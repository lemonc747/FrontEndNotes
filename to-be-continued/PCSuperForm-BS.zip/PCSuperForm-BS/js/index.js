
// after document loaded
$.when( $.ready ).then(function() {
    // Document is ready.
    var innerHeight = window.innerHeight;
    $("#xh-container").css("height", innerHeight);
    $(".xh-sidebar-content-container")
});





// var CONST_COMPONENTS = {
//     components: [
//         {name: "容器组件", icon: "", flag: "container"},
//         {name: "FLEX布局", icon: "", flag: "flex"},
//         {name: "九宫格", icon: "", flag: "nine_patch"},
//         // {name: "选项卡", icon: "", flag: ""},
//         {name: "底部导航", icon: "", flag: "bottom_nav"},
//         // {name: "滑块组件", icon: "", flag: ""},
//         {name: "图文列表", icon: "", flag: ""},
//         {name: "面板组件", icon: "", flag: ""},
//         {name: "文本链接", icon: "", flag: ""},
//         {name: "链接组件", icon: "", flag: ""},
//         {name: "图片组件", icon: "", flag: ""},
//         {name: "地图组件", icon: "", flag: ""},
//         {name: "图标", icon: "", flag: ""},
//         {name: "进度条", icon: "", flag: ""},
//         {name: "搜索组件", icon: "", flag: ""},
//         {name: "动态容器", icon: "", flag: ""}
//     ],
//     coms_template: "",
//     forms:[
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""},
//         {name: "", icon: "", flag: ""}
//     ]
// }

// function initComponents(){

// }

// initComponents();

// function initEvent(){
//     var $nav_tabs = $("#sidebar-nav-tabs"),
//         $tab_contnet = $("#tab-content"),
//         $tools =  $("#tools");

//     $nav_tabs.on("click", "li", function(){
//         event.preventDefault();
//         var $el = $(this),
//             href = $el.find("a").attr("href");
//         $nav_tabs.find("li").removeClass("active");
//         $el.addClass("active");
//         $tab_contnet.find(".tab-pane").removeClass("active"); 
//         $(href).addClass("active");
//     });

//     $tools.on("click", "li.boxes", function(){
//         var $el = $(this),
//             box_height = window.innerHeight;
//         $tools.find("li.boxes").hide();
        

//     })
// }

// initEvent();