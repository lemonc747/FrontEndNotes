
// after document loaded
$.when( $.ready ).then(function() {
    // Document is ready.
    var innerHeight = window.innerHeight;
    $("#xh-container").css("height", innerHeight);
    $(".xh-sidebar-content-container")
});