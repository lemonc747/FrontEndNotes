1,Node 服务器 打包js文件 简要
protoc.exe  将proto文件编译js文件

-I  .proto  内部  import 的路径
--js_out
	import_import_style    js的规范
			commonjs     nodejs  采用的CommonJS模块规范  （这里的表现是 一个proto文件就只生成一个js文件）
			closure		 闭包规范 （这里的表现是 一个proto文件里有多少个message就会生成多少个js文件）

protoc -I public/protofile --js_out=import_style=commonjs,output_dir:server/protojs public/protofile/*.proto

2，项目运行 

	node环境 npm包管理工具
	
	安装依赖  npm install 
	
	启动服务器 npm start 

	浏览器 http://localhost:8080
	
	数据库地址设置 server/db/mogodb.js  127.0.0.1:27017/mongodb   注：mongodb为数据库名  目前只有im模块用的了数据库
	
3，项目文件夹说明

	--logs ： 日志文件夹  （log4js）  这个文件夹是自动生成的
	--public   前端文件夹（静态网页，js，css）
		--css  样式文件夹（按模块分子文件）
		--images
		--javascripts
		--json  模拟数据文件夹
		--protofile  pb协议文件夹
		calerdar.html  日历模块
		hisDynamic.html 动态
		index_communitcate.html  im模块
		index.html  主页
		myFavorite.html 我的收藏
		new.html 新闻
		notice.html  通知
		rankBaord.html 排行
		todoList.html  待办
		...
		
	
	--server  后端nodejs文件夹
		-- api 					 接口模块
		--clientToc				 连接c服务器模块
		--config				 配置文件
		--db				     数据库模块
		--msg					 消息处理模块
		--protojs    			 pb协议 js文件
		--utils 				 工具模块
		
	--test  测试文件夹

	--app.js   入口js
	
	--package.json
	
	--protoc.exe				编译proto文件的exe
	
4,提交需知
	1，必须写日志
	2，提交前先update
	3，拉取不成功，解决冲突，提交不成功，解决冲突，解决不了冲突，请联系队友
	4，冲突解决后，别闲着，要提交，要提交，要提交！
	...
	更多注意请移步：http://www.jianshu.com/p/a980fc1eb626
	
5，编译proto文件

	命令说明：
	protoc --js_out=tes face.proto

	protoc.exe 

	--js_out 生成文件夹

	需要打包的文件

	不会  可以 查命令 help
	protoc --help
	
	进入项目中 以下命令行
	protoc --js_out=import_style=commonjs,binary:. public/protofile/*.proto

	
		
		
		
		

	
