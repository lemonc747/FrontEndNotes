#!/bin/sh
node app_docker_minjing.js &
