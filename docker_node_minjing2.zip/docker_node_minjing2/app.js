var express = require('express');
var app = express();
var bodyParser = require("body-parser");
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
//注册服务
var resgEureka = require('./server/resgEureka/resgEureka');
app.get('/health', (req, res) => {
    res.json({
        status: 'UP'
    });
});
app.get('/', (req, res, next) => {
    res.json({status: true,message:"It's works!"});
});


//日志模块
//var log = require("./server/utils/logUtils.js").init();
var server = require('http').createServer(app);
//var io = require('socket.io')(server);
app.use('/', express.static(__dirname + '/public'));
server.listen(5566, function() {
    var host = server.address().address
    var port = server.address().port
    console.log("listen "+host + port );
});
// 处理api接口
// var api = require("./server/api/api.js");
// api.init(app);
//web端通讯模块
//var webSocket = require("./server/webSocket/webSocket.js");
//webSocket.init(app);

////node 与 c++服务器模块
//var clientToC = require("./server/clientToC/clientToC.js");
//
//var helper = require("./server/utils/protojs_helper.js");
//var convert = require("./server/utils/convert_pro.js");
//var strUtils = require("./server/utils/string_utils.js");
//
//var Acceptmsg = helper.acceptmsg;
//var Common = helper.common;
//var SendMsg = helper.sendmsg;
//
//var msgAck = new Acceptmsg.msg_p2p_ack();
//
//var common = new Common.errorinfo();
//common.setErrorCode(4);
//common.setErrorInfo("错误");
//common.setErrorClientShow("helo");
//msgAck.setError(common);
//
//var byte = convert.objectToByte(msgAck);
//
//console.log("pb包前的obj");
//console.log(msgAck.toObject());
//var obj = convert.byteToObject(byte, Acceptmsg.msg_p2p_ack);
//console.log("解析包后的obj");
//console.log(obj.toObject());
//
////var pbByte = convert.addHead(byte);
////clientToC.SendToCByte(new Buffer(pbByte));
//console.log("我发了");
//clientToC.SendToCByte(new Buffer(convert.addHead(byte)));
