
function stringToByte(str) {
    var bytes = [];
    var buf = new Buffer(str);
	for(var i = 0;i < buf.length; i++){
		bytes.push(buf[i]);
	}
    return bytes;
}  
  
  
function byteToString(bytes) {  
    if(typeof arr === 'string') {  
        return arr;  
    }
     var buf = new Buffer(bytes);
     console.log(buf);
     console.log(bytes);
     return buf.toString('utf8', 0, bytes.length);
}  


var byte = stringToByte("我测试用例");

console.error("ches"+byteToString(byte));

