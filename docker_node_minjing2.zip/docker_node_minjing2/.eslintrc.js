module.exports = {
    // "extends": "google",
    // "extends": "eslint-config-airbnb",
    // rules: {
    //     "linebreak-style": ["error", "windows"],
    //     // "indent": ["error", 4]
    // }
};