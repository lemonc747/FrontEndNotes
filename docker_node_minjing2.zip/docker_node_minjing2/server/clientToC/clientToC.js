var net = require('net');
var port = 8888;
var host = '192.168.1.175';

var client= new net.Socket();
 client.setEncoding("utf8"); 
client.setEn
client.setEncoding('binary');
//定义接受消息处理函数
var receiveFromC;
//连接到服务端
client.connect(port,host,function(){
    console.log("连接"+host+":"+port+"成功");
});
client.on('data',function(d){
	console.log(typeof(d));
	
	console.log("socket",d);
	receiveFromC(d);
});
client.on('error',function(error){
    console.log('收到了错误:',error);

});
client.on('close',function(){
    console.log('Connection closed');
});

function SendToCByte(byte){
	client.write(byte, function(){
		console.log("发送 成功");
	});
}
//注册接受消息处理函数
function init(func){
	receiveFromC = func;
}

module.exports = {
    SendToCByte: SendToCByte,
    init:init
};