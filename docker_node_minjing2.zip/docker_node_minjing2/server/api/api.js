//API接口js
//1、req.body
//2、req.query
//3、req.params
function init(app){
	//引入dao层
	var dbDao = require("../db/mongodbDao.js");
	dbDao.init();
	//获取全部部门
	app.get("/org/allOrg",function(req,res){
		var dataHandle = function(data){
			res.json({result:data});
		}
		dbDao.getDepartMent(dataHandle,0);
	});
	
	//获取所有部门下的子部门
	app.get("/org/allOrg/childOrg",function(req,res){
		var dataHandle = function(data){
			 res.json({result:data});
		}
		dbDao.getDepartMent(dataHandle,1);
	});
	
	//获取部门(深圳市公安局)peson
	app.post("/org/orgName/p",function(req,res){
		 var id = req.body.orgId;
		 var dataHandle = function(data){
			 res.json({result:data});
		}
	    dbDao.getPerson(dataHandle,id);
	});
	
	//获取部门(深圳市公安局)下的部门
	app.post("/org/orgName/o",function(req,res){
		var id = req.body.orgId;
		var dataHandle = function(data){
			 res.json({result:data});
		}
		dbDao.getAllDepartMent(dataHandle,id);
	});
	
	//根据姓名搜索
	app.post("/org/userName",function(req,res){
		console.log("ddddd",req.body);
		var name = req.body.name;
//		console.log(name);
		var dataHandle = function(data){
			 res.json({result:data});
		}
		dbDao.getDataByName(dataHandle,name);
	});
	
	//获取消息列表
	app.post("/msgList",function(req,res){
		var id = req.body.imid;
		//数据处理回调(涉及到两个表查询)
		var dataHandle = function(d){
// 			res.json({data});
			//会话列表
			var msgList = d;
			//无会话记录
			if(msgList.length == 0){
				var data  = [];
				res.json({data});
				return ;
			}
			var personArray = [];
			var index = 1;
   			var func = function(data){
   				personArray.push(data);
   				mixData();
   			}
   			//请求imid对应得user表
   			for(var i = 0; i< msgList.length; i++){
   				dbDao.getPersonByimid(func,msgList[i].rec_id);
   			}
   			var mixData = function(){
   				if(index++>msgList.length-1){
   					//console.log("这样是可行的");
   					var data = [];
   					for(var i = 0 ; i < msgList.length; i++){
   						data.push({
   							c_id:msgList[i].c_id,
						    imid:msgList[i].imid,
						    rec_id:msgList[i].rec_id,
						    time:msgList[i].time,
						    lastWord:msgList[i].lastWord,
						    unread:msgList[i].unread,
						    userName:personArray[i].userName,
						    grade:personArray[i].grade,
						    policeRank:personArray[i].policeRank
   						});
   					}
   					res.json({data});
   				}
   			}
	   	}
		dbDao.getConversation(dataHandle,id);
	});
	
	//创建一个会话
	app.post("/createConv",function(req,res){
		var dataHandle = function(doc){
			//处理会话记录和 人整合
			var func = function(d){
				var data = {
					c_id:doc.c_id,
				    imid:doc.imid,
				    rec_id:doc.rec_id,
				    time:doc.time,
				    lastWord:doc.lastWord,
				    unread:doc.unread,
				    userName:d.userName,
				    grade:d.grade,
				    policeRank:d.policeRank
				};
				res.json(data);
			}
			dbDao.getPersonByimid(func,doc.rec_id);
		}
		var dataJson = req.body;
		dbDao.setConversation(dataHandle,dataJson);
	});
	
	//删除一个会话
	app.post("/deleteConv",function(req,res){
		function dataHandle(data){
			res.json("deletesucess");
		}
		var cID = req.body.c_id;
		var dataJson = {
			c_id:cID
		};
		dbDao.deleteConvs(dataHandle,dataJson);
	});
	
	//保存聊天记录
	app.get("/saveCRecord",function(req,res){
		function dataHandle(data){
			res.json("success");
		};
		var data = {
			msgId: new Date().getTime(),
			imId:"dddsdfd4545",
			sendId:"1545454",
			recId:"454811545",
			sendTime:new Date().getTime(),
			msgType:"45",
			msgBody:"4145",
			sendFlag:"24115415",
			recordTime:new Date().getTime()
		}
		dbDao.saveChatRecord(dataHandle,data);
	});
	
	//获取聊天记录
	app.post("/getCRecordList",function(req,res){
		function dataHandle(da){
			res.json(da);
		}
		console.log(req.body);
		dbDao.getCRcordList(dataHandle,req.body);
	});
	
	//测试推送消息
	app.get("/bgSendTo",function(req,res){
		res.json("success");
	});
	
	
}

module.exports = {
    init: init
};


