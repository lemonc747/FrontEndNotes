//数据转化工具js

/**
 * （类转化成字节数组）
 * @param object  传入的对象
 */
function objectToByte(object) {
    //编码
    var setToClient = object.serializeBinary();
    //console.log(setToClient);
    //转换成数组发送
    var byte = [];
    for (var i = 0; i < setToClient.length; i++) {
        byte.push(setToClient[i]);
    }
    return byte;
}

/**
 * （字节转化为对应得类对象）
 * @param {byte[]} byte 
 * @param {Object} originObj 
 */
function byteToObject(byte, originObj) {
    return new originObj.deserializeBinary(byte);
}

//添加协议头
function addHead(bodyByte){
	
//	typedef struct __tag_sdk_heart
//{
//	unsigned int   magic;				  // 识别sdk类型,前端或者后端(4字节)
//  unsigned char  version;               // 协议版本号（1字节）
//  unsigned char  encript;               // 压缩加密算法（1字节）
//  unsigned short cmd;                   // 命令字/功能号（2字节）,1-在服务端做注册, 3-心跳, ...
//  unsigned short checksum;              // 校验码（2字节）
//  unsigned int   body_len;              // 消息体长度（4字节）
//  unsigned int   seq;                   // 序列号（4字节）
//	unsigned int   imid;				  // imid(4字节)
//	unsigned short devicetype;			  // 设备类型(2字节),0-所有设备, 1-安卓, 2-PC, 3-Web
//}SDK_HEART;
//	
//	
//	heart->magic      = 0xFEFEFEFE;  //Web    发给 服务器
//heart->version    = 1;			 // 版本 1
//heart->encript    = 1;
//heart->cmd        = 1001;  		//统一注册命令
//heart->body_len	  = 0;
//heart->seq        = time(NULL);
//heart->imid       = xxx;
//heart->devicetype = 3;	// 0-all, 1-android, 2-pc, 3-web
//	
	
	//消息头部  24个字节
	//识别sdk类型,前端或者后端(4字节)
	var magic = 0xFEFEFEFE;
	//版本号    1 个字节
	var version = 1;
	//压缩，加密算法  1 个字节
	var encript = 1;
	//命令字功能号   2个字节
	var cmd = 1001;
//	//校验码  2个字节
//	var checkCode = 1;
	//消息体长度  4个字节
	var bodyLen = bodyByte.length;
	//序列号 4个字节
	var seq = 11;
	//imid(4字节)
	var imid = 6554;
	//设备类型(2字节),0-所有设备, 1-安卓, 2-PC, 3-Web
	var devicetype = 3;
	
	var buf = new Buffer(22);
	//writeInt32BE 大端 字节序 （按8bit）
	//writeInt32LE 小端字节序（按4bit）
	buf.writeUIntLE(magic,0,4);
	buf.writeUIntLE(version,4,1);
	buf.writeUIntLE(encript,5,1);
	buf.writeUIntLE(cmd,6,2);
//	buf.writeUIntLE(checkCode,8,2);
	buf.writeUIntLE(bodyLen,8,4);
	buf.writeUIntLE(seq,12,4);
	buf.writeUIntLE(imid,16,4);
	buf.writeUIntLE(devicetype,20,2);
	var byte = [];
	for(var i = 0 ; i<buf.length; i++){
		byte.push(buf[i]);
	}
	for(var i = 0; i<bodyByte.length; i++){
		byte.push(bodyByte[i]);
	}
	return byte;
}

//解析 数据 
function removeHead(data){
	console.log(data.length);
	var buf = new Buffer(data,'binary');
	
	var m = buf.readUIntLE(0,4);
	var v = buf.readUIntLE(4,1);
	var e = buf.readUIntLE(5,1);
	var c = buf.readUIntLE(6,2);
//	var ch = buf.readUIntLE(8,2);
	var b = buf.readUIntLE(8,4);
	var s = buf.readUIntLE(12,4);
	var i = buf.readUIntLE(16,4);
	var d = buf.readUIntLE(20,2);
	var bodyB = [];
	for(var i =0 ;i< buf.length-22;i++){
		bodyB.push(buf.readUIntLE(22+i,1));
	}
	var headInfo = {
		magic:m,
		version:v,
		encript:e,
		cmd:c,
//		checkCode:ch,
		bodyLen:b,
		seq:s,
		imId:i,
		devicetype:d,
	}
	return {headInfo:headInfo,bodyB:bodyB}
}

module.exports = {
    byteToObject: byteToObject,
    objectToByte: objectToByte,
    addHead:addHead,
    removeHead:removeHead
};