//定义协议 消息js类的 导入
module.exports = {
	
    acceptmsg: require("../protojs/acceptmsg_pb.js"),
    common: require("../protojs/common_pb.js"),
    sendmsg: require("../protojs/sendmsg_pb.js"),
  
  
};