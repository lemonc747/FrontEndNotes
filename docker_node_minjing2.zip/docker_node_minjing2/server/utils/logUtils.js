//日志模块
function init(){
	var log4js = require('log4js');
	var log4js_config = require("../config/log4js.js").config;
	log4js.configure(log4js_config);
	var logger = log4js.getLogger();
	console.log = logger.info.bind(logger);
	console.log("log4js start");
}

module.exports = {
    init: init
};
