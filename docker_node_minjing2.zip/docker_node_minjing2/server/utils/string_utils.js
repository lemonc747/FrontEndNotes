/**
 *
 * 字符串一些操作工具
 **/


function stringToByte(str) {
    var bytes = [];
    var buf = new Buffer(str);
	for(var i = 0;i < buf.length; i++){
		bytes.push(buf[i]);
	}
    return bytes;
}  
  
  
function byteToString(bytes) {  
    if(typeof arr === 'string') {  
        return arr;  
    }
     var buf = new Buffer(bytes);
     return buf.toString('utf8', 0, bytes.length);
}  

//提供分割@的用户列表
function getUserFromString(contentStr){
	var userList = [];
	var strArr =contentStr.split('@');
	//处理
	
	
	
	return userList;
}

module.exports = {
    byteToString: byteToString,
    stringToByte: stringToByte,
    getUserFromString:getUserFromString
};