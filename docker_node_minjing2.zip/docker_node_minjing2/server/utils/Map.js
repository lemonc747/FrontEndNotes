var Map = function (){ 
	var struct = function(key, value) { 
		this.key = key; 
		this.value = value; 
	} 

	var put = function(key, value){ 
		for (var i = 0; i < this.arr.length; i++) { 
			if ( this.arr[i].key === key ) { 
				this.arr[i].value = value; 
				return;
			} 
		} 
		this.arr[this.arr.length] = new struct(key, value); 
	} 

	var get = function(key) { 
		for (var i = 0; i < this.arr.length; i++) { 
			if ( this.arr[i].key === key ) { 
				return this.arr[i].value; 
			} 
		} 
		return null; 
	} 
	
	var getByValue = function(value){
		for (var i = 0; i < this.arr.length; i++) { 
			if ( this.arr[i].value === value ) { 
				return this.arr[i]; 
			} 
		} 
		return null; 
	}

	var remove = function(key) { 
		var v; 
		for (var i = 0; i < this.arr.length; i++) { 
			v = this.arr.pop(); 
			if ( v.key === key ) { 
				continue; 
			} 
			this.arr.unshift(v); 
		} 
	} 
	
	var removeByValue = function(value) { 
		var v; 
		for (var i = 0; i < this.arr.length; i++) { 
			v = this.arr.pop(); 
			if ( v.value === value ) { 
				continue; 
			} 
			this.arr.unshift(v); 
		} 
	} 

	var size = function() { 
		return this.arr.length; 
	} 

	var isEmpty = function() { 
		return this.arr.length <= 0; 
	} 
	
	var hasKey = function(key){
		for (var i = 0; i < this.arr.length; i++) { 
			if(this.arr[i].key == key){
				return true;
			}
			return false;
		}
	}
	
	this.arr = new Array(); 
	this.get = get;
	this.getByValue = getByValue;
	this.put = put;
	this.hasKey = hasKey;
	this.remove = remove;
	this.removeByValue = removeByValue;
	this.size = size; 
	this.isEmpty = isEmpty; 
}

module.exports = {
    Map: Map
};
