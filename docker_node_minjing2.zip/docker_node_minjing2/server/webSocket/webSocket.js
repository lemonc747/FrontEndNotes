//客户端和nodejs的 socket连接处理

var map = require("../utils/Map.js").Map;
//处理消息
var eventEmitter =  require("../msg/msgOprate.js").eventEmit;
//建立一个用户连接map
var connectPool = new map();

function init(io){
	//socket部分
	io.on('connection', function(socket) {
	    console.log(socket.id+'连接成功');
	    //接收并处理客户端的hi事件
	    socket.on('fromClient', function(data) {
	    	//客户端发送的token作为key
	    	console.log(data.id +'连接服务器成功');
	    	console.log("字段标识",data.id);
	    	//将客户端连接加入到连接池中
	    	addConnectPool(data.id,socket);
	    	//验证用户
	    	eventEmitter.emit("verify",data,socket);
	    	console.log("当前连接数："+connectPool.size());
	    });
	
	    //断开事件
	    socket.on('disconnect', function(data) {
	        console.log(socket.id+"断开");
	        removeConnectPoolValue(socket);
	        console.log("当前连接数："+connectPool.size());
	    });
	    
	    socket.on("transfer",function(data){
	    	//处理业务消息
	    	var soc = getConnetSocketByValue(socket);
	    	eventEmitter.emit("chatMsgOprate",data,soc);
	    });
	});
}

//加入到连接池
function addConnectPool(key,value){
	connectPool.put(key,value);
}

//从连接池移除
function removeConnectPool(key){
	connectPool.remove(key);
}

function removeConnectPoolValue(value){
	connectPool.removeByValue(value);
}

function getConnetSocketByValue(value){
	//返回的是一个map   key  和 value
	return connectPool.getByValue(value);
}

//判断是否又这个连接
function hasthisSocket(key){
	return connectPool.hasKey(key);
}

module.exports = {
    init: init,
    connectPool:connectPool
};