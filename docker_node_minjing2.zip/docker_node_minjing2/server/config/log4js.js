exports.config = {
	appenders: {
		outConsole:{ type: 'console'},
		outFile:{ type: 'dateFile', filename: 'logs/all-the-logs.log',
		pattern: '.yyyy-MM-dd-hh', compress: true}
	},
	categories: {
		default: { 
			appenders: [ 'outConsole', 'outFile' ], level: 'debug' }
	},
	replaceConsole: true
}