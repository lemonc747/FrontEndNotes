//mongodb 数据库
function init(){
	var mongoose = require("mongoose");
	console.log("初始化db ");
	var db = mongoose.connect("mongodb://172.19.255.93:27017/webIM");
	db.connection.on("open",function(){
    	console.log("172.19.255.93—数据库连接成功！——"); 
	});
	db.connection.on("error", function (error) { 
     	console.log("-172.19.255.93--数据库连接失败：" + error); 
	}); 
	return mongoose;
}

function createDepartMentTable(mongoose){
	var orgSchema = new mongoose.Schema({
		  orgId:{type:String,require:true},
		  orgCode:{type:String},
		  orgName:{type:String},
		  parentId:{type:String},
		  orgPath:{type:String},
		  sort:{type:String}
		});
	var org=mongoose.model("org",orgSchema);
	return org;
}

function createPersonTable(mongoose){
	var userSchema = new mongoose.Schema({
		imid:{type:String,require:true},
		copNum:{type:String},
		userName:{type:String},
		orgId:{type:String},
		sort:{type:String},
		grade:{type:String},
		policeRank:{type:String},
		avatarUrl:{type:String}
	});
	var User=mongoose.model("User",userSchema);//用户表	
	return User;
}

function createConversationTable(mongoose){
	var conSchema = new mongoose.Schema({
		c_id:{type:String,require:true},
		imid:{type:String,require:true},
		rec_id:{type:String,require:true},
		time:{type:String},
		lastWord:{type:String},
		unread:{type:String}
	});
	var conversation = mongoose.model("conversataion",conSchema);//用户表	
	return conversation;
}

function createChatRecordTable(mongoose){
	var conSchema = new mongoose.Schema({
		msg_id:{type:String,require:true},
		imid:{type:String,require:true},
		send_id:{type:String},
		rec_id:{type:String,require:true},
		send_time:{type:String},
		msg_type:{type:String},
		msg_body:{type:String},
		send_flag:{type:String},
		record_time:{type:String}
	});
	var chatRecord = mongoose.model("chatRecord",conSchema);//用户表	
	return chatRecord;
}

module.exports = {
    init: init,
    createDMTable:createDepartMentTable,
    createPTable:createPersonTable,
    createCTable:createConversationTable,
    createCRecordTable:createChatRecordTable,
};
