//dao层
//部门表结构
var org;
//用户表结构
var User
//回话表结构
var conversate;

function init(){
	var db = require("../db/mongodb.js");
	var mongoose = db.init();
	//部门表结构
	org = db.createDMTable(mongoose);
	//用户表结构
	User = db.createPTable(mongoose);
	//会话表结构
	conversate = db.createCTable(mongoose);
	//聊天记录表结构
	chatRecord = db.createCRecordTable(mongoose);
	
}

function getDepartMent(datahandle,id){
	org.findOne({parentId:id},function(err,doc){
	        if(err){
	          console.log(err)
	        }else{
	          datahandle(doc);
	        }
     	});
}

function getAllDepartMent(datahandle,id){
	org.find({parentId:id},function(err,doc){
        if(err){
          console.log(err)
        }else{
          datahandle(doc);
        }
    });
}

//获取指定部门下所有的人
function getPerson(datahandle,id){
	User.find({orgId:id},function(err,doc){
	        if(err){
	          console.log(err)
	        }else{
             	datahandle(doc);
	        }
	     });
}

//根据名称获取部门或人
function getDataByName(datahandle,name){
//	org.find({orgName:{"$regex":name}},function(err,doc){
//      if(err){
//        console.log(err)
//      }else{
//      var arr = doc;
//	    User.find({userName:{"$regex":name}},function(err,doc){
//		    if(err){
//		        console.log(err)
//		        }else{
//		         	for (var i = 0; i < arr.push()doc.length; i++) {
//		         		arr.push(doc[i]);
//		         	}
//		         	datahandle(arr);
//		        }
//		    });
//      }
//  });
//  
    
 	User.find({userName:{"$regex":name}},function(err,doc){
	    if(err){
	       		console.log(err)
	        }else{
         		datahandle(doc);
	        }
	    });
    }

//获取指定imid 的详细信息
function getPersonByimid(datahandle,imid){
	User.findOne({imid:imid},function(err,doc){
        if(err){
          console.log(err)
        }else{
         	datahandle(doc);
        }
     });
}

function getConversation(dataHandle,id){
	conversate.find({imid:id},function(err,doc){
	        if(err){
	           console.log(err)
	        }else{
	            dataHandle(doc);
	        }
        });
}

//创建一个会话
function setConversation(dataHandle,data){
	conversate.create({
		c_id:new Date().getTime(),
		imid:data.imid,
		rec_id:data.rec_id,
		time:new Date().getTime(),
		lastWord:"",
		unread:0
	},function(err,doc){
		dataHandle(doc);
	});
}

//删除一个会话
function deleteConvs(dataHandle,data){
  var whereStr = {c_id:data.c_id};
  conversate.remove(whereStr, function(err, result) {
    if(err)
    {
      console.log('Error:'+ err);
      return;
    }
    dataHandle(result);
  });
}

function updateConversation(dataHandle,data){
    //更新数据
    console.log(data);
    var whereStr = {"c_id":data.c_id};
    var updateStr = {$set: { 'lastWord' : data.lastWord, 
    	'time': new Date().getTime(),'unread':data.unReadCount }};
    conversate.update(whereStr,updateStr, function(err, result) {
        if(err)
        {
            console.log('更新数据失败！！:'+ err);
            return;
        }
        dataHandle(result);
    });
}

function saveChatRecord(dataHandle,data){
	chatRecord.create({
		msg_id:data.msgId,
		imid:data.imId,
		send_id:data.sendId,
		rec_id:data.recId,
		send_time:data.sendTime,
		msg_type:data.msgType,
		msg_body:data.msgBody,
		send_flag:data.sendFlag,
		record_time:data.recordTime
	},function(err,doc){
		dataHandle(doc);
	}); 
}

function getCRcordList(dataHandle,data){
	chatRecord.find({imid:data.imId,rec_id:data.recId},function(err,doc){
	  	if(err){
           console.log(err)
        }else{
            dataHandle(doc);
        }
	});
}

module.exports = {
    init: init,
    getDepartMent:getDepartMent,
    getAllDepartMent:getAllDepartMent,
    getPerson:getPerson,
    getPersonByimid:getPersonByimid,
    getConversation:getConversation,
    setConversation:setConversation,
    updateConversation:updateConversation,
    deleteConvs:deleteConvs,
    saveChatRecord:saveChatRecord,
    getCRcordList:getCRcordList,
    getDataByName:getDataByName
};
