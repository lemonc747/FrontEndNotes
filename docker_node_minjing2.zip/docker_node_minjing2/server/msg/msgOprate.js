//客户端处理消息处理
var events = require('events');
var eventEmit = new events.EventEmitter();

eventEmit.on('verify', verify);
eventEmit.on('chatMsgOprate',chatMsgOprate);
//数据操作
var dbDao = require("../db/mongodbDao.js");

var eventEmitter =  require("../msg/msgdispatch.js").eventEmitter;

function verify(data,soc){
	console.log("验证");
	console.log(data);
}

function chatMsgOprate(data,soc){
	//记录消息保存的mongo
	var dataHandle = function(){}
	var dd = {
			msgId: new Date().getTime(),
			imId:data.imid,
			sendId:data.imid,
			recId:data.rec_id,
			sendTime:new Date().getTime(),
			msgType:data.msg_type,
			msgBody:data.msgbody,
			sendFlag:"24d",
			recordTime:new Date().getTime()
		}
	dbDao.saveChatRecord(dataHandle,dd);
	//更新会话的最后一句话
	var huihua = {
		c_id:data.c_id,
		lastWord:data.msgbody,
		unread:"0"
	}
	dbDao.updateConversation(dataHandle,huihua);
	//发送出去
	eventEmitter.emit("dispatchMsg",dd);
}


module.exports = {
    eventEmit: eventEmit
};