//消息分发
var events = require('events');
var eventEmitter = new events.EventEmitter();
//数据操作
var dbDao = require("../db/mongodbDao.js");
//监听消息分发
eventEmitter.on('dispatchMsg', getMsg);
//node 与 c++服务器模块
var clientToC = require("../clientToC/clientToC.js");
var helper = require("../utils/protojs_helper.js");
var convert = require("../utils/convert_pro.js");
var strUtils = require("../utils/string_utils.js");
//初始化连接c
clientToC.init(sendMsg);
//fromCServer
function getMsg(data){
	//发送到c++服务器
	console.log("待处理的消息_发送pb包到c++");
	var Acceptmsg = helper.acceptmsg;
	var Common = helper.common;
	var SendMsg = helper.sendmsg;
	var msgAck = new Acceptmsg.msg_p2p_ack();
	//发送单聊
	var sendMsgPB = new SendMsg.msg_p2p_send();
	var msgContent = new Common.msg_content();
	sendMsgPB.setRecvId(data.recId);
	//根据common.proto的msg_content类型
	//文本 1 	图片2 	语音3		名片4		位置5		红包6	 	消息分享7
	sendMsgPB.setMsgType(data.msgType);
	var value;
	switch (data.msgType) {
	    case 1:
		    value = new Common.TEXT_CONTENT();
		    value.setMsg(data.msgBody);
		    var remindUserList = strUtils.getUserFromString(data.msgBody);
			console.log("user数组",remindUserList);
			value.setRemindUserListList(remindUserList);
	      	msgContent.setText(value);
	      	break;
	    case 2:
	      	value = new Common.PICTURE_CONTENT();
	      	value.setPictureUrl("");
	      	value.setThumbPic("");
	      	value.setThumbWidth(11);
	      	value.setThumbHight(11);
	      	msgContent.setPicture(value);
	      	break;
	    case 3:
	      	value = new Common.VOICE_CONTENT();
	      	value.setVoiceLen(11);
	      	value.setVoiceUrl("www.baidu.com");
	      	msgContent.setVoice(value);
      		break;
	    case 4:
	      	value = new Common.BUSI_CARD_CONTENT();
	      	value.setCardUserId(11);
	      	value.setCardUserName("22");
	      	value.setCardUserUrl("");
	      	msgContent.setCard(value);
	      	break;
	    case 5:
	      	value = new Common.LOCATION_CONTENT();
	      	value.setLocationPicUrl("ss");
	      	value.setLongitude(125.55);
	      	value.setLatitude(125.25);
	      	value.setLocationAddr("shen");
	      	msgContent.setLocation(value);
	      	break;
	    case 6:
	      	value = new Common.RED_PKT_CONTENT();
	      	value.setRedPkgId(11);
			value.setRedPkgMessage("sdf");
			msgContent.setRedpkt(value);
	      	break;
	    case 7:
	      	value = new Common.SHARE_CONTENT();
	      	value.setMsgShareType(11);
	      	value.setJsonMsgbody("sjj");
	      	msgContent.setShare(value);
	      	break;
	    default:
	    	console.log("无法识别的类型");
	      	break;
    }
	sendMsgPB.setMsg(msgContent);
	
	var byteArr = convert.objectToByte(sendMsgPB);
//	//测试是否能转换回来
//	var obj = convert.byteToObject(byteArr, SendMsg.msg_p2p_send);
//	console.log("解析包后的obj");
//	console.log(obj.toObject());
	console.log("发送到服务器");
	clientToC.SendToCByte(new Buffer(convert.addHead(byteArr)));
}

clientToC.SendToCByte(new Buffer(convert.addHead([])));


//处理c++的pb包发送到web	
function sendMsg(data){
	console.log(data);
	var headInfoS = convert.removeHead(data).headInfo;
	console.log(headInfos);
	//根据命令来解析包体
//	//封装消息发送出去 若收到消息是要发送回应
//	var sendData = {
//		msg_id: new Date().getTime(),
//		imid: data.imid,
//		send_id:data.rec_id,
//		rec_id:data.rec_id,
//		msgbody:"兄弟我收到了",
//		send_time: new Date().getTime(),
//		msg_type:1,
//		send_flag:4,
//		record_time:new Date().getTime(),
//		//会话id
//		c_id:data.c_id
//	}
//	returnmsg(sendData,keyAndValue.value);
//	var dd1 = {
//			msgId: new Date().getTime(),
//			imId: data.imid,
//			sendId:data.rec_id,
//			recId:data.rec_id,
//			msgBody:"兄弟我收到了",
//			sendTime: new Date().getTime(),
//			msgType:1,
//			sendFlag:4,
//			recordTime:new Date().getTime(),
//		}
//	dbDao.saveChatRecord(dataHandle,dd1);
//	//更新会话的最后一句话
//	var huihua = {
//		c_id:data.c_id,
//		lastWord:data.msgbody,
//		unread:"0"
//	}
//	dbDao.updateConversation(dataHandle,huihua);
//	//发到web端
//	socket.emit('transfer', data);
}

module.exports = {
    eventEmitter: eventEmitter
};