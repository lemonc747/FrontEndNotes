/**
 * table
 * @date 20180626
 * 1. 初始化配置：options结构
 * {
 *  selector: container选择器
 *  fields: [
 *      {
 *        // 每个字段的配置属性
 *        name: string, //字段名
 *        width: number, //列宽
 *        format: function(value){ return 'string';}, //value格式化函数
 *        ...
 *      },
 *      ...
 *  ],
 *  getData: function(pagination){} //获取数据的方式 参数为paginnation分页对象
 *
 * }
 *
 *  pagination: {
 *    pageSize: 每页条数,
 *    pageNumber:  当前页码,
 *    pageTotal: 总页码,
 *  }
 *
 *  2. 载入数据：data + total
 *  data: [], // 返回的数据数组

 * }
 *
 * 1. 数据请求的过程与table无关，table只关心返回的data
 * 2. pagination
 *
 * 三：流程
 * 1. 点击分页 => 触发回调 => 获取data !> 不会自动重绘界面，需要自己调用render方法
 *
 */

(function xh() {
  const defaultOptions = {
    pageSize: 10, // 每页条数
    pageNumber: 0, // 当前页码
    pageTotal: 0, // 总页数
  };

  const init = Symbol('init');
  const template = Symbol('template');
  const createTable = Symbol('createTable');
  const createPagination = Symbol('createPagination');
  const handleEachField = Symbol('handleEachField');
  const createPgBody = Symbol('createPgBody');
  const createPsBody = Symbol('createPsBody');
  const getItem = Symbol('getItem');
  const bindPgEvent = Symbol('bindPgEvent');
  const bindRowCallback = Symbol('bindPgEvent');
  const handleEachTitle = Symbol('handleEachTitle');

  class XHTable {
    constructor(options) {
      if (!options || !options.selector) {
        throw new Error('XHTable options format error.');
      }
      this[init](options);
    }

    /**
     * 初次绘制需要同步pagination
     * @param {object} data
     */
    render(data, pageNumber, pageSize) {
      // todo 现在取data的过程排除在XHTable外面，因为异步的一些原因
      // const data = this.getData(pagination || this.pagination);
      // fixed: data.total = 0 throw error
      if (!data || !data.data || data.total === undefined) {
        throw new Error('XHTable getData return uncorrect data.');
      }
      this.data = data.data;
      if (pageNumber !== undefined) {
        this.pageNumber = pageNumber;
      }
      if (pageSize !== undefined) {
        this.pageSize = pageSize;
      }
      this[createTable](data.data);
      this[createPagination](data.total);
      this[bindPgEvent]();
      return this;
    }

    setCallback(fnc) {
      this.getData = fnc;
      return this;
    }

    [init](options) {
      const params = extend({}, defaultOptions, options);
      this.fields = params.fields;
      this.getData = params.getData;
      this.pageNumber = params.pageNumber;
      this.pageSize = params.pageSize;
      this.pageTotal = params.pageTotal;
      this.el = document.querySelector(params.selector);
      this.el.innerHTML = this[template]('container');
      this.elThead = this.el.querySelector('table>thead');
      this.elTbody = this.el.querySelector('table>tbody');
      this.elPagination = this.el.querySelector('ul.pagination');
      // events no $
      this[bindRowCallback](params.rowCallback);
    }

    [createTable](data) {
      if (!this.elThead.innerHTML) {
        const ths = [];
        this.fields.forEach((field) => {
          ths.push(this[handleEachTitle](field));
        });
        this.elThead.innerHTML = this[template]('tr', ths.join(''))
      }
      let rows = [];
      let rowsSum = [];
      this.fields.forEach((field) => {
        const name = field.name;
        for (let index=0; index < this.pageSize; index ++) {
          let item = data[index] || {};
          const value = this[handleEachField](item[name], field);
          rows[index] = rows[index] || [];
          rows[index].push(value);
        }
      });
      rows.forEach((item, index) => {
        rowsSum.push(this[template]('tr', item.join(''), index));
      });
      this.elTbody.innerHTML = rowsSum.join('');
    }

    [createPagination](total) {
      this.pageTotal = Math.ceil(total / this.pageSize);
      this[createPgBody]();
    }

    [handleEachTitle](field) {
      let style = '';
      let result = field.name;
      if (field.show === false) {
        return '';
      }
      if (field.width) {
        style += `width:${field.width}px;=`;// 'width:' + field.width + 'px;';
      }
      if (field.text) {
        result = field.text;
      }
      return this[template]('th', result, style);
    }

    /**
     * handle each field value with configes
     */
    [handleEachField](value, field) {
      let result = value;
      // 配置：隐藏
      if (field.show === false) {
        return '';
      }
      // 空值：返回占空间的td元素
      if (result === undefined) {
        return this[template]('td', '&nbsp;');
      } else {
        // 其他处理
        if (field.format) {
          result = field.format(value);
        }
        return this[template]('td', result);
      }
    }

    [template](type, content, param=' ') {
      const template = {
        container: '<table class="table table-hover" style="cursor:pointer;"><thead></thead><tbody></tbody></table><div class="pagi_container"><ul class="pagination"></ul></div>',
        th: `<th style="${param}">${content}</th>`,
        tr: `<tr data-xh-index='${param}'>${content}</tr>`,
        td: `<td style="${param}">${content}</td>`,
        tf: `<tfoot>${content}</tfoot>`,
        pagination: `<li class="page-item {{status}}"><a class="page-link" data-dt-idx="{{index}}" href="javascript:void(0);">{{content}}}</a></li>`,
      }
      return `${template[type]}`;
    }

    [createPgBody]() {
      let pt = this.pageTotal || 0,
        pn = this.pageNumber || 0,
        itemsDom = [],
        preEnable = pn>0,
        nextEnable = pn<pt,
        preElipsis = pn >= 4,
        nextElipsis = pt-pn>=4,
        preJumpPoint = Math.min(pn-1, pt-4),
        nextJumpPoint = Math.max(pn+1,4);
      
      itemsDom.push(this[getItem](-1, '<', preEnable));
      for( var i=0; i<pt; i++ ){
        if( preElipsis && i>0 && i<preJumpPoint ){
            itemsDom.push(this[getItem]("", "...", !preElipsis));
            i = preJumpPoint-1;
            continue;
        }
        if(nextElipsis && i<pt && i>nextJumpPoint){
            itemsDom.push(this[getItem]("", "...", !nextElipsis));
            i = pt-1;
            continue;
        }
        itemsDom.push(this[getItem](i, i+1, i==pn?"active":true));
      }
      itemsDom.push(this[getItem](-2, '>', nextEnable));
      this.elPagination.innerHTML = itemsDom.join('');
    }

    [getItem](index, content, status) {
      // true means enabled/normal, false means disabled, "active" means active
      var status = status === false ? "disabled" : ( status === "active" ? "active" : "" );
      return this[template]('pagination').replace("{{index}}", index).replace("{{content}}}", content).replace("{{status}}", status);
    }

    [createPsBody]() {
      const pageSize = this.elPagination.querySelector('select');
      if (!pageSize) {
        // todo
      }
    }
    
    /**
     * 选中页码随后重绘
     */
    [bindPgEvent]() {
      let pageNumber = this.pageNumber;
      let pageSize = this.pageSize;
      const that = this;
      $(this.elPagination).off("click").on("click", "li:not(.disabled)", function(){
        const index = $(this).find(".page-link").attr("data-dt-idx");
        if (index === undefined || index == "" || index == pageNumber) {
          return;
        } else if(index =="-1") {
          pageNumber = parseInt(pageNumber)-1;
        } else if (index == "-2") {
          pageNumber = parseInt(pageNumber)+1;
        } else {
          pageNumber = parseInt(index);
        }
        // update
        that.pageNumber = pageNumber;
        that.pageSize = pageSize;
        that.getData(pageNumber, pageSize);
      });
    }

    // 绑定行点击事件
    [bindRowCallback](rowCallback) {
      if (rowCallback) {
        const that = this;
        $(this.elTbody).on('click', 'tr', function rowClick() {
          const $row = $(this);
          const index = this.getAttribute('data-xh-index');
          const item = that.data[index];
          item && rowCallback(item, index, $row);
        });
      }
    }
  }

  function extend(target, ...obj) {
    // todo 
    return $.extend(true, target, ...obj);
  }

  // todo
  window.XHTable = XHTable;
}());
