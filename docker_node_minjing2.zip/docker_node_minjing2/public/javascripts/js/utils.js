
;(function(win){

    win.Utils = {};

    /**
     * ajax
     * @data [object] ajax请求参数
     * {
     *  url：
     *  data:
     *  success:
     * }
     */
    Utils.ajax = function(data){
        if(!($ && data && data.url)){
            console.log("JQuery & data & data.url is required!");
            return;
        }
        parent.XHSDK.ajax({
            url: data.url,
            data: JSON.stringify(data.data),
            type: data.type || "GET",
            dataType: data.dataType || "json",
            contentType: "application/json;charset=utf-8",
            success: function(result){
                data.success && data.success instanceof Function && data.success(result);
            },
            error: function(e){
                data.error && data.error instanceof Function && data.error();
                console.log( console.log("Utils-ajax error || ", e));
            }
        });
    }

    /**
     * websocket
     * @param data [object]
     * {
     *  url:
     *  onmessage:
     * }
     */
    Utils.ws = function(data){
        //这里的变量，为每个websocket私有
        //避免重复连接
        var lockReconnect = false,
            //心跳检测
            heartCheck = {
                timeout: 30000,//60秒
                timeoutObj: null,
                reset: function(){
                    clearTimeout(this.timeoutObj);
                    return this;
                },
                start: function(ws){
                    this.timeoutObj = setTimeout(function(){
                        //这里发送一个心跳，后端收到后，返回一个心跳消息，
                        //onmessage拿到返回的心跳就说明连接正常
                        ws.send("HeartBeat");
                    }, this.timeout)
                }
            };
         createWebSocket();

         /**重新连接 */
        function reconnect() {
            if(lockReconnect) return;
            lockReconnect = true;
            //没连接上会一直重连，设置延迟避免请求过多
            setTimeout(function () {
                createWebSocket();
                lockReconnect = false;
            }, 2000);
        }

        function createWebSocket() {
            console.log("create websocket with url:"+ data.url);
            try {
                var ws = new WebSocket(data.url);
                ws.onclose = function () {
                    reconnect();
                };
                ws.onerror = function () {
                    reconnect();
                };
                ws.onopen = function () {
                    //心跳检测重置
                    heartCheck.reset().start(ws);
                };
                ws.onmessage = function (event) {
                    console.log(event.data);
                    //如果获取到消息，心跳检测重置
                    //拿到任何消息都说明当前连接是正常的
                    heartCheck.reset().start(ws);
                    try {
                        //数据处理

                        // var my_event = eval("WS:(" + event.data + ")");
                        // if(my_event && my_event.code !=0){
                        //     layer.open("websocket error! cmd is "+my_event.cmd+", code is "+my_event.code);
                        //     return;
                        // }
                        var my_event = Utils.parseJSON(event.data);
                        data.onmessage && data.onmessage instanceof Function
                            && data.onmessage(my_event);
                    } catch (error) {
                        console.log("error:",event.data);
                        return;
                    }
                }
                return ws;
            } catch (e) {
                reconnect();
            }
        }

    };


    Utils.parseJSON = function(data){
        if(data && typeof data === "string"){
            if( (data.startsWith("{") && data.endsWith("}"))
                || (data.startsWith("[") && data.endsWith("]"))){
                try{
                    data = JSON.parse(data);
                }catch(e){
                    data = eval("("+data+")");
                }
            }
        }

        Utils.each(data, function(index, item){
            data[index] = Utils.parseJSON(item);
        });

        return data;
    };

    /**
     * 遍历对象，数组，类数组
     * @param obj
     * @param callback
     * @param deep [boolean] default:false
     * @return
     *  (retrurn === false) ? break loop : continue
     */
    Utils.each = function(obj, callback, deep){
        if( !obj || typeof obj !== "object" )
            return;
        var lenght = obj.length, i=0;
        if( isArrayLike(obj)){
            for(; i<length; i++){
                if( callback.call(obj[i], i, obj[i]) === false ){
                    break;
                }
                if(deep){
                    Utils.each(obj[i], callback, deep);
                }
            }
        }else{
            for( i in obj){
                if( callback.call(obj[i], i, obj[i]) === false ){
                    break;
                }
                if(deep){
                    Utils.each(obj[i], callback, deep);
                }
            }
        }
        return obj;
    };

    function isArrayLike(obj){
        var length = !!obj && obj.length;
        //isWindow || isFunction
        if( (obj != null && obj.window === obj) || typeof obj === "function"){
            return false
        }
        return Array.isArray(obj) || length===0 || length>0 && (length-1) in obj;
    }

}(window));