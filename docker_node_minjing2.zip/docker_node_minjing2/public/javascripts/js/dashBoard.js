// window.Utils
;(function(){
    // var dashboardServiceUrl = parent.dashboardServiceUrl;
    // var dashboardWebSocketUrl = parent.dashboardWebSocketUrl;
    const token_chart = parent.my_token;
    // 实例化，并自定义配置的echart主题
    const dashboard_bar = echarts.init(document.querySelector("#dashboard-bar"), 'xhtheme');
    const dashboard_pie = echarts.init(document.querySelector("#dashboard-pie"), 'xhtheme');

    // const $el = $(myChart);
    const barOptions = {
      title : {
          text: '仪表盘柱状图',
          x:'left'
      },
      color: ['#3398DB'],
      tooltip : {
          trigger: 'axis',
          axisPointer : {            // 坐标轴指示器，坐标轴触发有效
              type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
          }
      },
      grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
      },
      xAxis : [
          {
              type : 'category',
              data : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
              axisLine: {
                show: false
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                  textStyle: {
                      color: '#999999'
                  }
              }
          }
      ],
      yAxis : [
          {
              type : 'value',
              axisLine: {
                show: false
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                  textStyle: {
                      color: '#999999'
                  }
              }
          }
      ],
      series : [
          {
              name:'name',
              type:'bar',
              barWidth: '60%',
              data:[10, 52, 200, 334, 390, 330, 220],
              itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 1, color: '#53A8E2'},
                            {offset: 0, color: '#76DDFB'}
                        ]
                    )
                }
              }  
          }
      ]
    };
    const pieOptions = {
      title : { text: '仪表盘饼图', x:'left'},
      tooltip : { trigger: 'item', formatter: "{a} <br/>{b} : {c} ({d}%)" },
      legend: { orient: 'vertical', left: 'left', top: 40, data: ['pie','pie','pie']},
      series : [
        {
          name: 'name',
          type: 'pie',
          radius: ['45%', '70%'],
          center: ['60%', '60%'],
          label: {
            position: "inside"
          },
          data:[
              {value:335, name:'demo'},
              {value:310, name:'demo'},
              {value:234, name:'demo'},
              {value:135, name:'demo'},
              {value:1548, name:'demo'}
          ],
          itemStyle: {
              emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
          }
        }
      ]
    };

    init();
    function init(){
      initBar();
      initPie();
    };
   
    /**初始化柱形图 */
    function initBar(){
      dashboard_bar.showLoading();
      Utils.ajax({
        url: dashboardServiceUrl+"/getInitDashboard",
        data: {accessToken:token_chart, type:"bar"},
        type: "POST",
        success: function(data){
          updateBaseBar(Utils.parseJSON(data));
          dashboard_bar.hideLoading();
        },
        error: function(e){
          dashboard_bar.hideLoading();
        }
      });
    }

    /**初始化饼状图 */
    function initPie(){
      dashboard_pie.showLoading();
      Utils.ajax({
        url: dashboardServiceUrl+"/getInitDashboard",
        data: {
          accessToken: token_chart,
          type: "pie"
        },
        type: "POST",
        success: function(data){
          updateBasePie(Utils.parseJSON(data));
          dashboard_pie.hideLoading();
        },
        error: function(e){
          dashboard_pie.hideLoading();
        }
      });
    }

    /**
     * @param {string} selector 容器选择器
     * @param {*} data 返回数据对象
     *  {
     *      cmd：
     *      type:
     *      url:
     *      result:         object, 属性如下
     * 
     *      ng_user:        
     *  }
     */
    function updateBaseBar(data) {
        if (!(data && data.result)) {
            console.log("data is required!");
            return;
        }
        barOptions.series[0].data = data.result.series_data;
        barOptions.series[0].name = data.result.series_name;
        barOptions.xAxis[0].data = data.result.xAxis_data;
        dashboard_bar.setOption(barOptions); 
    };

    function updateBasePie(data) {
        if (!(data && data.result)) {
            console.log("data is required!");
            return;
        }
        pieOptions.series[0].data = data.result.series_data;
        pieOptions.series[0].name = data.result.series_name;
        pieOptions.legend.data = data.result.legend_data;
        dashboard_pie.setOption(pieOptions); 
    };

    //处理websocket数据 
    function handlerWebSokcetData(data){
        console.log("仪表盘websokcet流 ");
        if(data.cmd == "dashboard"){    
            if(data.data && typeof data.data !== "object"){
                data.data = JSON.parse(data.data);
            }
            if(data.type === "pie"){
              updateBasePie(data.data);
            }	
            if(data.type === "bar"){
              updateBaseBar(data.data);
            }
        }
    } 

    // 注册给parent里面的回调方法
    parent.registerMethod(handlerWebSokcetData);
    Utils.ws({
        url: dashboardWebSocketUrl+"?"+ token_chart, //公安网正式
        onmessage: function(data){
            console.log("Utils.onmessage:",data);
            if(data.cmd == "dashboard"){    
                if(data.data && typeof data.data !== "object"){
                    data.data = JSON.parse(data.data);
                }
                if(data.type === "pie"){
                  updateBasePie(data.data);
                }	
                if(data.type === "bar"){
                  updateBaseBar(data.data);
                }
            }
        }
    });

    // /** 测试数据 */
    // var testBar = function(){
    //     var testBar = {
    //         result: {
    //             ng_user: "admin",
    //             user_code: "wangxinyu",
    //             series_data: [20,10,30,40,100],
    //             series_name: "测试数据",
    //             remark: "备注",
    //             id: "d16dc06bd87c457c805d271c86391522",
    //             create_date: {
    //                 date: 10,
    //                 hours: 8,
    //                 seconds: 0,
    //                 month: 6,
    //                 timezoneOffset: -480,
    //                 year: 117,
    //                 minutes: 0,
    //                 time: 1499644800000,
    //                 day: 1
    //             },
    //             series_type: "bar",
    //             app_code: "app",
    //             xAxis_data: ['a','b','c','d','e']
    //         },
    //         cmd: "dashboard",//仪表盘
    //         type: "bar",    //图类别，柱状图
    //         url: "dashboard/getInitDashboard"
    //     };
    //     var testPie = {
    //         result: {
    //             ng_user: "admin",
    //             user_code: "wangxinyu",
    //             series_data: [{value:225,name:'测试1'},{value:338,name:'测试2'}],
    //             series_name: "测试数据",
    //             remark: "备注",
    //             id: "d16dc06bd87c457c805d271c86391522",
    //             create_date: {
    //                 date: 10,
    //                 hours: 8,
    //                 seconds: 0,
    //                 month: 6,
    //                 timezoneOffset: -480,
    //                 year: 117,
    //                 minutes: 0,
    //                 time: 1499644800000,
    //                 day: 1
    //             },
    //             series_type: "bar",
    //             app_code: "app",
    //             legend_data: ['测试1','测试2']
    //         },
    //         cmd: "dashboard",//仪表盘
    //         type: "bar",    //图类别，柱状图
    //         url: "dashboard/getInitDashboard"
    //     };
    //     drawBaseBar(dashboard_bar, testBar);
    //     drawBasePie(dashboard_pie, testPie);
    // }();

}());