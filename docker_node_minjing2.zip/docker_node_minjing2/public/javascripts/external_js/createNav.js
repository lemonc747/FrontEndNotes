var parentDataArray;
var rootItemsJq = [];
var allSecondSortArr;
// my_token = "e6f5f17534f74db89c1048f4d3888888";
getSecondSort_Data();
//.获取所有的二级分类Id

 function getSecondSort_Data(){
// 	 "accessToken": "e6f5f17534f74db89c1048f4d3888888",
    XHSDK.ajax({
        url:uiURL+"/baseClassifyAction/dataListByMJ",
        type:"POST",
        data:'{"classifyType":'+ 0 +',"classifyLevel":'+ 2 +',"accessToken":"'+my_token+'"}',
        contentType:"application/json;charset=utf-8",
        dataType:"json",
        success:function(res){ 		
        	if(res.code == 0 || res.code == 200){
        		allSecondSortArr = res.data.result;
        		getAppNavBarAjax();
        	}else{
        		console.log(res.code,"错误码：：：");
        	}
        },
        error:function(msg){
            console.log("Error:",msg);
        }
    });
}

function getAppNavBarAjax(){
	clearRootMeumJq();
	rootSort = [];
	saveAjax = [];
	appNav = [];
	XHSDK.ajax({
		// url:"./json/getAppNavBar.json",       
		// type:"get",
		url:appserviceURL+"/front/app/getAppNavBar",
		type:"post",
		contentType: "application/json;",
		data:'{"accessToken":"'+my_token+'"}',
		dataType:"json",
		success:function(res){
			// console.log(res);
			if(res.code == 0 || res.code == 200){
				if(res.data && res.data.length > 0){
					getAppNavData(res.data);
				}
			}
		},
		error:function(msg){
			console.log("getAppNavBar Error:",msg);
		}
	});
}

var rootSort = [];
// {
// appTypeName: "应用名称"
// appTypeId:"分类Id"
// }
var appNav = [];

//处理数据
function getAppNavData(data){
	for(var i = 0; i<data.length; i++){
		if(!ifExistRootNav(data[i])){
			var obj = getSecondBarName(data[i]);
			if(!!obj){
				rootSort.push({appClassify:data[i].appClassify,appTypeName:obj.classifyName,imgPath:obj.classifyThumb});
			}else{
								
			}
		}
	}
	sortByAppId();
	//console.log(rootSort);
	var navItems;
	saveAjax = [];
	for(var i = 0; i < rootSort.length; i ++ ){
		 navItems = [];
		for(var j = 0; j< data.length; j++){
			if(rootSort[i].appClassify == data[j].appClassify){
				// console.log(rootSort[i].appTypeId);
				navItems.push(data[j]);
			}
		}
		saveAjax.push(navItems);
		///console.log(saveAjax);
	}
	//console.log(rootSort,saveAjax);
	for(var i = 0; i < rootSort.length; i ++ ){
		createbroadside(rootSort[i],i);
	}
}

function getSecondBarName(data){
	for (var i = 0; i < allSecondSortArr.length; i++) {
		if(data.appClassify == allSecondSortArr[i].classifyId){
			return allSecondSortArr[i];
		}
	}
	return null;
}

function sortByAppId(){
	for(var i = 0 ; i< rootSort.length;i++){
		for(var j = 0 ; j< rootSort.length-1;j++){
			if(rootSort[i].appTypeId < rootSort[j].appTypeId){
				var tem = rootSort[j];
				rootSort[j] = rootSort[i];
				rootSort[i] = tem;
			}
		}
	}
	//排序后
	//console.log(rootSort);
}

function ifExistRootNav(dataItem){
	for(var i = 0 ; i < rootSort.length; i++){
		if(dataItem.appClassify == rootSort[i].appClassify){
			return true;
		}
	}
	return false;
}

//旧接口
// function testAjax(appID){
//     my_token = GetQueryString("access_token");
//     //console.log(appID);    
// 	$.ajax({            			
// 		url:postUrl+"/AppTypeService/apptype/getAppsByTypeLevel",
// 		//url:"http://172.28.0.56:9106/AppTypeService/apptype/getAppsByTypeLevel",
// 		type:"POST",
// // 		url:"./json/nav.json",            			
// // 		type:"get",
//         contentType: "application/json;",
//         data:'{"level":2,"appDic":'+appID+',"userCode":"'+my_token+'"}',
//         dataType:"json",
//         success:function(result){
//             if(result.code==0){
//                 $.each(result.data,function(index,item){
//                 	getData(result.data[index]);
//       				createbroadside(result.data[index],index);
//                 });
//             }
//         },
//         error:function(msg){
//             console.log("getAppTypeList Error:",msg);
//         }
// 	})                                                              
// }



//清理侧边items
function clearRootMeumJq(){
	for(var i =0 ; i< rootItemsJq.length;i++){
		rootItemsJq[i].remove();
	}
	rootItemsJq = [];
}


//创建侧边栏
function createbroadside(data,index){
	
//	console.log(data,index);
//	console.log(saveAjax[index]);
//	console.log(data);
	//data的格式 
//	 {
//          "appTypeId": 2,
//          "name": "管理考核",
//          "parentId": 1,
//          "imgPath": "images/collect.png",
//          "description": "",
//          "listOrder": 2
//    },
	
	var li = $("<li>").appendTo($(".mainNav")).css({"positon":"absolute", "cursor": "pointer"});
	li.data("info",saveAjax[index]);
	var a = $("<a>").appendTo(li).data("info",saveAjax[index]);
	var p = $("<p>").appendTo(a).data("info",saveAjax[index]);
	//var img = $("<img>").attr("src",postUrl+data.imgPath).appendTo(p).data("info",saveAjax[index]);
	var textP = $("<p>").addClass("navText").text(data.appTypeName).appendTo(a).data("info",saveAjax[index]);
	//console.log("appName",data);
	rootItemsJq.push(li);
	li.mouseleave(function(e){
		$(e.target).find(".broadside").remove();
	});
	
//	a.mouseout(function(e){
//		$(e.target).find(".broadside").remove();
//	});
	
	li.mouseenter(function(e){
		getSecondMeun($(e.target),$(e.target).data("info"));
	});
}

var lastBoderSideDiv;

var saveAjax = [];
var lastBoderSideDiv = [];

function getSecondMeun(rootJq,data){
	if(lastBoderSideDiv.length != 0){
		for(var i =0; i<lastBoderSideDiv.length; i++){
			lastBoderSideDiv[i].remove();
		}
		lastBoderSideDiv = [];
	}
	var floatDiv = $("<div>").addClass("broadside").appendTo(rootJq);
	if(!data){
		return;
	}
	lastBoderSideDiv.push(floatDiv);
	for(var i = 0 ; i<data.length;i++){
		var item = createItem(data[i]);
		item.appendTo(floatDiv).data("info",data[i]);
	}
	
	//但只有一个菜单项目时调用
	if(data.length == 1){
		floatDiv.css({"top":"0px"})
	}
	
	floatDiv.mouseleave(function(e){
		if($(e.target).hasClass("broadside")){
			$(e.target).remove();
		}else{
			$(e.target).parent().remove();
		}
	});
}

function createItem(data){
	var li = $("<li>").data("info",data).addClass("broadsideItem").data("info",data);
	var img = $("<img>").attr("src",data.appIcon).appendTo(li).data("info",data);
	var textP = $("<div>").text(data.appName).appendTo(li).data("info",data);
	
	li.click(function(e){
	//打开一个iframe	
	//console.log($(e.target).data("info"));
		var appdata = $(e.target).data("info");
		//console.log(appdata)
		XHSDK.ajax({
			// url:"./json/getAppNavBar.json",       
			// type:"get",
			url:appserviceURL+"/front/app/saveUserAppUse",
			type:"post",
			contentType: "application/json;",
			data:'{"accessToken":"'+my_token+'","appId":"'+appdata.appId+'"}',
			dataType:"json",
			success:function(res){
				//console.log(res);
			},
			error:function(msg){
				console.log("getAppNavBar Error:",msg);
			}
		});
		// changePage(appdata.appName,appdata.appUrl+"?access_token="+my_token);
		changePage(appdata.appName,appdata.appUrl);
		$(e.target).parent().remove();
	});
	
	li.mouseenter(function(e){
		$(e.target).parent("").addClass("active");
	});
	return li;
}