        //提供关闭拖动操作函数
        var closeTrag;
        var getModuleData;
        $(function(){
            var aSort = [],bSort = [],cSort = [];
            $flag=1;
            var not_add_nub;
            var add_nub
	       // console.log(userData);

            var delArr;
            getModuleData = function(data){
                delArr = data;
            }
            $(".leftColumn").hide();
            //初始化各参数
            var clientWidth = document.body.clientWidth;
            var cssHideStr = "0 0px 0 230px";
            var cssShowStr = "0 325px 0 230px";
            if(clientWidth<=1280){
                //解决窄屏不匹配
                $(".customize_list").css({"position":"absolute","left":"-90px"});
                cssHideStr = "0 0px 0 140px";
                cssShowStr = "0 325px 0 140px";
            }

            closeTrag = closeTragOpr;

            //关闭拖动操作
            function closeTragOpr(){
                saveLayoutInfo();
                $(".bottomContent").css({"padding": cssHideStr}); 
                $(".leftColumn").hide();
                $(".title").attr("style","display:none");
                $(".move").attr("style","display:none");
                $(".customize_list").hide();
                $(".im_Div").attr("style","display:block"); 
                $(".beOnDuty").attr("style","display:block"); 
                $(".displayNone").css("display","none");
                $flag=1;
            }

            //开启拖动操作
            function openTragOpr(){
                $(".bottomContent").css({"padding":cssShowStr}); 
                $(".leftColumn").show();
                $(".title").attr("style","display:block");
                $(".move").attr("style","display:block"); 
                $(".customize_list").show(); 
                $(".im_Div").attr("style","display:none"); 
                $(".beOnDuty").attr("style","display:none"); 
                $(".displayNone").css("display","block");
                $flag=0;
            }

            // 开关按钮
            $(".customize").click(function(){
                if(!isInMainPage){
                    layer.msg("请切换到主页进行拖动操作！！");
                    return;
                }
                if($flag==0){
                    closeTragOpr();
                }else if($flag==1){
                    openTragOpr();
                }
            })
               Sortable.create(document.getElementById ("parentBox"),{
                    handle:".title",
                    disabled:false,
                    ondrop:onDropCallBack
                    
                })
                Sortable.create(document.getElementById("iframe_item_two"),{
                    handle:".move",
                    group:"iframeChild",
                    disabled:false,
                    ondrop:onDropCallBack
            
                })
                Sortable.create(document.getElementById("iframe_item_thr"),{
                    handle:".move",
                    group:"iframeChild",
                    disabled:false,
                    ondrop:onDropCallBack
                }) 
                 function onDropCallBack(el){
                    //做一个延时操作 为了让拖拽插件生成的div销毁
                    setTimeout(function(){
                        getSortInfo();
                    },500);
                }
            
                function getSortInfo(){
                    var bSortArr = [];
                    var sSortArr = [];
                    var liArr = $("#parentBox").find(".iframe_child");
                    for (var i = 0; i < liArr.length; i++) {
                        bSortArr.push($(liArr[i]).attr("sortId"));
                        var items = $(liArr[i]).find(".iframe_item");
                        for (var j = 0; j < items.length; j++) {
                            for (var x = 0; x < $(items[j]).children("div[sortId]").length; x++) {
                                var it = $(items[j]).children("div[sortId]")[x];
    //                          console.log(it);
                                sSortArr.push($(it).attr("sortId"));    
                            }
                        }
                    }
                    // sessionStorage.setItem("bSortArr",bSortArr); 
                    // sessionStorage.setItem("sSortArr",sSortArr);
                    aSort = bSortArr;
                    bSort = sSortArr;
                }

            function saveLayoutInfo(){
                getSortInfo();
                var temArr = [];
                temArr.push(aSort);
                temArr.push(bSort);
                temArr.push(cSort);
                var layoutData = {};
                layoutData.tokenStr = my_token;
                layoutData.layout = JSON.stringify(temArr);
                layoutData = JSON.stringify(layoutData);
                XHSDK.ajax({
                    url: userserviceURL+"/user/setLayout",
                    type: "POST",
                    contentType: "application/json;charset=utf-8",
                    data:layoutData,
                    dataType: "json",
                    success: function(result) {
                        console.log("layout:",result)
                        if(result.code==200){
                            
                        }else{
                            layer.msg("保存布局失败！！",{icon:2});
                        }
                    },
                    error: function(msg) {
                        console.log("Error:" + msg);
                    }
                });
            }

            //左侧添加栏隐藏               
            $(".add").parent().parent().hide();
            $(".delete").click(function(){
                var _delete =$(this);
                operate(_delete,"att",".not_added_list_li","att","[at]","at","del");
                // fit(_delete,"att","[at]","at","del");
                add_nub=$(".added_list_li:visible").length;
                $("#add_nub").html(add_nub);
                var not_add_nub =$(".not_added_list_li:visible").length;
                $("#not_add_nub").html(not_add_nub);
            })
            $(".delete_div").click(function(){
                var _delete_div =$(this);
                operate(_delete_div,"at",".added_list_li","att",".not_added_list_li","att","del_div");
                // fit(_delete_div,"att","[at]","at","del_div");
                not_add_nub =$(".not_added_list_li:visible").length;
                $("#not_add_nub").html(not_add_nub);
                add_nub=$(".added_list_li:visible").length;
                $("#add_nub").html(add_nub);
            })  
            $(".add").click(function(){
                var _add =$(this);
                operate(_add,"att",".added_list_li","att","[at]","at","add");
                // fit(_add,"att","[at]","at","add");
                not_add_nub =$(".not_added_list_li:visible").length;
                $("#not_add_nub").html(not_add_nub);
                add_nub=$(".added_list_li:visible").length;
                $("#add_nub").html(add_nub);
            })  

            //控制添加删除模块
            function operate(this_,this_list_attr,list_one,list_one_attr,list_two,list_two_attr,effect){
                if(this_list_attr == "att"){
                    var _this_attr=$(this_).parent().parent().attr(this_list_attr);
                    $(this_).parent().parent().hide();
                }else if(this_list_attr == "at"){
                    var _this_attr=$(this_).parent().next().attr(this_list_attr);
                    $(this_).parent().next().hide();
                }
                for(var i=0;i<$(list_one).length;i++){
                    var _one_attr=$(list_one).eq(i).attr(list_one_attr);
                    if(_this_attr==_one_attr&&effect=="del"||_this_attr==_one_attr&&effect=="add"){
                        $(list_one).eq(i).show();
                    }else if(_this_attr==_one_attr&&effect=="del_div"){
                        $(list_one).eq(i).hide();
                        delArr.push($(list_one).eq(i).attr("att"));   
                    }
                }
                for(var j=0;j<$(list_two).length;j++){
                    var _two_attr=$(list_two).eq(j).attr(list_two_attr);
                    if(_this_attr==_two_attr&&effect=="del_div"||_this_attr==_two_attr&&effect=="add"){
                        $(list_two).eq(j).show(); 
                        removeArrVal(delArr,$(list_two).eq(j).attr("at"));
                    }else if(_this_attr==_two_attr&&effect=="del"){
                        $(list_two).eq(j).hide();
                        delArr.push($(list_two).eq(j).attr("at"));  
                    }
                } 
                if($(".iframe_item").eq(0).children().eq(0).children().eq(1).css("display") == "none" && $(".iframe_item").eq(0).children().eq(1).children().eq(1).css("display") == "none"){
                    $("#iframe_item_two").parent().css("display","none");
                }else if($(".iframe_item").eq(0).children().eq(0).children().eq(1).css("display") == "block" || $(".iframe_item").eq(0).children().eq(1).children().eq(1).css("display") == "block"){
                    $("#iframe_item_two").parent().css("display","block");
                }
                if($(".iframe_item").eq(1).children().eq(0).children().eq(1).css("display") == "none" && $(".iframe_item").eq(1).children().eq(1).children().eq(1).css("display") == "none"){
                    $("#iframe_item_thr").parent().css("display","none");
                }else if($(".iframe_item").eq(0).children().eq(0).children().eq(1).css("display") == "block" || $(".iframe_item").eq(0).children().eq(1).children().eq(1).css("display") == "block"){
                    $("#iframe_item_thr").parent().css("display","block");
                }
                // localStorage.setItem("delArr",JSON.stringify(delArr)); 
                cSort = delArr;
                //console.log(saveLayoutArr);
            }
            // function fit(this_,this_list_attr,list,list_attr,effect){
            //     var _this_attr=$(this_).parent().parent().attr(this_list_attr);
            //     if(effect=="del_div"){
            //         // $(this_).parent().parent().parent().children().css("width","100%");
            //     }
            //     if(effect=="add"){
            //         for(var i=0;i<$(list).length;i++){
            //             var _one_attr=$(list).eq(i).attr(list_attr);
            //             if(_this_attr==_one_attr&&$(list).eq(i).attr("at")!="Calendar"){
            //                 // $(list).eq(i).parent().children().css("width","50%");
            //             }
            //             if($(list).eq(i).parent().children().css("display")=="none"){
            //                 // $(list).eq(i).parent().children().css("width","100%");
            //             }
            //         } 
            //     }       
            //     if(effect=="del"){
            //         for(var i=0;i<$(list).length;i++){
            //             var _one_attr=$(list).eq(i).attr(list_attr);
            //             if(_this_attr==_one_attr){
            //                 // $(list).eq(i).parent().children().css("width","100%");
            //             }
            //         }      
            //     } 

            // }
            
 
        }) 
        function removeArrVal(arr,val){
            for(var i = 0;i < arr.length;i++ ){
               if(arr[i] == val){
                   arr.splice(i,1);
                   break;
               }
            }
        }