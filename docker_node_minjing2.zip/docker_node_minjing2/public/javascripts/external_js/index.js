//放最前面 获取到    不能放在 windows .load 里  会比其他的后执行（问题查找中）
var my_token;
var userData;
//
var projectName = '/szga/docker_node_minjing';

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}

my_token = GetQueryString("access_token") || sessionStorage.getItem('access_token');
if(my_token == "" || !my_token){
    window.location.href = 'http://'+window.location.host+loginPage;
}
var  XHSDK = new Xhsdk("1884c5d400bc416c8351a0cc4245dcac","25D6805385618DCF41F67BCDC4287E57");
XHSDK.setGetaWayUrl(serviceBaseUrl);
XHSDK.setToken(my_token);
XHSDK.setReqType("tymh");
//获取默认的模块界面 结合 dargDiv.js
//获取本地存储的数据
// var bSortArr = sessionStorage.getItem("bSortArr");
// var sSortArr = sessionStorage.getItem("sSortArr");
// var delArr = JSON.parse(localStorage.getItem("delArr"));
// var moveParentArr = JSON.parse(localStorage.getItem("moveParentArr"));
//控制拖拽并删除某个块后旁边快自动100%
// $(function(){
//     if(!!moveParentArr){
// 		if(moveParentArr[0] != moveParentArr[1]){
// 			if(moveParentArr[0] == 'iframe_item_two' || moveParentArr[1] == 'iframe_item_two'){
// 				console.log($("#iframe_item_two").children().eq(0));
// 				console.log($("#iframe_item_two").children().eq(1));
// 				if($("#iframe_item_two").children().eq(0).css('display') == 'none'){
// 					$("#iframe_item_two").children().eq(1).css('width',"100%");
// 				}else if($("#iframe_item_two").children().eq(1).css('display') == 'none'){
// 					$("#iframe_item_two").children().eq(0).css('width',"100%");
// 				}
// 			}
// 			if(moveParentArr[0] == 'iframe_item_thr' || moveParentArr[1] == 'iframe_item_thr'){
// 				console.log($("#iframe_item_thr").children().eq(0));
// 				console.log($("#iframe_item_thr").children().eq(1));
// 				if($("#iframe_item_thr").children().eq(0).css('display') == 'none'){
// 					$("#iframe_item_thr").children().eq(1).css('width',"100%");
// 				}else if($("#iframe_item_thr").children().eq(1).css('display') == 'none'){
// 					$("#iframe_item_thr").children().eq(0).css('width',"100%");
// 				}
// 			}
// 		}
// 	}
// })
//

/** todo 布局函数bug，移动jquery dom对象导致绑定事件丢失
 * bug：$("#parentBox").html(""): 移动dom时事件丢失
 */
function getSelfLayOut(){
    XHSDK.ajax({
        url:userserviceURL+"/user/getLayout",
        type:"post",
        data: '{"tokenStr":"'+my_token+'"}',
        contentType: "application/json;charset=utf-8",
        dataType:"json",
        success:function(res){
            if(res.code == 200){
                var arrStr = res.data.layout;
                console.log("arrStr:",arrStr);
                if(!!!arrStr)
                    return;
                var layoutArr = JSON.parse(arrStr);
                //从网络获取
                var bSortArr = layoutArr[0];
                var sSortArr =  layoutArr[1];
                var delArr =  layoutArr[2];
                getModuleData(delArr);
                if(delArr.length != 0){
                    console.log(delArr);
                    for(var i = 0;i < delArr.length;i++){
                        console.log(delArr[i]);
                        for(var j = 0;j < $(".added_list_li").length;j++){
                            // console.log($(".added_list_li").eq(j).attr("att"));
                            if(delArr[i] == $(".added_list_li").eq(j).attr("att")){
                                $(".added_list_li").eq(j).css("display","none");
                                $(".not_added_list_li").eq(j).css("display","block");
                            }
                            if(delArr[i] == $(".iframe_item_rl").attr("at")){
                                $(".added_list_li").eq(2).css("display","none");
                                $(".not_added_list_li").eq(2).css("display","block");
                            }
                        }
                        if($(".iframe_item").eq(0).children().eq(0).children().eq(1).attr("at") == delArr[i]){
                            $(".iframe_item").eq(0).children().eq(0).children().eq(1).css("display","none");
                            // console.log($(".iframe_item").eq(0).children().eq(0).css("display"));
                        }else if($(".iframe_item").eq(1).children().eq(0).children().eq(1).attr("at") == delArr[i]){
                            $(".iframe_item").eq(1).children().eq(0).children().eq(1).css("display","none");
                            // console.log($(".iframe_item").eq(0).children().eq(0).css("display"));
                        }else if($(".iframe_item").eq(0).children().eq(1).children().eq(1).attr("at") == delArr[i]){
                            $(".iframe_item").eq(0).children().eq(1).children().eq(1).css("display","none");
                            // console.log($(".iframe_item").eq(0).children().eq(0).css("display"));
                        }else if($(".iframe_item").eq(1).children().eq(1).children().eq(1).attr("at") == delArr[i]){
                            $(".iframe_item").eq(1).children().eq(1).children().eq(1).css("display","none");
                            // console.log($(".iframe_item").eq(0).children().eq(0).css("display"));
                        }
                        if($(".iframe_item_rl").attr("at") == delArr[i]){
                            // $(".iframe_item_rl").css("display","none");
                            $(".iframe_item_rl").parent().css("display","none");
                        }
                        // console.log( $("#iframe_item_two").parent());
                        if($(".iframe_item").eq(0).children().eq(0).children().eq(1).css("display") == "none" && $(".iframe_item").eq(0).children().eq(1).children().eq(1).css("display") == "none"){
                            $("#iframe_item_two").parent().css("display","none");
                            // console.log( $("#iframe_item_two").parent());
                        }
                        if($(".iframe_item").eq(1).children().eq(0).children().eq(1).css("display") == "none" && $(".iframe_item").eq(1).children().eq(1).children().eq(1).css("display") == "none"){
                            $("#iframe_item_thr").parent().css("display","none");
                            // console.log($("#iframe_item_thr").parent());
                        }
                    }
                }
                if(!!bSortArr.length != 0 && !!sSortArr.length !=0){
                    //console.log(bSortArr,sSortArr)
                    var db = $("#db");
                    var ph = $("#ph");
                    var xw = $("#xw");
                    var tz = $("#tz");
                    //old @20180322 绑定event丢失,原理不清
                    var iframe1 = $("#sortId1");
                    var iframe2 = $("#sortId2");
                    var iframe3 = $("#sortId3");
                    // $("#iframe_item_two").html("");
                    // $("#iframe_item_thr").html("");
                    // $("#parentBox").html("");
                    // //new
                    // $("#iframe_item_two").html("");
                    // $("#iframe_item_thr").html("");
                    // var iframe1 = $("#sortId1").clone(true, true);
                    // var iframe2 = $("#sortId2").clone(true, true);
                    // var iframe3 = $("#sortId3").clone(true, true);
                    // $("#parentBox").html("");
                    var iframeArr = [];
                    var haveLitteIframeArr = [];
                    for (var i = 0; i < bSortArr.length; i++) {
                        switch (bSortArr[i]){
                            case "1":
                                iframe1.appendTo($("#parentBox"));
                                iframeArr.push(iframe1);
                                haveLitteIframeArr.push(iframe1);
                                break;
                            case "2":
                                iframe2.appendTo($("#parentBox"));
                                iframeArr.push(iframe2);
                                haveLitteIframeArr.push(iframe2);
                                break;
                            case "3":
                                iframe3.appendTo($("#parentBox"));
                                iframeArr.push(iframe3);
                                break;
                            default:
                                break;
                        }
                    }
                    getAndappendtoJq(sSortArr[0],haveLitteIframeArr[0]);
                    getAndappendtoJq(sSortArr[0],haveLitteIframeArr[0]);
                    getAndappendtoJq(sSortArr[0],haveLitteIframeArr[1]);
                    getAndappendtoJq(sSortArr[0],haveLitteIframeArr[1]);

                    function getAndappendtoJq(arrItem,iframe){
                        switch (arrItem){
                            case "db":
                                db.appendTo($(iframe).find(".iframe_item"));
                                break;
                            case "ph":
                                ph.appendTo($(iframe).find(".iframe_item"));
                                break;
                            case "xw":
                                xw.appendTo($(iframe).find(".iframe_item"));
                                break;
                            case "tz":
                                tz.appendTo($(iframe).find(".iframe_item"));
                                break;
                            default:
                                break;
                        }
                        sSortArr = removeIndex(sSortArr,arrItem);
                    }
                    function removeIndex(arr,str){
                        var newArr = [];
                        for (var i = 0; i < arr.length; i++) {
                            if(arr[i]  != str){
                                newArr.push(arr[i]);
                            }
                        }

                        return newArr;
                    }
                }
            }
        },error:function(error){
            console.log("error:",error);
        }
    })

}


/********************************* websocket ********************************/
// var websocket = null;

// if('WebSocket' in window){
//     websocket = new WebSocket(webSocketURL + "/websocket?"+my_token);
// }
// else{
//     console.log('Not support websocket')
// }

// websocket.onopen = function(){
// 	console.log("websocket.open:")
// }

// websocket.onmessage = function(event){
// 	console.log("websocket.onmessage:"+event.data);
// 	if(event.data.indexOf("有新连接加入") != -1)  {
//         return;
// 	}
// 	dowebsocketDataEvent(event);
// }

// websocket.onerror = function(){
//     console.log("error")
// }

// websocket.onclose = function(){
//     websocket.close();
// }

/**加入心跳包机制 */
var ws;//websocket实例
var lockReconnect = false;//避免重复连接
function createWebSocket(url) {
    try {
        ws = new WebSocket(url);
        initEventHandle(url);
    } catch (e) {
        reconnect(url);
    }
}

function initEventHandle(wsUrl) {
    ws.onclose = function () {
        reconnect(wsUrl);
    };
    ws.onerror = function () {
        reconnect(wsUrl);
    };
    ws.onopen = function () {
        //心跳检测重置
        heartCheck.reset().start();
    };
    ws.onmessage = function (event) {
        //如果获取到消息，心跳检测重置
        //拿到任何消息都说明当前连接是正常的
        heartCheck.reset().start();
        try {
            //数据处理
            dowebsocketDataEvent(event);
        } catch (error) {
            console.log(event.data);
            return;
        }
    }
}

/**重新连接 */
function reconnect(url) {
    if(lockReconnect) return;
    lockReconnect = true;
    //没连接上会一直重连，设置延迟避免请求过多
    setTimeout(function () {
        createWebSocket(url);
        lockReconnect = false;
    }, 2000);
}

//心跳检测
var heartCheck = {
    timeout: 30000,//60秒
    timeoutObj: null,
    reset: function(){
        clearTimeout(this.timeoutObj);
        return this;
    },
    start: function(){
        this.timeoutObj = setTimeout(function(){
            //这里发送一个心跳，后端收到后，返回一个心跳消息，
            //onmessage拿到返回的心跳就说明连接正常
            ws.send("HeartBeat");
        }, this.timeout)
    }
}

//创建websocket链接
createWebSocket(webSocketURL + "/websocket?"+my_token);

/**
 * 处理websocket的数据
 */
function dowebsocketDataEvent(event){
    var my_event = eval("WS:(" + event.data + ")");
    //本单位消息通知
    if(my_event.cmd == "noticeService")
    {
        var tmp = $(".index_notice > span").text();
        if(tmp==""){
            tmp=0;
        }
        $(".index_notice").html('<img alt=""><span class="index_span">'+(parseInt(tmp)+parseInt(1))+'</span>');
        var a = findIframeByName();//返回值  null object
    }

    //
    if(my_event.cmd == "userMsgCount")
    {
        console.log(my_event);
    }

    //日历
    if(my_event.cmd == 'calendarService'){
        // debugger;
        //显示弹窗
        // console.log(my_event);
        var newTask = my_event;
        try{
            // newTask = JSON.parse(newTask);
            if(newTask && newTask.data && typeof newTask.data !== "object"){
                newTask.data = JSON.parse(newTask.data);
                if(newTask.data && newTask.data.schedule && typeof newTask.data.schedule !== "object"){
                    newTask.data.schedule = JSON.parse(newTask.data.schedule);
                }
            }
            var scheId = newTask.data.schedule.scheId;
            var $calendar = $(".easyui-fullCalendar");
            $calendar.data("newScheID", scheId);
            // if("Notification" in window){
            // 	Notification.requestPermission().then(function(){var notification = new Notification("您有一条新的日程推送消息",{body: newTask.data.sendContent})})
            // }
            //bug: 直接刷新页面，querySchedule查不到新的那条记录？在点击确认后再刷新日历
            layer.confirm("请查看<strong>"+newTask.data.sendContent+"</strong>的日程详情。",
                {title:'您有一条新的日程推送消息'
                }, function(index){
                    getMonthTask();
                    $calendar.data("newScheID", undefined);
                    layer.close(index);
                }, function(index){
                    layer.close(index);
                });
        }catch(e){
            console.log(e.message);
        }
    }

    //仪表盘
    if(my_event.cmd == 'dashboard'){
        console.log(my_event);
        if(!!dashboardHandlerMethod){
            dashboardHandlerMethod(my_event);
        }
    }
}

//处理仪表盘的函数
var dashboardHandlerMethod;
/**注册方法 */
function registerMethod(method){
    if(!!method){
        dashboardHandlerMethod = method;
    }
}

//加载页面
$(".iframe_item_rl").load("calendar.html",function(){
    $(".db").load("todoList.html",function(){
        $(".ph").load("rankBoard.html",function(){
            $(".xw").load("news.html",function(){
                $(".tz").load("notice.html");
            });
        });
    });
});

var searchIndex = 1;
//搜索
function searchByContent(){
    var searchWordKey =  $("#index_search").val();
    var urlStr = "?access_token="+my_token;
    // my_token = GetQueryString("access_token");
    // search_val = GetQueryString("value");

    changePage("搜索结果","search.html");

    //调用搜索结果iframe的方法
    var childIframeArr = $("#iframeHtml").children();
    var lastUrl = "search.html"+urlStr;
    for(var i = 0; i<childIframeArr.length; i++ ){
        if($(childIframeArr[i]).attr("src") == lastUrl){
            if(!!childIframeArr[i].contentWindow.searchInfo){
                childIframeArr[i].contentWindow.searchInfo();
            }
        }
    }
}

//原来的
// $(".iframe_item_rl").load("calendar.html");
// $(".db").load("todoList.html");
// $(".ph").load("rankBoard.html");
// $(".xw").load("news.html");
// $(".tz").load("notice.html");
// $(".im_Div").load('index_communicate.html');
// $(".beOnDuty").load('onDuty.html');

window.onload = function(){
    //本地存储的皮肤
    var localSkinX = localStorage.getItem('isWhiteSkin');
    // console.log("本地",localSkinX);
    if(localSkinX != null){
        if(localSkinX == "true"){
            // console.log("-------true");
            isWhiteSkin = true;
        }else{
            // console.log("------------false");
            isWhiteSkin = false ;
        }
    }
    //调用换肤操作
    changeIndexBg(isWhiteSkin);
    $(".index_exit").click(function(){
      //window.location.href = ssoLoginURL + "/logout.html?token="+my_token+"&fromUrl="+window.location.href;
      // window.location.href = 'http://'+window.location.host+"/login.html";
      window.location.href = 'http://'+window.location.host+loginPage;
    });

    //获取用户数据内容
    XHSDK.ajax({
        url:userserviceURL + "/user/getUserInfo",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        data: '{"tokenStr":"'+my_token+'"}',
        dataType: "json",
        success: function(result) {
            if(result.code== 200){
                userData = result.data;
                //console.log("用户信息",userData);
                //布局
                getSelfLayOut();
                //是否显示仪表盘
                if(parent.userData.userStatus == "在职领导" || parent.userData.userCode =="zhangxl"){
                    $(".index_chart").show();
                }
                $(".infoTxt").html("<p>"+result.data.userName+"</p>");
            }
            else if(result.code == 603){
                layer.confirm('登录超时'+result.cmd, {
                    btn: ['确定'] //按钮
                }, function(){
                    // window.location.href=ssoLoginURL + "/login.html?access_token="+ my_token;
                    window.location.href = 'http://'+window.location.host+loginPage;
                });
            }
            else{
                console.log("Error:result.code=",result.code);
            }
        },
        error: function(msg) {
            console.log("Error:" + msg);
        }
    });
    var sumCount = 0;
    //获取未读消息条数
    // $.ajax({
    //     url:"http://172.19.255.93:8082/MessageService/service/message/getMsgAppService",
    //     type: "POST",
    //     contentType: "application/json;charset=utf-8",
    //     data: '{"userCode":"'+my_token+'"}',
    //     dataType: "json",
    //     success: function(result) {
    //         if(result.code==0){

    //             for(var i=0;i<result.data.length;i++){
    //                 sumCount += result.data[i].count;
    //                 //console.log(sumCount)
    //             }

    //             if(sumCount == 0){
    //                 $(".index_notice > span").remove();
    //             }
    //             else{
    //                 $(".index_notice > span").text(sumCount);
    //             }
    //         }else if(result.code == 603){
    //             layer.confirm('登录超时'+result.cmd, {
    //                 btn: ['确定'] //按钮
    //             }, function(){
    //                 window.location.href="http://172.19.255.102:88/login.html?access_token="+ my_token;
    //             });
    //         }else{
    //             console.log("Error:result.code=",result.code);
    //         }
    //     },
    //     error: function(msg) {
    //         console.log("Error:" + msg);
    //     }
    // });

    //本单位通知未读统计
    XHSDK.ajax({
        url: mainNoticeServiceURL + "/notice/getReceiveCountReport",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        data: '{"accessToken": "'+my_token+'","type":1}',
        dataType: "json",
        success: function (result) {
            if(result.code==0){
                sumCount += result.data.receiveUnReadCount;
                if(sumCount == 0){
                    $(".index_notice").html('<img alt=""><span ></span>');
                }
                else{
                    $(".index_notice").html('<img alt=""><span class="index_span">'+(sumCount)+'</span>');
                }
            }else if(result.code == 603){
                layer.confirm('登录超时'+result.cmd, {
                    btn: ['确定'] //按钮
                }, function(){
                    // window.location.href=ssoLoginURL + "/login.html?access_token="+ my_token;
                    window.location.href = 'http://'+window.location.host+loginPage;
                });
            }
            else{
                console.log("Error:result.code=",result.code);
            }
        },
        error: function (msg) {
            console.log("Error:" + msg);
        }
    });
};

$(".close").click(function() {
    $(this).parent("div").hide();
});

/**
 * id  */
//
var iframeHtmlArr = [
//	{
//		name:"应用中心",
//		src:"myApp.html",
//		ifameJq:null,
//		tabJq:null
//	}
];

//关闭全部
function closeAll(){
    for(var i = 0; i< iframeHtmlArr.length; i++){
        $(iframeHtmlArr[i].ifameJq).remove();
        $(iframeHtmlArr[i].tabJq).remove();
    }
    iframeHtmlArr = [];
    //打开首页
    showMainPage();
}

function refreshIframe(name){
    var ifameTep = findIframeByName(name);
    if(ifameTep==null){
        return ;
    }
    var src = $(ifameTep).attr("src");
    $(ifameTep).attr("src",src).ready();

}

function findIframeByName(name){
    for(var i = 0; i< iframeHtmlArr.length; i++){
        if(iframeHtmlArr[i].name == name){
            return iframeHtmlArr[i].ifameJq;
        }
    }
    return null;
}
//是否当前在主页
var isInMainPage = true;
//点击首页
function showMainPage(){
    isInMainPage = true;
    //隐藏Iframe容器
    $("#iframeHtml").hide();
    //显示主页
    $(".iframeBox").show();
    //取消其他的高亮
    cancelTabLight();
    $("#myApp").addClass("tab_active");
}



function changePage(tabname,srcStr,param,func) {
    isInMainPage = false;
    window.scrollTo(0,0);
    //console.log("ff");
    //隐藏主页
    $(".iframeBox").hide();
    //显示iframe容器
    $("#iframeHtml").show();
    //隐藏其他的iframe
    for(var i = 0 ; i <iframeHtmlArr.length; i++){
        $(iframeHtmlArr[i].ifameJq).hide();
    }
    if(!ifHaveCreate(srcStr)){
        var newIframe = createNewIframe(srcStr);
        var newTabItem = creteNewTab(tabname);
        newIframe.show();
        //取消其他的高亮
        cancelTabLight();
        //高亮
        newTabItem.addClass("tab_active");
        var iframeData = {
            name:tabname,
            src:srcStr,
            ifameJq:newIframe,
            tabJq:newTabItem
        }
        //保存数据在tab
        iframeData.tabJq.data('data',iframeData);
        iframeHtmlArr.push(iframeData);
    }
}

//取消其他的高亮
function cancelTabLight(){
    for(var i = 0 ; i <iframeHtmlArr.length; i++){
        $(iframeHtmlArr[i].tabJq).removeClass("tab_active");
    }
    $("#myApp").removeClass("tab_active");
}

function ifHaveCreate(srcStr){
    for(var i = 0 ; i <iframeHtmlArr.length; i++){
        if(srcStr == iframeHtmlArr[i].src){
            $(iframeHtmlArr[i].ifameJq).show();
            //取消其他的高亮
            cancelTabLight();
            //点亮tab
            $(iframeHtmlArr[i].tabJq).addClass("tab_active")
            return true;
        }
    }
    return false;
}

//点亮数组中的一个
function showIndexiframe(index){
    // closeTrag();
    // isInMainPage = false;
    //隐藏主页
    $(".iframeBox").hide();
    //显示iframe容器
    $("#iframeHtml").show();
    //隐藏其他的iframe
    for(var i = 0 ; i <iframeHtmlArr.length; i++){
        $(iframeHtmlArr[i].ifameJq).hide();
    }
    // console.log(iframeHtmlArr,index);
    $(iframeHtmlArr[index].ifameJq).show();
    //取消其他的高亮
    cancelTabLight();
    //点亮tab
    $(iframeHtmlArr[index].tabJq).addClass("tab_active")
}

function creteNewTab(tabName){
    // console.log("打开tab");
    // closeTrag();
    // isInMainPage = false;
    var tabItem = $("<li>").addClass("seeNow").appendTo($(".seeNavCon"));
    var span = $("<span>").text(tabName).appendTo(tabItem);
    var spanRemove = $("<span>").text("×").appendTo(tabItem);
    spanRemove.click(function(e){
        var daa= $(e.target).parent().data("data");
        daa.ifameJq.remove();
        daa.tabJq.remove();
        RemoveArr(daa);
        //是否全部标签关闭了
        if(iframeHtmlArr.length == 0){
            showMainPage();
        }else{
            showIndexiframe(iframeHtmlArr.length-1);
        }
    });
    tabItem.click(function(e){
        var daa = $(e.target).data("data");
        if(!daa){
            daa = $(e.target).parent().data("data");
        }
        var index_ ;
        for(var i = 0 ; i<iframeHtmlArr.length ; i++){
            if(daa == iframeHtmlArr[i]){
                index_ = i;
            }
        }
        showIndexiframe(index_);
    });
    return tabItem;
}

function RemoveArr(data){
    var newArr = [];
    for(var i = 0 ; i <iframeHtmlArr.length; i++){
        if(data != iframeHtmlArr[i]){
            newArr.push(iframeHtmlArr[i]);
        }
    }
    iframeHtmlArr = newArr;
}

function createNewIframe(srcStr){
    //拼接一个token
    if( srcStr && srcStr.length != 0 &&srcStr.indexOf("?") ==-1){
        srcStr+= "?access_token="+my_token;
    }else if(srcStr != undefined){
        srcStr+= "&access_token="+my_token;
    }else{
        srcStr = "";
        srcStr+= "?access_token="+my_token;
    }
	var getIframeHei = $(window).height() - $(".topView").height();
    var iframeJq = $("<iframe>").attr("src",srcStr).addClass("iframeHtmlId")
        .attr('sandbox', 'allow-forms allow-scripts allow-same-origin allow-popups')
        .css({
            "display":"none",
            "height":getIframeHei,
            "width":"100%",
            "border":"none"
        })
        .appendTo($("#iframeHtml"));
    return iframeJq;
}

//关闭一个 后显示最近加载的  var recnetOpen = [];
function showRecent(){


}

//换肤
var isWhiteSkin = true;

//index.js调用iframe的操作(主动调用，打开Iframe的时候还是要Iframe自身调用自身的换肤，其中parent.isWhiteSkin为获取外部的颜色值)
//Iframe的换肤操作
function changeiframeSkin(){
    var childIframeArr = $("#iframeHtml").children();
    for(var i = 0; i<childIframeArr.length; i++ ){
      const changeStyle = childIframeArr[i].contentWindow.changeBgcolor;
      if(changeStyle && changeStyle instanceof Function){
        // 允许不提供切换皮肤函数
        childIframeArr[i].contentWindow.changeBgcolor(!isWhiteSkin);
      }
    }
}

function changeSkin(){
//调用Iframe的换肤操作
    isWhiteSkin = !isWhiteSkin;
    localStorage.setItem("isWhiteSkin",isWhiteSkin);
    changeiframeSkin();
    //保存到本地存储
    changeColor(isWhiteSkin);
}

function changeIndexBg(bgColor){
    if(bgColor){
        $("#indexCss").attr("href","./css/external_css/index_2.css");
    }else{
        $("#indexCss").attr("href","./css/external_css/index.css");
    }
}

function changeColor(fOrT){
    //保存到本地存储
    if(fOrT){
        //主界面
        $("#indexCss").attr("href","./css/external_css/index_2.css");
        //待办换肤
        $("#todolist2").attr("href","./css/todoList/todoList_2.css");
        //排行
        $("#rankBoard2").attr("href","./css/rankBoard/rankBoard2.css");
        //新闻
        $("#news2").attr("href","./css/news/news_2.css");
        //通知
        $("#notice_2").attr("href","./css/notice/notice_2.css");
        //日历
        $("#calendar2").attr("href","./css/calendar/easyui_1.css");
        //im
        $("#im_css").attr("href","./css/im/index_communicate_blue.css");
        //我的收藏
        $("#myFavorite").attr("href","./css/myFavorite/myFavorite2.css");
        //值班
        $("#onDutyCss").attr("href","./css/onduty/onduty.css");
        //任务管理
        $("#taskMangae").attr("href","./css/taskMangage/bulma.css");

    }
    else{
        //主界面
        $("#indexCss").attr("href","./css/external_css/index.css");
        //待办换肤
        $("#todolist2").attr("href","./css/todoList/todoList.css");
        //排行
        $("#rankBoard2").attr("href","./css/rankBoard/rankBoard.css");
        //新闻
        $("#news2").attr("href","./css/news/news.css");
        //通知
        $("#notice_2").attr("href","./css/notice/notice.css");
        //日历
        $("#calendar2").attr("href","./css/calendar/easyui_2.css");
        //im
        $("#im_css").attr("href","./css/im/index_communicate.css");
        //我的收藏
        $("#myFavorite").attr("href","./css/myFavorite/myFavorite.css");
        //值班
        $("#onDutyCss").attr("href","./css/onduty/onduty_2.css");
        //任务管理
        $("#taskMangae").attr("href","./css/taskMangage/bulma_2.css");
    }
}


function persionInfoItem(key,value,i){
    var li = $($("#personInfoUl").children()[i]);
    $(li.children()[0]).text(key);
    $(li.children()[1]).text(value);
}
var isOpenTips= true;;
//个人界面
function personInfoM(){
    layer.closeAll("tips");
    isOpenTips = !isOpenTips;
    if(isOpenTips){
        return;
    }
    persionInfoItem("姓名",userData.userName,0);
    persionInfoItem("警号",userData.userCode,1);
    persionInfoItem("当前职位",userData.currentJob || "无",2);
    persionInfoItem("工作岗位",userData.job || "无",3);
    persionInfoItem("职务",userData.position || "无",4);
    persionInfoItem("职级",userData.rank || "无",5);
    persionInfoItem("警衔",userData.policeRank || "无",6);
    persionInfoItem("手机",userData.mobilePhone || userData.mobilePhone2,7);
    persionInfoItem("部门",userData.dept.name,8);
    // // persionInfoItem("个性签名",userData.dept.remark || "这个人很懒，什么都没留下",7);
    var htmlStr = $("#personInfo").html();
    var tipLayer = layer.tips(htmlStr, '.selfInfo', {
        tips: [1, '#3875EB'],
        time: 2000
    });
    //捕获页
    // layer.open({
    //     type: 1,
    //     shade: false,
    //     title:  ["个人信息", 'font-size:18px;background-color:rgb(50, 115, 220);color:white'], //不显示标题,
    //     area: ['55%', '60%'],
    //     content: $("#personInfo"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
    //     cancel: function(){
    //         //隐藏
    //         $('#personInfo').hide();
    //     },
    // });

}
