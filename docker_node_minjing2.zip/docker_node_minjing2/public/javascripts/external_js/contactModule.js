// 	//通讯录ip
// 	var httpUrl = "http://172.19.255.102:8888";
	
// 	//搜索
// 	$("#goSearch").click(function(){
// 		searchName = $("#searchName").val();
// 		if(!!searchName){
// 			getPersonByName(searchName);
// 		}else{
// 			//获取所有部门
// 			getData(func);
// 		}
// 	});
	
// 	//通过姓名获取联系人
// 	function getPersonByName(name){
// 		var searchNameUrl = httpUrl+"/org/userName";
// 		var par = {name:name+""};
// 		console.log(par);
// 		$.post(searchNameUrl,par,function(res){
// 			re = [];
// 			for(var i = 0; i < res.result.length; i++){
// 				re.push(res.result[i]);
// 			}
// //			console.log(res);
// 			//创建
// 			$("#itemsddd").html("");
// 			for(var i = 0; i<re.length; i++){
// 				CreatItemDiv(re[i],funcCallBack);
// 			}
// 		});
// 	}
	
// 	var funcCallBack;
// 	//获取联系人
// 	function getContacts(func){
// 		funcCallBack = func;
// 		console.log("获取通讯录模块--");
// 	//捕获页
// 	layer.open({
// 	  	type: 1,
// 	  	shade: false,
// 	  	offset: 'rt',
// 		title:  ['通讯录', 'font-size:18px;background-color:rgb(50, 115, 220);color:whith;border'], //不显示标题,
// 	  	area: ['20%', '60%'], 
// 	  	content: $("#contacts"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
// 	  	cancel: function(){
// 	  		//隐藏
// 	  		$('#contacts').hide();
// 	//			    layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', {time: 5000});
// 		  	},
// 		});
// 		getData(func);
// 	}
	
// 	function CreatItemDiv(dd,func) {
// 		var imgSrc,name,msg;
// 		if(!!dd.imid){
// 			imgSrc = "images/communicate/men.png";
// 			name = dd.userName;
// 			msg = dd.policeRank;
// 		}else{
// 			imgSrc = "images/communicate/department.png"
// 			name = dd.orgName;
// 			msg = "";
// 		}
// 		dd = {dd:dd,callback:func};
// 		var im_item = $("<div>").addClass("contact_item").data("data",dd);
// 		var headImage = $("<img>").addClass("contact_headImage").data("data",dd).attr("src",imgSrc).attr("isclick","1");
// 		var textDiv = $("<div>").addClass("contact_text").data("data",dd).css({"display": "flex","flex-direction": "column"});
// 		var nameP = $("<span>").addClass("contact_name").text(name).data("data",dd).css({"height": "0px"});
// 		var msgP = $("<span>").addClass("im_msg").text(msg);
		
// 		im_item.click(function(e){
// 			var fun = $(e.target).data("data").callback;
// 			var datat = $(e.target).data("data").dd;
// 			//点击的是部门还是人
// 			if(!!datat.imid){
// 				fun(datat);
// 			}else{
// 				deepIndex.push(datat.orgId);
// 				getResquest(datat.orgId,fun);
// 			}
// 		});
// 		headImage.appendTo(im_item);
// 		nameP.appendTo(textDiv);
// 		msgP.appendTo(textDiv);
// 		textDiv.appendTo(im_item);
// 		$("#itemsddd").append(im_item);
// 	}
	
// 	function getData(func){
// 		getNodeData(httpUrl+"/org/allOrg/childOrg");
// 		function getNodeData(url){
// 			$.get(url,function(res){
// 				callBack = func;
// 				$("#itemsddd").html("");
// 					CreatItemDiv(res.result,func);
// 			});
// 		}
// 	}
	
// 	var deepIndex = [];
// 	var currentOrgId;
// 	var callBack ;
	
// 	//点击返回
// 	function contackGoBack(){
// 		deepIndex.reverse();
// 		deepIndex.shift();
// 		console.log(deepIndex);
// 		deepIndex.reverse();
// 		var orggid = deepIndex[deepIndex.length-1];
// 		if(!!orggid){
// 			getResquest(orggid,callBack);
// 		}else{
// 			getData(callBack);
// 		}
// 		showGoBack();
// 	}
// 	//隐藏返回按钮
// 	function showGoBack(){
// 		if(deepIndex.length== 0){
// 			$("#contackGoBtn").hide();
// 		return;
// 	}else{
// 		$("#contackGoBtn").show();
// 		}
// 	}
	
// 	function getResquest(orgId,func){
// //		console.log(deepIndex)
// 		showGoBack();
// 		$("#itemsddd").html("");
// 		var departMentUrl  = httpUrl+"/org/orgName/o";
// 		var personUrl = httpUrl+"/org/orgName/p";
// 		//用来保存用户和部门的合集
// 		re = [];
// 		var par = {orgId :orgId+""}
// 		$.post(personUrl,par,function(res){
// 			for(var i = 0; i < res.result.length; i++){
// 				re.push(res.result[i]);
// 			}
// 			$.post(departMentUrl,par,function(res){
// 				for(var i = 0; i < res.result.length; i++){
// 					re.push(res.result[i]);
// 				}
// 				//创建
// 				for(var i = 0; i<re.length; i++){
// 					CreatItemDiv(re[i],func);
// 				}
// 			});
// 		});
// 	}
	
// //	//test
// //	getContacts(testll);
// //	
// //	function testll(data){
// //		console.log(data);
// //	}

	//通讯录ip 正式
	// var httpUrl = "http://172.19.255.215/userservice";
//  测试userserviceURL
	var httpUrl = userserviceURL;
	var token = my_token;
	var userInfoContact;
	//点击回调
	var funcCallBack;
	
	function getContacts(func){
		//首先获取用户数据
		getUserInfoContact();
		funcCallBack = func;
	}
	
	//根据token获取用户信息 getUserInfoByToken
	function getUserInfoContact(){
		var userInfoUrl = httpUrl + "/user/getUserInfo";
		var paramToken = {tokenStr:token,userCode:""};		
		// var paramToken = {tokenStr:"e6f5f17534f74db89c1048f4d3888888"};
		getAjaxRequest(userInfoUrl, paramToken,"userInfo");
	}
	
	function handlerDataByUserInfo(data){
		userInfoContact = data;
//		console.log(userInfoContact);
		//获取用户数据成功后拉起通讯录
		getContactsInfo(funcCallBack);
		
	}
	var isHavaGetData = false;
	//搜索
	var currentSearchName ;
	$("#goSearch").click(function(){
		$("#contackGoBtn").hide();
		searchName = $("#searchName").val();
		if(!!searchName){
			currentSearchName = searchName;
			getPersonByName(searchName);
		}else{
			if(!isHavaGetData){
				//获取所有部门
				getRootData(funcCallBack);
				isHavaGetData = true;
			}else{
				showCurrentUserCo();
			}
			
		}
	});
	
	var tempRe = [];
	//通过姓名或者部门名获取联系人通讯录
	function getPersonByName(name){
		var searchNameUrl = httpUrl+"/user/getUserByUserName";
		var par = {tokenStr:token,userName:name};
	  	getAjaxRequest(searchNameUrl,par,"byName")
	}
	
	function handlerDataByName(data){
		for(var i = 0; i < data.length; i++){
			tempRe.push(data[i]);
		}
		//嵌套ajax的 再模糊查询部门  这里不合理
		var searchNameUrl = httpUrl+"/user/getOrgByOrgName";
		var par = {tokenStr:token,orgName:currentSearchName};
	  	getAjaxRequest(searchNameUrl,par,"byOrgName")
	}
	
	function handlerDataByOrgName(data){
		for(var i = 0; i < data.length; i++){
			tempRe.push(data[i]);
		}
		//创建
		$("#itemsddd").html("");
		for (var i = 0; i < tempRe.length; i++) {
			CreatItemDiv(tempRe[i],funcCallBack);
		}
		tempRe = [];
	}
	//封装的ajax请求
	function getAjaxRequest(url,data,flag){
		data = JSON.stringify(data);
		console.log("url:",url);
		console.log("data：",data);
	 	XHSDK.ajax({
		    url: url,
		    type: "post",
		    data:data,
		    contentType:"application/json;charset=utf-8",
		    dataType:"json",
		    success : function (res) {  
		    	if(res.code == 200){
		    		if(flag == "byName"){
		    			handlerDataByName(res.data);
		    		}
		    		if(flag == "userInfo"){
		    			handlerDataByUserInfo(res.data);
		    		}
		    		if(flag == "getCurrent"){
		    			handlerGetData(res.data);
		    		}
		    		if(flag == "getCurrentFirst"){
		    			handlerFirstGetData(res.data);
		    		}
		    		if(flag == "byOrgName"){
		    			handlerDataByOrgName(res.data);
		    		}
		    		if(flag == "getRootDat"){
		    			handlerRootData(res.data);
		    		}
		    	}
		    },  
		    error:function(errorMsg){  
		        console.log("错误",errorMsg);  
		    }  
	  	});
	}
	
	//获取联系人
	function getContactsInfo(func){
//		console.log("获取通讯录模块--");
		//捕获页
		layer.open({
		  	type: 1,
		  	shade: false,
		  	offset: 'rt',
			title:  ['通讯录', 'font-size:18px;background-color:rgb(50, 115, 220);color:whith;border'], //不显示标题,
		  	area: ['20%', '60%'], 
		  	content: $("#contacts"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
		  	cancel: function(){
		  		//隐藏
		  		$('#contacts').hide();
		//			    layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', {time: 5000});
			  	},
			});
			getRootData(func);
		}
	
	function CreatItemDiv(dd,func) {
		var imgSrc,name,msg;
		if(!!dd.id){
			imgSrc = "images/communicate/department.png"
			name = dd.name;
			msg = "";
		}else{
			imgSrc = "images/communicate/men.png";
			name = dd.userName;
			if(!!dd.policeRank){
				msg = dd.policeRank;
			}else{
				msg = "";
			}
		}
		dd = {dd:dd,callback:func};
		var im_item = $("<div>").addClass("contact_item").data("data",dd);
		var headImage = $("<img>").addClass("contact_headImage").data("data",dd).attr("src",imgSrc).attr("isclick","1");
		var textDiv = $("<div>").addClass("contact_text").data("data",dd).css({"display": "flex","flex-direction": "column"});
		var nameP = $("<span>").addClass("contact_name").text(name).data("data",dd).css({"height": "0px"});
		var msgP = $("<span>").addClass("im_msg").text(msg).data("data",dd);
		
		im_item.click(function(e){
			var fun = $(e.target).data("data").callback;
			var datat = $(e.target).data("data").dd;
			//点击的是部门还是人
			if(!!datat.id){
				deepIndex.push(datat.id);
				getResquest(datat.id,fun);
			}else{
				fun(datat);
			}
		});
		headImage.appendTo(im_item);
		nameP.appendTo(textDiv);
		msgP.appendTo(textDiv);
		textDiv.appendTo(im_item);
		$("#itemsddd").append(im_item);
	}
	
	//获取当前用户的用户数目录
	function getData(func){
//		console.log(userInfoContact);
		var url = httpUrl + "/user/getOrgUserByOrgId";
		var param = {tokenStr:token,id:userInfoContact.departmentId};
//		var param = {tokenStr:token,orgId:0};
		getAjaxRequest(url,param,"getCurrentFirst")
	}
	
	function handlerFirstGetData(data){
		var re = [];
		var userList = data.userList;
		var orgList = data.orgList;
		for (var i = 0; i < userList.length; i++) {
			re.push(userList[i]);
		}
		for (var i = 0; i < orgList.length; i++) {
			re.push(orgList[i]);
		}
		for (var i = 0; i < re.length; i++) {
			currentContactUser.push(re[i]);
		}
		showCurrentUserCo();
	}
	
	function handlerGetData(data){
//		console.log(data);
		var re = [];
		var userList = data.userList;
		var orgList = data.orgList;
		for (var i = 0; i < userList.length; i++) {
			re.push(userList[i]);
		}
		for (var i = 0; i < orgList.length; i++) {
			re.push(orgList[i]);
		}
		for (var i = 0; i < re.length; i++) {
			CreatItemDiv(re[i],funcCallBack);	
		}
	}
	
	//初始化显示的
	var currentContactUser = [];
	//获取根级组织架构
	function getRootData(func){	
		var url = httpUrl + "/user/getOrgUserByOrgId";
		//var param = {tokenStr:token,orgId:userInfoContact.orgId};
		var param = {tokenStr:token,id:1};
		getAjaxRequest(url,param,"getRootDat")
	}
	
	function handlerRootData(data){
		var re = [];
		var userList = data.userList;
		var orgList = data.orgList;
		for (var i = 0; i < userList.length; i++) {
			re.push(userList[i]);
		}
		for (var i = 0; i < orgList.length; i++) {
			re.push(orgList[i]);
		}
		currentContactUser = re;
		// console.log(currentContactUser);
		getData(funcCallBack);
	}
	
	//显示当前目录
	function showCurrentUserCo(){
		$("#itemsddd").html("");
//		console.log(currentContactUser);
		for (var i = 0; i < currentContactUser.length; i++) {
			CreatItemDiv(currentContactUser[i],funcCallBack);	
		}
	}
	
	var deepIndex = [];
	var currentOrgId;

	//点击返回
	function contackGoBack(){
		$("#itemsddd").html("");
		deepIndex.reverse();
		deepIndex.shift();
//		console.log(deepIndex);
		deepIndex.reverse();
		var orggid = deepIndex[deepIndex.length-1];
		if(!!orggid){
			getResquest(orggid,funcCallBack);
		}
		showGoBack();
	}
	//隐藏返回按钮
	function showGoBack(){
		if(deepIndex.length== 0){
			showCurrentUserCo();
			$("#contackGoBtn").hide();
		return;
	}else{
		$("#contackGoBtn").show();
		}
	}
	
	function getResquest(orgId){
		showGoBack();
		$("#itemsddd").html("");
		var url = httpUrl + "/user/getOrgUserByOrgId";
		var param = {tokenStr:token,id:orgId};
		getAjaxRequest(url,param,"getCurrent")
	}