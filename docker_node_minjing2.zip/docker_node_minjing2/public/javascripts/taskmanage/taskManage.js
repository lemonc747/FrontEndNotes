
	//默认的参数
	var userCode ;//= "jiaowei";
	var userName = "";
	//1:查自己创建的, 2:查接收的, 3:查全部,4:我传阅的
	var type = 1;
	//任务级别级别(0一般、1重要、2紧急)
	var taskLevel = -1;
	// string 0：未完成、1：已完成、2：未完成和已完成、9：已结束、 null 为空查全部
	var status = -1;
	//string 格式 2017-11-5
	var startDate = -1;
	//string 格式 2017-11-5
	var endDate = -1;
	//Integer
	var pageNo = 1;
	//Integer
	var pageSize = 5;
	var createUserName = "";
	var postUrl = 'http://10.42.0.235/qapp/leaderTask'
	// var postUrl = 'http://172.28.0.56:9000/qapp/leaderTask';
	//测试
	postUrl = "http://10.42.0.171:9019/msa_xhyzd_task";
	//后台本地服务测试用
	//postUrl = "http://68.61.113.41:8080/msa_xhyzd_task";
	
	//是否正式环境
	var isTest = false;
	if(isTest){
		postUrl = "http://68.61.8.117:5008/msa_xhyzd_task";
	}
	
	
	
	var taskMParma = {};
	
	//http://172.28.0.56:9008/qapp/leaderTask/listToApp?userCode=wangcan&type=1&pageNo=1&pageSize=20
	 window.onload =function(){
		 //我主办的
		 initParam();
		//第一次请求默认的 
		getData();
		//获取发起人
		getCreater();
	}

	function initParam(){
		taskMParma = {};
		taskMParma.userId = parent.userData.userId;
		//	查询类别(1:查我创建的,3:我主办的 , 2:我协办的 4:我传阅的,5：查全部 , 6:查接收的(我主办的+我协办的))
		taskMParma.type = 3;
		//任务级别级别(0一般、1重要、2紧急)
		taskMParma.taskLevel = -1;
		//任务状态（0未完成、1已完成、9已结束、-9已终止）
		taskMParma.status = 0;
		//string 格式 2017-11-5
		taskMParma.startDate = -1;
		//string 格式 2017-11-5
		taskMParma.endDate = -1;
		//Integer
		taskMParma.pageNo = 1;
		//Integer
		taskMParma.pageSize = 5;
		taskMParma.access_token = parent.my_token;
		taskMParma.queryUserName = "";
		taskMParma.terminalId = 1;
	}

	//我主办的
	function myTask(){
		removeAllActive();
		$("#myTaskTab").addClass("is-active");
		$("#myTaskTab").find("img").attr("src","images/taskmanage/2-2.png");
		initParam();
		taskMParma.type = 3;
		tablePage(5,1)
		getData();
		
	}

	//我协办的
	function myHelpTask(){
		removeAllActive();
		$("#myTaskHelpTab").addClass("is-active");
		$("#myTaskHelpTab").find("img").attr("src","images/taskmanage/1-1.png");
		initParam();
		taskMParma.type = 2;
			tablePage(5,1)
		getData();
	}
	
	//我创建的
	function mysetTask(){
		removeAllActive();
		$("#mysetTaskTab").addClass("is-active");
		$("#mysetTaskTab").find("img").attr("src","images/taskmanage/3-2.png");
		initParam();
		taskMParma.type = 1;
		tablePage(5,1)
		getData();
	}
	
	//我传阅的
	function readTask(){
		removeAllActive();
		$("#readTaskTab").addClass("is-active");
		$("#readTaskTab").find("img").attr("src","images/taskmanage/ic_index_circulate2.png");
		initParam();
		taskMParma.type = 4;
	tablePage(5,1)
		getData();
	}
	function removeAllActive(){
		$("#myTaskTab").removeClass("is-active");
		$("#myTaskHelpTab").removeClass("is-active");
		$("#mysetTaskTab").removeClass("is-active");
		$("#readTaskTab").removeClass("is-active");
		$("#myTaskHelpTab").find("img").attr("src","images/taskmanage/1.png");
		$("#myTaskTab").find("img").attr("src","images/taskmanage/2.png");
		$("#mysetTaskTab").find("img").attr("src","images/taskmanage/3.png");
		$("#readTaskTab").find("img").attr("src","images/taskmanage/ic_index_circulate1.png");
	}
	
	function createItems(data){
		//console.log(data);
		var item = $("<div>").addClass("itemss");
		var FDiv = $("<div>").addClass("columns").addClass("itemContent").appendTo(item);
		var ContentDiv = $("<div>").addClass("column").addClass("is-three-quarters").appendTo(FDiv);
		var i =$("<img>").attr('src','images/taskmanage/ic_index_task_title2.png').css({"margin-right":"5px","vertical-align":"-1px"}).appendTo(ContentDiv);
		var strDiv = $("<div>").addClass("spanContent").appendTo(ContentDiv).text(data.title);
		var tagDiv = $("<div>").addClass("column").addClass("flexCenter").appendTo(FDiv);
		var endDateStr;
		if(!!data.endDate){
			endDateStr = data.endDate;
			var endDate = new Date(data.endDate.replace(/-/g,'/'));
	//				console.log(endDate);
	// 		if(endDate.getTime() < new Date().getTime()){
	// 			$("<a>").addClass("button").addClass("is-danger").text("超期").addClass("is-outlined").appendTo(tagDiv);
			// }
		}else{
			endDateStr = "无";
		}

		if(data.expired == 0){
			$("<a>").addClass("button").addClass("is-danger").text("超期").addClass("is-outlined").appendTo(tagDiv);
		}

		//级别(0一般、1重要、2紧急)
		if(data.taskLevel == 0 ){
			$("<a>").addClass("button").addClass("is-info").addClass("left_mar").text("一般").appendTo(tagDiv);
		}else if(data.taskLevel == 1){
			$("<a>").addClass("button").addClass("is-warning").addClass("left_mar").text("重要").appendTo(tagDiv);
		}else{
			$("<a>").addClass("button").addClass("is-danger").addClass("left_mar").text("紧急").appendTo(tagDiv);
		}
		var BDiv = $("<div>").addClass("columns").addClass("itemContent").addClass("itemStyle").appendTo(item);
		var contDiv = $("<div>").addClass("column").addClass("is-three-quarters").addClass("columnFlex").appendTo(BDiv);
		var imgDiv =  $("<div>").addClass("displayInline").appendTo(contDiv);
		var img  =  $("<img>").addClass("imgTag").attr("src","images/taskmanage/pinfenBg.png").appendTo(imgDiv);
		if(!!data.score && data.score  != " "){
			var span = $("<span>").addClass("spantextListScore").text(parseInt(data.score)).appendTo(imgDiv);
		}else{
			var span = $("<span>").addClass("spantextList").text("未评分").appendTo(imgDiv);
		}
		var contSetStrDiv = $("<div>").addClass("displayInline").appendTo(contDiv);
		var sentDiv = $("<div>").addClass("columnFlex").addClass("sentText").appendTo(contSetStrDiv);
		var senti = $("<img>").addClass("sentImag").attr("src","images/taskmanage/ic_index_leader.png").appendTo(sentDiv);
		var spanText = $("<span>").text("发起人："+data.userName).appendTo(sentDiv);
		var sentDiv1 = $("<div>").addClass("columnFlex").addClass("sentText").css({"margin-top":"5px"}).appendTo(contSetStrDiv);
		var senti1 = $("<img>").addClass("sentImag").attr("src","images/taskmanage/ic_index_data.png").appendTo(sentDiv1);
		var spanText1 = $("<span>").text("截止时间："+endDateStr).appendTo(sentDiv1);
		
		var notFinish = $("<div>").addClass("column").addClass("flexCenter").appendTo(BDiv);
		//状态（0未完成、1已完成、9已结束）
		var textStatus = "";
		if(data.status == 0){
			textStatus ="未完成";
		}else if(data.status == 1){
			textStatus ="已完成";
		}else if(data.status == -9){
			textStatus ="终止";
		}else{
			textStatus ="已结束";
		}
		var notFinisha = $("<a>").addClass("button").addClass("is-info").addClass("is-outlined").text(textStatus).appendTo(notFinish);
		var detail = $("<a>").addClass("button").addClass("is-info").addClass("is-outlined").addClass("left_mar").text("详情").appendTo(notFinish);
		item.appendTo($("#items"));
		detail.data("data",data);
	
		detail.click(function(e){
			showTaskDetail($(e.target).data("data"));
		});
		notFinisha.data("data",data);
		notFinisha.click(function(e){
			if($.trim($(this).html())=="未完成"){
				finishTask($(this).data("data"));
			}
			
		});
	}
	//选择完成情况
		function selectFinish(data){
			console.log(data);
			
			layer.open({
				type: 1,
				shade: 0.5,
				shadeClose:true,
				offset:"t",
				title:  ['新建任务', 'font-size:18px;background-color:rgb(50, 115, 220);color:white'], //不显示标题,
				area: ['55%', '64%'], 
				content: $("#taskDone"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
				cancel: function(){
					
				}
			});
			
			$("#doneMainer,#donehelper,#doneRead").html("");
			$("#doneName").text(data.title).data("data",data);
		
			var getreceiveUser = data.receiveUserName.split(',');
			var getreceiveUserId = data.receiveUserName.split(',');
			for(var i=0;i<getreceiveUser.length; i++){
				$("#doneMainer").append('<div style="margin-bottom:12px;"><span>'+getreceiveUser[i]+'</span> <input type="number"  value="60"   data-id="'+getreceiveUserId[i]+'" ></div>');
			}
			var partakeUserName = data.partakeUserName.split(',');
			var partakeUserId = data.partakeUserId.split(',');
			for(var i=0;i<getreceiveUser.length; i++){
				$("#donehelper").append('<div style="margin-bottom:12px;"><span>'+partakeUserName[i]+'</span> <input type="number"  value="60"   data-id="'+partakeUserId[i]+'" ></div>');
			}	
			
			var circulateUserName = data.circulateUserName.split(',');
			var circulateUserUuid = data.partakeUserId.split(',');
			for(var i=0;i<circulateUserName.length; i++){
				$("#doneRead").append('<div style="margin-bottom:12px;"><span>'+circulateUserName[i]+'</span> <input type="number"  value="60"   data-id="'+circulateUserUuid[i]+'" ></div>');
			}	
		}
		
	function doneTask(){
			var getTaskData = $("#doneName").data().data;
			getTaskData.type = taskScore;
			getTaskData.access_token = parent.my_token;
			getTaskData.terminalId = 1;
			
		  $.ajax({
	     	url:postUrl + '/task/v1/manager/scoreToApp',
	        type:"post",
	        contentType:"application/json;charset=utf-8",
	        success:function(res){  
	            if(res.success){
	            	createOptions(res.obj);
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
	        }
	   });
		
	}		
	//选择时间
	function timeChange(e){
    var startDate = new Date();
		var addDays  = 0;
		endDate = new Date("2017/11/14");
		var valueStr = $(e.target).val();
		if(valueStr == "一周"){
			addDays = 7;
		}else if(valueStr == "一月"){
			addDays = 30;	
		}else if(valueStr == "半年"){
			addDays = 183;	
		}else{
			addDays = 365
    }
    startDate.setDate(startDate.getDate()-addDays);
		taskMParma.startDate = startDate.Format("yyyy-MM-dd");
		taskMParma.endDate = new Date().Format("yyyy-MM-dd");
		if(addDays == 0){
			taskMParma.startDate = -1;
			taskMParma.endDate = -1;
		}
		getData();
	}
	
	//选择优先级
	function priorityChange(e){
		//	任务级别级别(0一般、1重要、2紧急)
		var taskLevel  = 0;
		var valueStr = $(e.target).val();
		if(valueStr == "一般"){
			taskLevel = 0;
		}else if(valueStr == "重要"){
			taskLevel = 1;	
		}else if(valueStr == "紧急"){
			taskLevel = 2;	
		}else{
			taskLevel = -1;
		}
	tablePage(5,1);
		taskMParma.pageNo = 1;
		taskMParma.taskLevel = taskLevel;
		getData();
	}
	
	//选择完成情况
	function finishChange(e){
		var type = 0;
		//	0：未完成、1：已完成、2：未完成和已完成、9：已结束、 null 为空查全部
		var valueStr = $.trim($(e.target).val());
		if(valueStr == "未完成"){
			type = 0;
		}else if(valueStr == "已完成"){
			type = 1;	
		}else if(valueStr == "已结束"){
			type = 9;	
		}else if(valueStr == "已终止"){
				type = -9;	
		}else{
			type = '-1';
		}
	tablePage(5,1)
		taskMParma.pageNo = 1;
		taskMParma.status = type;
		getData();
	}
	
	//选择发起人
	function personChange(e){
		var createUserName = "";
		var valueStr = $(e.target).val();
		if(valueStr == "发起人"){
			createUserName = "";
		}else{
			createUserName = $(e.target).val();
		}
		taskMParma.queryUserName = createUserName;
		getData();
	}
	
	//获取发起人
	function getCreater(){
		$("#items").html("");
		var params = "?userId="+parent.userData.userId;
		var urll;
		if(isTest){
			urll =postUrl+"/task/v1/manager/getDistinctCreateUser"+params;
		}else{
			urll = "json/taskPerson.json"+params;
		}
        $.ajax({
	     	url:urll,
	        type:"get",
	        contentType:"application/json;charset=utf-8",
	        success:function(res){  
	            if(res.success){
	            	createOptions(res.obj);
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
	        }
	   });
	}
	
	function createOptions(data){
		for(var i = 0; i< data.length; i++){
			$("<option>").text(data[i].userName).appendTo($("#createPerson"));
		}
	}
	
	//拼接字符串
	function getDataParma(){
		var str = "?"
		for(var item in taskMParma){

			
			if(item === 'taskLevel'){
				if(taskMParma[item]===0){
					str+= item +"="+0;
					str+="&";
				}
						
			}
			if(item === 'status'){
				if(taskMParma[item]===0){
					str+= item +"="+0;
					str+="&";
				}		
			}
			if(taskMParma[item]== -1 ||taskMParma[item] == "")
				continue;
			str+= item +"="+taskMParma[item];
			str+="&";
		}
		
		return str.substr(0,str.length-1);
	}
	
	function getData(){
	
		var dataS = getDataParma();
		//清空列表
		$("#items").html("");
		urll1 = postUrl+"/task/v1/manager/listToApp"+dataS;
		 $.ajax({
	     	url:urll1,
	        type:"get",
	        success:function(res){ 
	            if(res.success){
	            	handerData(res.obj);
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("error:",msg);
	        }
	   });
	}
	
	function handerData(obj){
		if(obj.length==0){
			if(taskMParma.pageNo != 1){
				taskMParma.pageNo = taskMParma.pageNo-1;
				$("#page li").eq(0).find('a').click();
				layer.msg("已是最后一页");	
			}else{
				layer.msg("无数据！！");	
			}
			
			return;
		}
		for(var i = 0 ; i< obj.length; i++){
			createItems(obj[i]);				
		}
	}
	
	function showTaskDetail(data){
		var param = "?userId="+parent.userData.userId+"&id="+data.id+"&access_token="+parent.my_token+"&terminalId=1";
		var urll2;
		urll2 = postUrl+"/task/v1/manager/detailToApp"+param;
		
		$.ajax({
	     	url:urll2,
	        type:"get",
	        contentType:"application/json;charset=utf-8",
	        success:function(res){ 
			console.log(res);
	            if(res.success){
	            	fillData(res.obj);
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
        	}
	   	});
	}
	
	function showCreatenewTask(){
		console.log("新建任务");
	 	//清空检查项
		contentStr = [];
		$("#checkItems").html("");
		$("#CT_Remark").val("");
		$("#CT_easyValue").val("");
		$("#CT_endTime").val("");
		$("#CT_reader").val("");
		$("#CT_helper").val("");
		$("#CT_mainer").val("");
		$("#CT_level").val("");
		$("#CT_taskName").val("");
		mainerArr = [];
		helperArr = [];
		readerArr = [];
		//捕获页
		layer.open({
		  	type: 1,
		  	shade: 0.5,
		  	shadeClose:true,
		  	offset:"t",
	  		title:  ['新建任务', 'font-size:18px;background-color:rgb(50, 115, 220);color:white'], //不显示标题,
		  	area: ['55%', '64%'], 
		  	content: $("#taskCreate"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
		  	cancel: function(){
		  		//隐藏
		  		$('#taskCreate').hide();
				parent.layer.closeAll();
				parent.$('#contacts').hide();
	//			    layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', {time: 5000});
		  	},
		});
		
		//截止日期  时间选择器
		laydate.render({
		  elem: '.CT_endTime'
		  ,value:new Date()
		  ,type:"datetime"
		  ,done: function(value, date){
		    
		  }
		});
	}
	
	var contentStr = [];
	//创建新任务
	function createNewTask(){
		
		var CT_remark = $("#CT_Remark").val();
		var CT_easyValue = $("#CT_easyValue").val();
		var CT_endTime = $("#CT_endTime").val();
		var CT_reader = $("#CT_reader").val();
		var CT_helper = $("#CT_helper").val();
		var CT_mainer = $("#CT_mainer").val();
		var CT_level = $("#CT_level").val();
		var CT_taskName =  $("#CT_taskName").val();
		
		if( CT_taskName== ""){
			layer.msg("请填写任务名称！！！");
			return;
		}
		if(CT_mainer== ""){
			layer.msg("请选择主办人！！");
			return;
		}
		if(CT_level== ""){
			layer.msg("请选择任务等级！！");
			return;
		}
		if(CT_endTime== "" ){
			layer.msg("请选择截至时间！！");
			return;
		}
		if(CT_easyValue== ""){
			layer.msg("请选择难度等级！！");
			return;
		}

		//级别(0一般、1重要、2紧急)
		var CT_levelInt;
		if(CT_level == "一般"){
			CT_levelInt = 0;
		}else if(CT_level == "重要"){
			CT_levelInt = 1;	
		}else{
			CT_levelInt = 2;	
		}

		var optionsCon = [];
		for(var i = 0;i< contentStr.length;i++){
			var itemsObj = {content:contentStr[i],isFinish:0};
			optionsCon.push(itemsObj);
		}
		optionsCon = JSON.stringify(optionsCon);
		//发送ajax
		var sAjaxParam = {};
		sAjaxParam.userId = parent.userData.userId;
		sAjaxParam.userName = parent.userData.userName;
		sAjaxParam.userCode = parent.userData.userCode;
		sAjaxParam.status = 0;
		sAjaxParam.description = CT_remark;
		sAjaxParam.taskLevel = CT_levelInt;
		sAjaxParam.title = CT_taskName;
		sAjaxParam.endDate = CT_endTime;
		sAjaxParam.score = CT_easyValue;
		sAjaxParam.currentUserId = parent.userData.userId;
		sAjaxParam.options = optionsCon;
		//参与人员
		sAjaxParam.partakeUserName = CT_mainer.substr(0,CT_mainer.length-1);
		sAjaxParam.receiveUserName = CT_helper.substr(0,CT_helper.length-1);
		 sAjaxParam.circulateUserName = CT_reader.substr(0,CT_reader.length-1);
		console.log(sAjaxParam);
		
		sAjaxParam.circulateUserCode = returnNeedStr(helperArr,"userCode",3);
		sAjaxParam.partakeUserCode = returnNeedStr(mainerArr,"userCode",1);
		sAjaxParam.receiveUserCode = returnNeedStr(readerArr,"userCode",2);
		
		
		sAjaxParam.partakeUserId = returnNeedStr(mainerArr,"userId",1);
		sAjaxParam.partakeUserUuid = returnNeedStr(mainerArr,"userId",1);
		sAjaxParam.circulateUserId = returnNeedStr(readerArr,"userId",3);
		sAjaxParam.circulateUserUuid = returnNeedStr(readerArr,"userId",3);
		sAjaxParam.receiveUserId = returnNeedStr(helperArr,"userId",2);
		sAjaxParam.receiveUserUuid = returnNeedStr(helperArr,"userId",2);
	
		var urll2 = postUrl+"/task/v1/manager/saveLeaderTaskToApp?access_token="+parent.my_token+"&terminalId=1";
		
		console.log(urll2);
		$.ajax({
	     	url:urll2,
	        type:"post",
	        data:JSON.stringify(sAjaxParam),
			contentType:"application/json;charset=utf-8",
	        success:function(res){
	            if(res.success){
	            	layer.msg("新建成功！！！");
					initParam();
	            	getData()
	            	layer.closeAll();
					parent.layer.closeAll();
					parent.$('#contacts').hide();
					setTimeout(function(){
					mysetTask();	
					},1000);
	            	
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
        	}
	   	});
		
	}
	
	function searchInput(e){
		var val = $(e.target).val();
		if(e.keyCode == "13"){
            //if(val == ""){
            	//layer.msg("请输入任务名称！！");
	        //}else{
	        	getSearchData(val);
	        //}
        }
	}
	
	//获取搜索数据
	function getSearchData(title){
		var params = getDataParma();
        if(!!title){
            params += "&title="+title;
        }
		var urll;
		urll =postUrl+"/task/v1/manager/queryLeaderTaskByUser"+params;
		
		//清空列表
		$("#items").html("");
		$.ajax({
	     	url:urll,
	        type:"get",
	        contentType:"application/json;charset=utf-8",
	        success:function(res){  
	            if(res.success){
	            	handerData(res.obj.list);
	            }else{
	            	console.log("请求数据失败！！！");
	            }
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
	        }
	   });
	}
	
	function fillData(data){
		//捕获页
		layer.open({
		  	type: 1,
		  	shade: false,
	  		title:  ['任务详情', 'font-size:18px;background-color:rgb(50, 115, 220);color:white'], //不显示标题,
		  	area: ['55%', '60%'], 
		  	content: $("#taskDetail"), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
		  	cancel: function(){
		  		//隐藏
		  		$('#taskDetail').hide();
	//			    layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', {time: 5000});
		  	},
		});
		
		var entity = data.entity;
		//协助人
		$("#taskhelper").text(entity.receiveUserName);
		//传阅
		$("#goRead").text(entity.circulateUserName);
		$("#endTime").text(entity.endDate);
		$("#taskMainer").text(entity.partakeUserName);
		//级别(0一般、1重要、2紧急)
		if(entity.taskLevel == 0 ){
			$("#taskLevel").text("一般");
		}else if(entity.taskLevel == 1){
			$("#taskLevel").text("重要");
		}else{
			$("#taskLevel").text("紧急");
		}
		$("#taskname").text(entity.title);
		$("#myScoreText").text(entity.score);
		//0：未完成、1：已完成、2：未完成和已完成、9：已结束、 null 为空查全部
		if(entity.status == 0){
			$("#taskstatus").text("未完成");
		}else if(entity.status == 1){
			$("#taskstatus").text("已完成");
		}else {
			$("#taskstatus").text("已结束");
		}
		
		$("#endTime").val(entity.endDate);
		if(!!entity.description){
			$("#taskRemark").text(entity.description);
		}
		$("#showchitesm").html("");
		//检查项数据
		if(!!data.optionList){
			var count = data.optionList.length;
			var finshCount = 0;
			for(var i = 0; i< data.optionList.length; i++){
				$("<p>").text((i+1)+". "+data.optionList[i].content).appendTo($("#showchitesm"));
				if(data.optionList[i].isFinish != 0){
					finshCount++;
				}
			}
			$("#checkItemShow").text(finshCount+"/"+count);
		}

		var addClassCount = entity.score/5;
		for(var i =0; i < 10;i++){
			$($("#easyValue").children("div")[i]).removeClass("easyValueItemHeigt");
		}
		for(var i =0; i < addClassCount;i++){
			$($("#easyValue").children("div")[i]).addClass("easyValueItemHeigt");
		}
		$("#easyValueText").text(entity.score);
		createReply(data.replyList)
	}
	
	function createReply(data){
		$("#replyList").html("");
		for(var i = 0; i< data.length; i++){
			GetItmes(data[i]).appendTo($("#replyList"));
		}
		function GetItmes(data){
			var div = $("<div>").addClass("columns").css({"margin-top":"8px"});
			var column = $("<div>").addClass("colucolumnmns").appendTo(div);;
			var personA = $("<a>").addClass("is-info").text(data.createTime).appendTo(column);
			var personB = $("<a>").addClass("is-info").text(data.createEmpName).appendTo(column);
			$("<span>").addClass("is-warning").text("操作").appendTo(column);
			var content = $("<span>").text(data.description).appendTo(column);
			return div;
		}
		
	}
	//完成任务
	function finishTask(data){
		//询问框
		console.log(data);
		layer.confirm('是否完成该任务？', {
		  btn: ['完成','终止'] //按钮
		}, function(){
			finishAjax(data,1)
		 
		},function(){
			finishAjax(data,2)
		
		});
	}
	//完成任务接口
	function finishAjax(data,type){
	
		var getFinishData = data;
	
			getFinishData.access_token = parent.my_token;
			getFinishData.terminalId = 1;
			if(type != 1){
				getFinishData.endType = 'zz';
			}else{
				getFinishData.endType = '1';
			}
			var urlParmas = "?status=1&terminalId=1&access_token="+parent.my_token+"&endType="+getFinishData.endType+"&id="+getFinishData.id+"&userId="+getFinishData.userId;
			console.log(urlParmas);
		  $.ajax({
	     	url:postUrl + '/task/v1/manager/updateStatusToApp'+urlParmas,
	        type:"post",
	        contentType:"application/json;charset=utf-8",
	        success:function(res){  
				
				if(type != 1){
						layer.msg('终止', {icon: 1});
				  }else{
					   layer.msg('完成', {icon: 1});
				  }
				  $(".is-active").click();
				
	          
	        },
	        error:function(msg){
	            console.log("Errordddddd:",msg);
	        }
	   });
		
	}
	//回复
	function addTaskReply(){
		layer.prompt({title: '添加回复', formType: 2},	function(pass, index){
			
			console.log(pass);
			
	  		layer.close(index);
		 	
		})
	}
	
	//分页的操作
	tablePage(5,1);
	function tablePage(pageCount,currentPage){
        var options = {
            bootstrapMajorVersion: 3, //版本
            currentPage: currentPage, //当前页数
            totalPages: pageCount, //总页数
            numberOfPages: 0,
            itemTexts: function (type, page, current) {
                switch (type) {
                    case "first":
                        return "首页";
                    case "prev":
                        return "上一页";
                    case "next":
                        return "下一页";
                    case "last":
                        return "末页";
                    case "page":
                        return page;
                }
            },
            shouldShowPage:function(type, page, current){
            	switch (type) {
                    case "first":
                        return false;
                    case "prev":
                        return true;
                    case "next":
                        return true;
                    case "last":
                        return false;
                    case "page":
                        return page;
                }
            },
            onPageClicked: function (event, originalEvent, type, page){
             	
				taskMParma.pageNo= page;
                getData();
            }
        }
        $('#page').bootstrapPaginator(options);
    }
	
	function addcheckItem(){
		//prompt层
		layer.prompt({title: '输入检查项目，并确认', formType: 2}, function(pass, index){
		  	layer.close(index);
	 		createItem(pass);
	 		contentStr.push(pass);
		});
		
		function createItem(str){
			var item = $("<div>").addClass("columns").css({"border-bottom":"1px solid wheat"});
			var col = $("<div>").addClass("column").appendTo(item);
			var spanText = $("<div>").text((contentStr.length+1)+". "+str).appendTo(col);
			spanText.appendTo($("#checkItems"));
		}
	}
	
	var mainerArr = [];
	var helperArr = [];
	var readerArr = [];
	
	//获取主办人
	function getMainer(){
		parent.getContacts(getMainerArr);
	}
	
	//协办人
	function getHeleper(){
		parent.getContacts(getHelperArr);
	}
	
	//获取传阅
	function getReader(){
		parent.getContacts(getReaderArr);
	}

	function getDiffernStr(str,name){
		var strArr = str.split(",");
		for(var i = 0; i < strArr.length; i++){
			if(strArr[i] == name){
				return false;
			}
		}
		return true;
	}
	
	function getMainerArr(data){
		var str = $("#CT_mainer").val();
		str +=  $("#CT_helper").val();
		str +=  $("#CT_reader").val();
		var addStr = $("#CT_mainer").val();
		if(!getDiffernStr(str,data.userName)){
			return;
		}
		addStr += data.userName +",";
		$("#CT_mainer").val(addStr);
		mainerArr.push(data);
		console.log(mainerArr);
	}
	
	function getHelperArr(data){
		var str = $("#CT_mainer").val();
		str +=  $("#CT_helper").val();
		str +=  $("#CT_reader").val();
		var addStr = $("#CT_helper").val();
		if(!getDiffernStr(str,data.userName)){
			return;
		}
		addStr += data.userName+",";
		$("#CT_helper").val(addStr);
	
		helperArr.push(data);
			console.log(helperArr);
	}
	
	function getReaderArr(data){
		var str = $("#CT_mainer").val();
		str +=  $("#CT_helper").val();
		str +=  $("#CT_reader").val();
		var addStr = $("#CT_reader").val();
		if(!getDiffernStr(str,data.userName)){
			return;
		}
		addStr += data.userName+",";
		$("#CT_reader").val(addStr);
		readerArr.push(data);
	}
	
	//返回需要的字段
	function returnNeedStr(arr, item,type){
		var checkName = '';
		if(type == 1){
			checkName = $("#CT_mainer").val().split(',');
		}else if(type == 2){
			checkName = $("#CT_helper").val().split(',');
		}else if(type == 3){
			checkName = $("#CT_reader").val().split(',');
		}
		console.log(checkName);
		var str = "";
		for(var i = 0 ; i < arr.length; i++){
			for(var k=0; k<checkName.length; k++){
				if(checkName[k] == arr[i]['userName']){
						str += arr[i][item]+",";
				}
			}
		
		}
		console.log(str);
		return str.substr(0,str.length-1);
	}
	
	//检查名称还是否存在，用户手动删除了用户名
	function findCode(str,arr){
		for(var i =0 ; i< arr.length; i++){
			if(arr.userName == str){
				var code = arr[i].copNum;
				return code;
			}
		}
		return null;
	}	
	//换肤
    function changeBgcolor(skin) {
        if(skin){
            $("#infoList2").attr("href","css/infoList/infoList.css");
        }else {
            $("#infoList2").attr("href","css/infoList/infoList2.css");
        }
    }
	

