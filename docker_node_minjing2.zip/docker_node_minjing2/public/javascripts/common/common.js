window.common = {
    jsonp: function (urls, loginUserInfo, callback) {
        for (var i = 0; i < urls.length; i++) {
            var script = document.createElement("script");
            script.src = encodeURI(urls[i] + "?" + "loginUserInfoStr=" + loginUserInfo + "&callbackName=" + callback);
            document.body.appendChild(script);
            script.onerror = function () {
                eval(callback + "()")
            }
        }
    },

    getUrlParameter: function (key) {
        var url = window.location.href;
        var re = new RegExp(key + '=([^&]*)(?:&)?');
        return url.match(re) && url.match(re)[1];
    },

    getQueryString: function () {
        var url = window.location.href;
        if (url.indexOf('?') == -1) {
            return '';
        }
        return url.substr(url.indexOf('?') + 1);
    }
};