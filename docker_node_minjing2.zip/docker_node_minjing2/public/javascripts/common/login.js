$(function () {
    $('#username,#password,#btn_login').enterkeydown(function () {
        login();
    });
	$(document).on('focus','#username,#password',function(){
		$("#err-tip").remove();
	})
});

function login() {
    //###登录加密
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCkh2hS0KYiw+JMsAzy2UJ4QGSsx1gkPwrI7bhVRWYgd1gSTm37n9tg0In7EVkoqSoPw6zFV+9C0y52pYKSMdJrbThXwaENUYBxTX0UzQRX21AgPBkmx1r2BYQ9SeT/jMwRrW2N+iReDbMfCCxJaLRutz3/XilkavbSX8yixkQjNQIDAQAB";
    var encrypt = new JSEncrypt();
    encrypt.setPublicKey(publicKey);
    var json = {
        "userName": username,
        "password": password
    };
    json = JSON.stringify(json);
    json = encrypt.encrypt(json);
    var postJson = {'userInfo': json};
    //###oauth2认证
    var isAuth2Authorize;
    if (common.getUrlParameter(constants.response_type) == constants.code) {
        isAuth2Authorize = true;
        postJson.type = constants.code;
    }
    //###登录请求
    $.ajax({
      type: 'POST',
      url: ssoLoginURL,
      data: postJson,
      headers:{"requestType":"tymh","applyID":"f3295b7e695145509ce6f55de679f1e1","secretKey":"30636034E3DFD48100C0E3DE40E3AF69"},
      // headers:{"requestType":"tymh","applyID":"dc9a2d8a6be64889a03f57b2d0abc39f","secretKey":"563E82BE110D1A2E6F22341552F78A48"},
      success: function (result) {
        if (result.success) {
          //###OAuth2.0认证
          sessionStorage.setItem('access_token', result.data.loginUserInfo.accessToken);
          window.location.href = 'http://'+window.location.host+indexPage;// +'?access_token='+result.data.loginUserInfo.accessToken
        } else {
          if(result.errMsg==undefined||result.errMsg=='undefined'){
            if($("#err-tip").length == 0){
                    $(".pass_login .item").before('<div id="err-tip" style="color:red;margin-top:  5px;font-size: 12px;">账号密码错误</div>');
            }
          }else{
            alert(result.errMsg);
          }
        }
      },
			error:function(){
				if($("#err-tip").length == 0){
				$(".pass_login .item").before('<div id="err-tip" style="color:red;margin-top:  5px;font-size: 12px;">账号密码错误</div>');
				}

			}
    });
}

jQuery.fn.enterkeydown = function (f) {
    return this.each(function () {
        jQuery(this).keypress(function (e) {
            if ((e.keyCode && e.keyCode == 13) || (e.which && e.which == 13)) {
                f();
                return false;
            } else {
                return true;
            }
        });
    });
};


/**
 * qrcode: 暂时未启用
 */
$(function () {
  var genQrcodeUrl = serviceBaseUrl + 'sso/sso/qrcode';//生成二维码接口地址
  var checkUrl = serviceBaseUrl + 'sso/qrcode/check';//长连接检测是否已扫描登录接口地址
  var qrcodeImgEleId = 'qrcode';//html中二维码图片元素ID
  var refreshQrcodeEleId = 'qrcode';//html中刷新二维码图片元素ID
  var uuid;
  var curAjax;

  $("#refreshQrcode").click(function () {
      genQrcode();
  });

  function genQrcode() {
      if (curAjax) {
          curAjax.abort();
      }
      $.ajax({
          method: 'GET',
          url: genQrcodeUrl,
          async: false,
          success: function (obj) {
              uuid = obj.uuid;
              $("#" + qrcodeImgEleId).attr("src", obj.qrcodeUrl);
              check();
          }
      });
  }

  function check() {
      curAjax = $.ajax({
          method: 'GET',
          url: checkUrl + '?uuid=' + uuid + '&date=' + new Date().getTime(),
          success: function (data) {
            // todo
              switch (data) {
                  case "pending":
                      check();
                      break;
                  case "expired":
                      genQrcode();
                      // alert('二维码已失效，请刷新二维码');
                      break;
                  default:
                      // index.html
                      //window.location.href = server.indexUrl + "?access_token=" + data;
                      break;
              }
          }
      });
  }

  // genQrcode();
});