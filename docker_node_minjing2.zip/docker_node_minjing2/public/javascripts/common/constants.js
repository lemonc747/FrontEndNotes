window.constants = {
    response_type: "response_type",
    code: "code",
    redirect_uri: "redirect_uri",
    state: "state",
    fromUrl: "fromUrl"
};