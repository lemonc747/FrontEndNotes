$(function () {
    var ctx = urlConfig.server.context;//web项目名
    var genQrcodeUrl = ctx + 'sso/qrcode';//生成二维码接口地址
    var checkUrl = ctx + 'sso/qrcode/check';//长连接检测是否已扫描登录接口地址
    var qrcodeImgEleId = 'qrcode';//html中二维码图片元素ID
    var refreshQrcodeEleId = 'qrcode';//html中刷新二维码图片元素ID
    var uuid;
    var curAjax;

    $("#refreshQrcode").click(function () {
        genQrcode();
    });

    function genQrcode() {
        if (curAjax) {
            curAjax.abort();
        }
        $.ajax({
            method: 'GET',
            url: genQrcodeUrl,
            async: false,
            success: function (obj) {
                uuid = obj.uuid;
                $("#" + qrcodeImgEleId).attr("src", obj.qrcodeUrl);
                check();
            }
        });
    }

    function check() {
        curAjax = $.ajax({
            method: 'GET',
            url: checkUrl + '?uuid=' + uuid + '&date=' + new Date().getTime(),
            success: function (data) {
                switch (data) {
                    case "pending":
                        check();
                        break;
                    case "expired":
                        genQrcode();
                        // alert('二维码已失效，请刷新二维码');
                        break;
                    default:
                        window.location.href = urlConfig.server.indexUrl + "?" + urlConfig.token + "=" + data;
                        break;
                }
            }
        });
    }

    genQrcode();
});