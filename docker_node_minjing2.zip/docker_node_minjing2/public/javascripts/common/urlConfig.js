window.urlConfig = (function () {
    /**客户端URL配置*/
        // var clientBaseUrls = ["http://172.19.255.31:8080/AppService"];//###Product###
    var clientBaseUrls = ["http://172.19.255.93:8080/AppService"];//###Test###
    // var clientBaseUrls = ["http://192.168.3.211"];//###Test###
    var cookieProt = {
        name: "/cookie",
        portNames: {
            set: "/set",
            destroy: "/destroy"
        }
    };

    var serverUrls = {
        home: "/home.html",
        login: "/login.html",
        logout: "/logout.html"
    };

    //通过网关调用服务，配置网关地址加服务名
 //   var root = "http://10.94.51.161:8004/ga/xinghuo-apaas-sso";//山西
//     var root = "http://20.0.36.97:80/ga/xinghuo-apaas-sso";//公安部
     var root = "http://68.61.8.125/szga/xinghuo-apaas-sso";//深圳市局
//    	var root ="http://68.72.86.251/szga/xinghuo-apaas-sso";//光明
//    var root = "http://20.0.4.224:8080/szga/xinghuo-apaas-sso";
//    var root="";

root = "http://172.29.3.76:9219/szga/xinghuo-apaas-sso";//深圳市局

    var serverProts = {
        login: root + "/sso/user/login",
        logout: root + "/sso/user/logout",
        registerDevelopers: root + "/sso/user/registerDevelopers",
        registerUser: root + "/sso/user/registerUser",
        developersVerify: root + "/sso/user/developersVerify",
        authorize: root + "/sso/oauth2/authorize"
    };

    function getPortArr(portName) {
        var portArr = [];
        for (var i = 0; i < clientBaseUrls.length; i++) {
            portArr.push(clientBaseUrls[i] + cookieProt.name + cookieProt.portNames[portName]);
        }
        return portArr;
    }


    /**服务端URL配置*/
    var serverBaseUrl = "";//local
    // var serverBaseUrl = "/sso";//docker&jmt
    // var serverBaseUrl = "http://192.168.3.211:88";//###Local###
    // var serverBaseUrl = "http://172.19.255.102:88";//###Test###
   //  var serverBaseUrl = "http://172.19.255.175/sso";//###DOCKER###
    // var serverBaseUrl = "http://172.29.3.41";//###JMT###

    return {
        token: "access_token",
        client: {
            setCookiePorts: getPortArr("set"),
            destroyCookiePorts: getPortArr("destroy")
        },
        server: {
            context: serverBaseUrl,
            indexUrl: 'http://172.19.255.104:5566/index.html',//深圳新平台
//            indexUrl: 'http://172.19.255.102:5566',//test
//            indexUrl: 'http://172.19.255.191',//docker
//            indexUrl:'http://20.0.36.65:80',//公安部一所
//            indexUrl:'http://10.94.51.163:8018/index.html',//山西
            loginUrl: serverBaseUrl + serverUrls.login,
            logoutUrl: serverBaseUrl + serverUrls.logout,
            loginPort: serverBaseUrl + serverProts.login,
            logoutPort: serverBaseUrl + serverProts.logout,
            registerDevelopersPort: serverBaseUrl + serverProts.registerDevelopers,
            registerUserPort: serverBaseUrl + serverProts.registerUser,
            developersVerifyPort: serverBaseUrl + serverProts.developersVerify,
            authorize: serverBaseUrl + serverProts.authorize
        }
    }
})();