// 切换测试与正式环境 => {0: JMT-映射 1：公安网-测试环境  2 公安网-正式环境}
const env = 0;

const projectContextPath = '/szga/xinghuo-apaas-node-minjing';// 项目部署路径
const currentLocation = location.protocol + '//' + location.host;// 域名
let serviceBaseUrl;// 统一接口前缀
let webSocketURL;// webSocket
let suppURL;// 通知公告，新闻
let dashboardWebSocketUrl;// 仪表盘webSocket
let taskManageURL;// 任务管理
let indexPage;// index页面
let loginPage;// 登录页面
if (env === 0) {
  indexPage = '/index.html';
  loginPage = '/login.html';
  serviceBaseUrl = 'http://172.29.3.76:9219/szga/xinghuo-apaas-';
  webSocketURL = "ws://172.19.255.196:219/websocketservice";
  suppURL="http://10.42.0.235:10001/supp";
  dashboardWebSocketUrl = "";
} else if (env === 1) {

} else if (env === 2) {
  indexPage = projectContextPath + '/index.html';
  loginPage = projectContextPath + '/login.html';
  serviceBaseUrl = currentLocation + '/szga/xinghuo-apaas-';//'http://68.61.8.125/szga/xinghuo-apaas-';
  webSocketURL =  "ws://68.61.8.125:1007/websocketservice";
  suppURL="http://10.42.0.235:10001/supp";
  dashboardWebSocketUrl = "ws://68.61.8.96:8080/websocketservice";
}

// 登录接口（不同于登录页面）
const ssoLoginURL = serviceBaseUrl + 'sso/sso/user/login';
// *********** 以下为接口相对地址
const mainNoticeServiceURL = "mainnoticeservice/mainnoticeservice";
const userserviceURL = "userservice/userservice";
const platformbaseURL = "platformbase/platformbase";
// 通知公告，新闻
// 收藏http://http://172.19.255.181
const collectserviceURL = "collectservice/collectservice";
// Ui服务
const uiURL = "uiservice/uiservice/ui";// "http://192.168.3.209:8080/ui";
// 上传视频
const videoserverURL = "videoserver/videoserver";
const appserviceURL = "appservice/appservice";
// 日历
const calendarserviceUrl = "calendarservice/calendarservice/calendar";
// 应用评论
const appCommentURL = "topic/topic";
// 仪表盘的ajax url 和websocket url
const dashboardServiceUrl = "dashboardservice/dashboard/";




// // 0: JMT-映射 1：公安网-测试环境  2 公安网-正式环境
// var env = 2;
// //JMT-测试环境
// var ssoLoginURL = "http://172.19.255.175/sso";
// //webSocket
// var webSocketURL = "ws://172.19.255.196:219/websocketservice";

// //通知公告，新闻
// var suppURL="http://10.42.0.235:10001/supp";

// //仪表盘

// var dashboardWebSocketUrl = "";

// var mainNoticeServiceURL = "mainnoticeservice/mainnoticeservice";

// var userserviceURL = "userservice/userservice";
// var platformbaseURL="platformbase/platformbase";
// //通知公告，新闻
// //收藏http://http://172.19.255.181
// var collectserviceURL="collectservice/collectservice";
// //Ui服务
// var uiURL="uiservice/uiservice/ui";//"http://192.168.3.209:8080/ui";//
// //上传视频
// var videoserverURL="videoserver/videoserver";
// var appserviceURL="appservice/appservice";
// //日历
// var calendarserviceUrl = "calendarservice/calendarservice/calendar";
// //应用评论
// var appCommentURL = "topic/topic";
// //仪表盘的ajax url 和websocket url
// var dashboardServiceUrl = "dashboardservice/dashboard/";

// if(env === 1){
//     ssoLoginURL = "http://172.19.255.175/sso";

//     // webSocketURL = "ws://172.19.255.196:219/WebSocketService";
//     webSocketURL =  "ws://172.19.255.93:8086/websocketservice";
//     //  webSocketURL =  "ws://192.168.3.209:8090";

//     //通知公告，新闻
//     suppURL="http://10.42.0.235:10001/supp";

// }

// if(env === 2){
//     ssoLoginURL = "http://68.61.8.125/szga/xinghuo-apaas-sso";

//     // webSocketURL =  "ws://68.61.8.96:8080/websocketservice";
//     webSocketURL =  "ws://68.61.8.125:1007/websocketservice";

//     //通知公告，新闻
//     suppURL="http://10.42.0.235:10001/supp";

//     dashboardWebSocketUrl = "ws://68.61.8.96:8080/websocketservice";
// }


// //公安部统一部署
// if(false){
//     ssoLoginURL = "http://20.0.36.97:2005/sso";
//     webSocketURL =  "ws://20.0.36.125:3008/websocketservice";

//     platformbaseURL="/platformbase";
//     //通知公告，新闻
//     suppURL="http://10.42.0.235:10001/supp";
//     //仪表盘的ajax url 和websocket url
//     dashboardWebSocketUrl = "ws://20.0.36.125:3008/websocketservice";
//     taskManageURL = '/qapp/leaderTask'
// }








