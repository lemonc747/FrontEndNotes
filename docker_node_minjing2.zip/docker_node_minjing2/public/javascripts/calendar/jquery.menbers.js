/**
 * @author 20180321 gya
 * 选择人员dom
 * 
 * options {
 *      key     type        return_type     return      required    default     description
 *      add     func        obj             new_menber  false       undefined   添加menber按钮
 *      remove  func        string          menber_id   false       undefined   
 *      menbers arr         undefined       ~           false       []          初始化menbers
 * }
 * 
 */

if (typeof jQuery === 'undefined') {
    throw new Error('Menbers plugin requires jQuery');
}

!function($, WIN){

    var Menbers = function(element, options){
        options = $.extend({}, $.fn.menbers.DEFAULT_OPTIONS, options);
        this.$el = $(element);
        this.options = options;
        this._init();
        this.rerenderView();
    }

    Menbers.prototype = {

        /**************************************************** private methods */

        _init: function(){
            this._initContainer();
            this._initData();
            this._bindEvents();
        },
        _initContainer: function(){
            this.$el.append([
                '<div  class="cal_Tip">参与人员</div>',
                '<div class="affPer">',
                    '<ul class="affPerul" >',
                        '<li class="m_add_menber"><img src="images/rl_add.png" alt="" style="width:35px;height:35px;cursor: pointer;"></li>',
                    '</ul>',
                '</div>'
            ].join(''));
        },
        _initData : function(){
            var menberList = [];
            Array.prototype.push.apply(menberList, this.options.menbers);
            this.$el.data("menbersList", menberList);
            this._initCurrentUserDom();
        },
        _initCurrentUserDom : function(){
            this.$el.find("ul").append([
                '<li style="width:60px;" class="m_me_menbers" data-m-userCode="">',
                    '<div><img src="images/communicate/men.png" alt=""><span style="display:block;">我</span></div></li>'
            ].join(''));
        },
        _bindEvents : function(){
            var that = this,
                options = this.options;
            this.$el.on("click", ".m_add_menber", options.add)
                .on("click", ".m_remove_menber", options.remove || function(){
                    var userCode = $(event.target).parent().attr("data-m-userCode");
                    that.removeMenber(userCode);
                });
    
        },
        //static
        _template : ['<li style="width:60px;" class="m_menbers" data-m-userCode="{{userCode}}">',
            '<div><img src="images/communicate/men.png" alt=""><span style="display:block;">{{userName}}</span></div>', 				
            '<span class="subscript m_remove_menber">x</span></li>'].join(""),

        _getNewPersonHtml : function(data){
            var template = this._template;
            return data && data.userCode && data.userName 
                ? template.replace("{{userCode}}", data.userCode).replace("{{userName}}", data.userName)
                : '';
        },

        _getCurUser : function(){
            //todo 获取当前用户userCode => bug:初始化时userData尚未获取到
            this.curUser = this.curUser || $.extend({}, WIN.userData);
            return this.curUser;
        },

        /**************************************************** public methods */
        addMenber : function(menber){
            // no-repeat
            var menbersList = this.$el.data("menbersList"),
                userCode = menber.userCode;
            //默认添加current userData
            if(userCode === this._getCurUser().userCode){
                return this;
            }
            for( var i=0,len=menbersList.length; i<len; i++){
                if(menbersList[i].userCode === userCode){
                    return this;
                }
            }
            this.$el.data("menbersList").push(menber);
            this.rerenderView();
            return this;
        },

        removeMenber : function(userCode){
            var menbersList = this.$el.data("menbersList");
            for( var i=0,len=menbersList.length; i<len; i++){
                if(menbersList[i].userCode === userCode){
                    menbersList.splice(i,1);
                    break;
                }
            }
            this.$el.data("menbersList", menbersList);
            this.rerenderView();
            return this;
        },

        rerenderView : function(){
            var $el = this.$el,
                $ul = $el.find("ul"),
                menbersList = $el.data("menbersList");
            $ul.find("li").remove(".m_menbers");
            if(menbersList){
                for(var i=0,len=menbersList.length; i<len; i++){
                    $ul.append(this._getNewPersonHtml(menbersList[i]));
                }
            }
            return this;
        },
        reset : function(){
            this.$el.data("menbersList", []);
            this.rerenderView();
            return this;
        },
		
		setData : function(data) {
			var newData = [];
			for( var i=0,len=data.length; i<len; i++){
                if(data[i].userCode !== this._getCurUser().userCode){
                    newData.push(data[i]);
                }
            }
			this.$el.data("menbersList", newData);
            this.rerenderView();
            return this;
		},	
        getData : function(){
            var menbersList = [];
            menbersList.push(this._getCurUser());
            Array.prototype.push.apply(menbersList, this.$el.data("menbersList"));
            // var menbersList = this.$el.data("menbersList") || [];
            // menbersList.push(this._getCurUser());
            return menbersList;
        }
        
    }

    // define jQuery plugin
    $.fn.menbers = function(options){
        var params = arguments;
        return this.each(function(){
            var $this = $(this),
                $data = $this.data("menbers");
            //options检测
            options = "object" === typeof options && options;
            if(!$data){
                $data = new Menbers(this, options);
                $this.data("menbers", $data);
            }

            //调用插件方法的另一种快捷方式
            if(typeof options === "string"){
                //menbers_methods.apply(menbers, arguments_1)
                $data[options].apply($data, [].prototype.slice.call(params, 1));
            }
        })
    }

    /************************************** Utils */
    //需要拓展时再添加helpers
    $.fn.menbers.helpers = {}
    $.fn.menbers.i18n = {}
    //允许修改default_options，或单独修改instance的options
    $.fn.menbers.DEFAULT_OPTIONS = {
        add : function(){ console.log("menbers default add func ")},
        remove : undefined,
        menbers: []
    }
}(window.jQuery, window);

