   //日历 控制
   $(function(){
// 	var postUrl = 'http://172.19.255.93:8082/CalendarService/calendar';
// 	var postUrl = "http://172.28.0.56:9113/CalendarService/calendar";
	//jmt
   	// var postUrl = "http://172.28.0.56:9116/xinghuo-apaas-CalendarService/calendar";
   	// var filePostUrl = "http://172.28.0.56:9116/xinghuo-apaas-CalendarService";
   	//公安网http://172.19.255.93:8085/xinghuo-apaas-CalendarService
	//var postUrl = "http://172.19.255.199/calendarservice/calendar";
	var filePostUrl = "s3fileservice/s3fileservice/",
		userCode = my_token,
		$partiPeople = $("#partiPeople");

   	//创建日历
   	$(".easyui-fullCalendar").fullCalendar();
   	//z注册一个获取当前日历显示日期回调
   	$(".easyui-fullCalendar").fullCalendar('getCDate',getCurrentDate);
   	//更新任务的信息函数
// 	$(".easyui-fullCalendar").fullCalendar('getNewTask',newTask);
	   //新建日程
   	$(".easyui-fullCalendar").fullCalendar('createNewTask',createNewTask);
   	//新建日程
   	$(".easyui-fullCalendar").fullCalendar('cancelAllTask',cancelAllTask);
   	//创建浮动人物框
   	$(".easyui-fullCalendar").fullCalendar('createFloatTask',createFloatTask);
   	//点击触发获取新数据
	$(".easyui-fullCalendar").fullCalendar('getMonthTask',getMonthTask);
   	//
   	$(".easyui-fullCalendar").css({"width":"100%"});

	//参与人员
	$partiPeople.menbers({
		add: function(){
			parent.getContacts(function(data){
				$partiPeople.data("menbers").addMenber(data);
			});
		}
	});

   	//当前选择的日期 月份 为准
   	var currentSelectDate;
   	//当前选择月份的天数
   	var currnetDaysCount;
   	function getCurrentDate(param){
   		var m = new Date().setMonth(param.month);
   		currentSelectDate =  new Date(m);
// 		console.log(currentSelectDate);
   		var x = currentSelectDate.setFullYear(param.year);
   		currentSelectDate =  new Date(x);
   		//现将日期设置为0 在获取天数（）
   		currentSelectDate.setDate(0);
   		currnetDaysCount = currentSelectDate.getDate();
   		month = param.month;
   		year = param.year;
   	}
   	var month,year;
   	//第一次触发
   	getMonthTask();

   	//获取当前月份的工作任务
   	function getMonthTask(){
   		//z注册一个获取当前日历显示日期回调
   		$(".easyui-fullCalendar").fullCalendar('getCDate',getCurrentDate);
//		console.log(month,year);

		if(month<10){
			var dateStr = year +"0"+ month;
		}else{
			var dateStr = year +""+ month;
		}
		var dataGo = {"date":dateStr};
		var params = {}
		params.accessToken = userCode;
		params.data = dataGo;
		params.type = 1;
		params = JSON.stringify(params);
   		XHSDK.ajax({
	            url:calendarserviceUrl+"/querySchedules",
	            type:"POST",
	            data:params,//'{"accessToken":"'+userCode+'","data":{"date":"'+dateStr+'"},"type":'+1+'}',
	            contentType:"application/json;charset=utf-8",
	            dataType:"json",
	            success:function(res){
	                if(res.code == 200 && res.data.length != 0){
	                	//处理获取的数据
	                 	dealWithData(res.data)
	                }else{
	                	clearItems();
	                	// layer.msg(month+"月无工作任务！！")
	                }
	            },
	            error:function(msg){
	                console.log("Error:",msg);
	            }
	    });
   	}

   	// var newTask = [];
   	//处理获取的数据 填充到UI
   	function dealWithData(data){
		console.log("data:",data)
		//notice: date每次使用都重新new一个
		var curDateTime = currentSelectDate.getTime();//currentSelectDate;//new Date();
		console.log("currentSelectDate:"+new Date(curDateTime));
		var daysOfMonth = new Date(new Date(curDateTime).setMonth(new Date(curDateTime).getMonth()+1, 1)-24*3600*1000).getDate();
		// 初始化||清空newTask数组
		var newTask = clearItems(daysOfMonth);
		// 查询新的日程推送消息
		var newScheID = $(".easyui-fullCalendar").data("newScheID");
		for(var i =0 ; i < data.length; i++){
			handleItemData(data[i], curDateTime, newTask, newScheID);
		}
		// console.log("newTask:"+newTask);
		$(".easyui-fullCalendar").fullCalendar('getNewTask',newTask);
   	}


	/**
	 * Schedule Obj {
	 * 		scheduleId		日程ID
	 * 		title			日程主题
	 * 		address			日程地址
	 * 		startTime		开始时间
	 * 		endTime			结束时间
	 * 		partiPeople		参与人员警号集合
	 * 		remindCycle		提醒周期
	 * 		repeatType		重复周期
	 * 		createTime		创建日程的时间
	 * 		remark			备注
	 * 		scheType		日程类型
	 * 		dataId			数据ID
	 * 		deleteDateList	取消某日期显示该日程的集合
	 * 		updateIdList	修改日程时存入修改后的ID集合
	 * 		lastUpdateTime	日程最后修改时间
	 * 		newScheFlag		是否是新的日程
	 * 		partiPeopleName:data.partiPeopleName,
	 *		partiPeople:	data.partiPeople
	 * }
	 *
	 * 取data.startTime作为游标cursor的起点，沿时间轴以repeatType为周期向右移动，
	 * 达到有效时间区间的endTime后终止。
	 *
	 * @param {*} data
	 * @param {*} curDateTime curDate.getTime()
	 * @param {*} newTask
	 * @param {*} newScheID 新的日程推送
	 */
   	function handleItemData(data, curDateTime, newTask, newScheID){
		// data.startTime data.endTime单位为秒，转换为毫秒
		var start = data.startTime*1000,
			end = data.endTime*1000,
			repeatType = data.repeatType,
			daysOfMonth = newTask.length,
			startTimeOfMonth = new Date(new Date(curDateTime).setDate(1)).setHours(0,0,0,0),
			endTimeOfMonth = new Date(new Date(curDateTime).setDate(daysOfMonth)).setHours(23,59,59,999),
			//取当月有效时间区间
			stFinal = Math.max(startTimeOfMonth, start),
			etFinal = endTimeOfMonth,
			cursor = start,
			expire = 1,
			whichDay = 0,
			MILLSECOND_OF_DAY = 24*3600*1000,
			//repeatType: 0 无 1 每天 2 每周 3 每两周 4 每月 5 每年
			CONST_REPEATTYPE = ["无","每天","每周","每两周","每月","每年"];

		//-1无 0 事件开始时 其他为对应分钟
		var remindStr;
		if(data.remindCycle == -1){
			remindStr = "无";
		}else if(data.remindCycle == 0){
			remindStr = "时间开始时间";
		}else{
			remindStr = data.remindCycle+"分钟后";
		}
		var addressStr = "";
		try {
			addressStr = JSON.parse(data.address).baiduAddr;
		} catch (error) {
			addressStr = data.address;
		}
		var itemT = {
			taskId:			data.scheId,
			taskTopic:		data.title,
			taskLocation: 	addressStr,
			taskStartTime:	new Date(parseInt(start)).Format("yyyy-MM-dd hh:mm"),
			taskEndTime:	new Date(parseInt(end)).Format("yyyy-MM-dd hh:mm"),
			taskWarring:	remindStr,
			taskOverCount:	CONST_REPEATTYPE[repeatType],
			taskOther:		data.remark,
			taskType:		data.scheType,
			taskRepeatType:	data.repeatType,
			taskFileUrl:	data.anexoURL,
			newScheFlag:	newScheID && newScheID == data.scheId,
			partiPeopleName:data.partiPeopleName,
			partiPeople:	data.partiPeople
		}

		if(repeatType == 5 || repeatType == 4){
			whichDay = new Date(cursor).getDate();
			newTask[whichDay].task.push(itemT);
		}else{
			if(repeatType == 3){
				expire = 14*MILLSECOND_OF_DAY;
			}else if(repeatType == 2){
				expire = 7*MILLSECOND_OF_DAY;
			}else if(repeatType == 1){
				expire = MILLSECOND_OF_DAY;
			}else{
				expire = MILLSECOND_OF_DAY;
				//rt=0不重复，时间区间终点在data.endTime而不是本月最后一天
				etFinal = Math.min(endTimeOfMonth, end);
			}

			while( cursor<=etFinal ){
				if(cursor< stFinal){
					cursor += (parseInt((stFinal - cursor)/expire)+1)*expire;
					continue;
				}
				whichDay = new Date(cursor).getDate();
				newTask[whichDay-1].task.push(itemT);
				cursor += expire;
			}
		}
   	}

	function clearItems(days){
		var newTask = [];
		for(var i = 0; i<days; i++){
			var items = {whichDay : i, task: []};
			newTask.push(items);
		}
		$(".easyui-fullCalendar").fullCalendar('getNewTask',newTask);
		return newTask;
	}

//    	//当前月是否匹配在开始和结束时间内
// 	function isMatchMonth(startTime,endTime){
// //		console.log(startTime.getMonth(),endTime.getMonth());
// //		console.log(currentSelectDate.getMonth());
// 		//0  开始时间在本月，结束时间也在本月 ；   1  开始时间在本月之前，结束时间在本月 ；  2开始时间在本月之前，结束时间在本月之后；   3 开始时间在本月，结束时间在本月之后
// 		var flag = -1;
// 		if(currentSelectDate.getMonth() == startTime.getMonth() && currentSelectDate.getMonth() == endTime.getMonth()){
// 			//console.log(true);
// 			flag = 0;
// 		}else if(currentSelectDate.getMonth() > startTime.getMonth() && currentSelectDate.getMonth() == endTime.getMonth()){
// 			flag = 1;
// 			//console.log(true);
// 		}else if(currentSelectDate.getMonth() > startTime.getMonth() && currentSelectDate.getMonth() < endTime.getMonth()){
// 			flag = 2;
// 		}else if(currentSelectDate.getMonth() == startTime.getMonth() && currentSelectDate.getMonth() < endTime.getMonth()){
// 			flag = 3;
// 		}
// 		return flag;
// 	}

	var floatdiv;
	function createFloatTask(div,taskInfo){
		if(floatdiv){
			floatdiv.remove();
		}
		floatdiv = $("<div>").addClass("cal_floatTaskInfo").appendTo(div).attr("taskId",taskInfo.taskId);
		var div_top = $("<div>").addClass("cal_top").appendTo(floatdiv);
		var div_remove = $("<div>").text("X").appendTo(div_top);
		$("<div>").addClass("cal_Tip").text("主题").appendTo(floatdiv);
		var topic = $("<div>").addClass("cal_value").text(taskInfo.taskTopic).appendTo(floatdiv);
		//显示参与人员
		$("<div>").addClass("cal_Tip").text("参与人员").appendTo(floatdiv);
		var topic = $("<div>").addClass("cal_value").text(taskInfo.partiPeopleName).appendTo(floatdiv);
		if(!!taskInfo.taskLocation){
			$("<div>").addClass("cal_Tip").text("地点").appendTo(floatdiv);
			var location = $("<div>").addClass("cal_value").text(taskInfo.taskLocation).appendTo(floatdiv);
		}
		$("<div>").addClass("cal_Tip").text("时间").appendTo(floatdiv);
		var startTime = $("<div>").addClass("cal_value").text(taskInfo.taskStartTime).appendTo(floatdiv);
		$("<div>").addClass("cal_Tip").text("到").appendTo(floatdiv);
		var endTime = $("<div>").addClass("cal_value").text(taskInfo.taskEndTime).appendTo(floatdiv);
		//var affPerson = $("<div>").addClass("affPerson").text("参与人员").appendTo(floatdiv)
		var waring = $("<div>").addClass("cal_value").text(taskInfo.taskWarring).appendTo(floatdiv);
//		$("<div>").addClass("cal_Tip").text("重复").appendTo(floatdiv);
//		var overCount = $("<div>").addClass("cal_value").text(taskInfo.taskOverCount).appendTo(floatdiv);
		$("<div>").addClass("cal_Tip").text("备注").appendTo(floatdiv);
//		console.log("备注；；",typeof taskInfo.taskOther);
		if(!!taskInfo.taskOther){
			taskInfo.taskOther = "无";
		}
		if(taskInfo.taskOther == ""){
			taskInfo.taskOther = "无";
		}
		var otherContent = $("<div>").addClass("cal_value").text(taskInfo.taskOther).appendTo(floatdiv);
		$("<div>").addClass("cal_Tip").text("附件").appendTo(floatdiv);
		if(!!taskInfo.taskFileUrl){
			$("<a>").attr("href",taskInfo.taskFileUrl).addClass("cal_value").text("点击下载附件").appendTo(floatdiv);
		}else{
			$("<a>").addClass("cal_value").text("无").appendTo(floatdiv);
		}
		var div_bottom = $("<div>").addClass("cal_bottom").appendTo(floatdiv);
		var modify = $("<div>").addClass("cal_createBtn").text("修改").appendTo(div_bottom);
		var cancle = $("<div>").addClass("cal_cancelBtn").text("取消").appendTo(div_bottom);
		//移除
		floatdiv.mouseleave(function(e){
			floatdiv.remove();
		});

		div_remove.click(function(e){
			floatdiv.remove();
		});

		cancle.click(function(){
			floatdiv.remove();
			//取消询问框
			layer.confirm('确定取消当前行程？', {
			  btn: ['是的','不了'] //按钮
			}, function(){
				cancelTask(taskInfo,false);
			}, function(){

			});
		});

		modify.click(function(){
			floatdiv.remove();
			//修改
//			$("#cal_bottomBtn").text("修改");
			createNewTask(taskInfo);
		});
	}


	//取消日程
	function cancelTask(taskInfo,isAll){
		//1 单个删除
		//2 全部删除（只对重复的记录使用）
		var cancelFlag = 1;
		//是否取消全部行程
		if(isAll){
			cancelFlag =2;
		}
		var paramdata = {};
		var da = {};
		da.scheId = taskInfo.taskId;
		da.cancelFlag = cancelFlag;
		da.opeDate = new Date().Format("yyyyMMdd");
		paramdata.accessToken = userCode;
		paramdata.type = 1;
		paramdata.data = da;
		paramdata = JSON.stringify(paramdata);
//		console.log(taskInfo);
		XHSDK.ajax({
            url:calendarserviceUrl+"/deleteSchedule",
            type:"POST",
            data:paramdata,
            contentType:"application/json;charset=utf-8",
            dataType:"json",
            success:function(res){
                if(res.code == 0 || res.code == 200){
                   layer.msg('你已经取消该行程!!!', {icon: 1});
                   	getMonthTask();
                }else if(res.code == 405){
                   layer.msg("没有权限删除该日程！");
                }else{
 					layer.msg("取消失败"+res.code);
				}
                closeAllLayer();
            },
            error:function(msg){
                console.log("Error:",msg);
            }
        });
	}

	//取消所有日程
	function cancelAllTask(){
		layer.confirm('是否取消所有日程！！',{icon: 3, title:'提示'}, function(index){
		 	XHSDK.ajax({
	            url:calendarserviceUrl+"/deleteAllSche",
	            type:"POST",
	            data:'{"accessToken":"'+userCode+'","type":'+1+'}',
	            contentType:"application/json;charset=utf-8",
	            dataType:"json",
	            success:function(res){
	                if(res.code == 0 ||res.code == 200){
	                   layer.msg("取消成功");
	                   clearItems();
	                }else{
	                    layer.msg("取消失败"+res.code);
	                }
	                closeAllLayer();
	            },
	            error:function(msg){
	                console.log("Error:",msg);
	            }
	        });
		});
	}
	 //关闭所有
    function closeAllLayer(){
        setTimeout(function(){
            parent.layer.closeAll();
        },500)
    }

	//创建
	function createNewTask(taskInfo){
		//消除悬浮
		if(!!floatdiv){
			floatdiv.remove();
		}
		// 任何时候都清除参与人员
		$("#partiPeople").data("menbers").reset();
		if(taskInfo){
			//不重复的日程//0 无 1 每天 2 每周 3 每两周 4 每月 5 每年
			if(taskInfo.taskRepeatType == 0){
				$("#cal_bottomBtn").text("修改");
				$("#my_file1").val("");
				//修改日程
				//显示数据
				console.log("0000000000000000000000000",taskInfo);
				reDisplayData(taskInfo);
				//修改
				$("#cal_bottomBtn").click(function(){

					layer.load(1,{shade:0.5})

					$("#cal_bottomBtn").unbind("click");
					layer.closeAll("page"); //关闭所有层
					taskInfo = getVal(taskInfo);
					var file = $('#my_file1')[0].files[0];
					if(!!file){
						var formData = new FormData();
						formData.append("fileList",file);
						formData.append("userId",userData.userId);
						formData.append("userName",userData.userName);
						formData.append("terminalType",1);
						formData.append("organization",userData.dept.name);
						formData.append("organizationId",userData.deptCode);

						XHSDK.ajax({
							url:filePostUrl+"s3/file/uploadByIStream",
							type: "POST",
							contentType: false,
							processData: false,
							mimeType:"multipart/form-data",
							data: formData,
							success: function(res){
								res = JSON.parse(res);
								if(res.code == 200){
									creatTask(res.data[0].fileUrl);
								}
							},
							error: function(msg) {
								console.log("Error---------:",msg);
							}
						});
					}else{
						modifyTask("");
					}
					function modifyTask(anexoURL){
						var paramd = {};
						var dd = {};
						dd.scheId = taskInfo.taskId;
						dd.title = taskInfo.taskTopic;
						dd.address = taskInfo.taskLocation;
						dd.startTime = taskInfo.taskStartTime;
						dd.endTime = taskInfo.taskEndTime;
						dd.partiPeople = taskInfo.partiPeople;
						dd.remindCycle = taskInfo.taskWarring;
						dd.repeatType = taskInfo.taskOverCount;
						dd.remark =taskInfo.taskOther;
						dd.scheType = taskInfo.taskType;
						if(!!anexoURL){
							dd.anexoURL = anexoURL;
						}else{
							dd.anexoURL = taskInfo.taskFileUrl;
						}
						dd.opeDate = new Date().Format("yyyyMMdd");
						dd.updateFlag = 1;
						paramd.data = dd;
						paramd.type = 1;
						paramd.accessToken = userCode;
						paramd = JSON.stringify(paramd);
						XHSDK.ajax({
				            url:calendarserviceUrl+"/updateSchedule",
				            type:"POST",
				            data:paramd,
				            contentType:"application/json;charset=utf-8",
				            dataType:"json",
				            contentType:"application/json;charset=utf-8",
				            dataType:"json",
				            success:function(res){
				                if(res.code == 200){
			                  		layer.msg('修改成功！', {icon: 1});
				                  	getMonthTask()
				                }else{
				                    layer.msg("修改失败");
				                }
				                closeAllLayer();
				                //隐藏
						  		$('#cal_createPage').hide();
				            },
				            error:function(msg){
				                console.log("Error:",msg);
				            }
				        });
					}
				});
			}else{
				$("#cal_bottomBtn").text("修改当天");
				//修改日程
				$("#cal_bottomBtndd").css({"display":""})
				//修改
				$("#cal_bottomBtn").click(function(){
					$("#cal_bottomBtn").unbind("click");
					layer.closeAll("page"); //关闭所有层
				 	layer.msg('修改成功！', {icon: 1});
				 	//隐藏
				 	$("#taskfileInfo").hide();
			  		$('#cal_createPage').hide();
				});
			}
		}
		else{

		   var userInfo = parent.userData;

        //    $(".affPerul").html('<li><div><img src="../images/policeicon.png" alt="头像" /><span>'+userInfo.userName+'</span></div></li><li class="addUser" ><img src="../images/rl_add.png" alt="头像" /></li>');
        //    $(".addUser").click(function(){
		// 		var divWidth = $(".affPer").width();
		// 		liNum =  parseInt(divWidth/55);
		// 		console.log("divWidth：",divWidth,"liNum：",liNum);
		// 		parent.getContacts(getPersonInfo);
		//   })

			$("#cal_bottomBtn").text("创建");
			$("#taskfileInfo").hide();
			//清空面版数据
			clearUIData();
			//创建
			$("#cal_bottomBtn").click(function(){

				//校验字段
				var isOk = checkFiled();
				if(!!isOk){
					$("#cal_bottomBtn").unbind("click");
				}else{
					layer.msg("请完善详细信息！！！");
					return;
				}
				//上传文件
				var file = $('#my_file1')[0].files[0];
				if(!!file){
					var formData = new FormData();
				    formData.append("fileList",file);
					formData.append("userId",userData.userId);
					formData.append("userName",userData.userName);
					formData.append("terminalType",1);
					formData.append("organization",userData.dept.name);
					formData.append("organizationId",userData.deptCode);

				    XHSDK.ajax({
				        url:filePostUrl+"s3/file/uploadByIStream",
				        type: "POST",
				        contentType: false,
				        processData: false,
				        mimeType:"multipart/form-data",
				        data: formData,
				        success: function(res){
				            res = JSON.parse(res);
				            if(res.code == 200){
				            	creatTask(res.data[0].fileUrl);
				            }
				        },
				        error: function(msg) {
				            console.log("Error---------:",msg);
				        }
				    });
				}else{
					creatTask("");
				}

				function creatTask(anexoURL){
					//获取面板上的值
					var dd = {
						taskId:"",					//id
			 			taskTopic:"",				//主题
			 			taskLocation:"",				//地点
			 			taskStartTime:"",		//开始时间
			 			taskEndTime:"",			//结束时间
			 			taskWarring:"",				//
			 			taskOverCount:'',
			 			taskOther:"",
			 			taskType:1,
			 			taskRepeatType:""
					}
					taskInfo = getVal(dd);

					// var userIds = userIdsArr.toString();

					// console.log("userIds:",userIds+"\n"+"userName：",userName);

					var newTaskC = {};
					var newTaskCD = {};
					newTaskCD.title = taskInfo.taskTopic;
					newTaskCD.address = taskInfo.taskLocation;
					newTaskCD.startTime = taskInfo.taskStartTime;
					newTaskCD.endTime = taskInfo.taskEndTime;
					newTaskCD.partiPeople = taskInfo.partiPeople;
					// newTaskCD.partiPeople = userName;//参与人员名字
					// newTaskCD.userIds = userIds;//参与人员Id
					newTaskCD.remindCycle = taskInfo.taskWarring;
					newTaskCD.repeatType = taskInfo.taskOverCount;
					newTaskCD.remark =taskInfo.taskOther;
					newTaskCD.scheType = taskInfo.taskType;
					newTaskCD.anexoURL = anexoURL,
					newTaskC.data = newTaskCD;
					newTaskC.type = 1;
					newTaskC.accessToken = userCode;
					newTaskC = JSON.stringify(newTaskC);

					XHSDK.ajax({
			            url:calendarserviceUrl+"/addSchedule",
			            type:"POST",
			            data:newTaskC,
			            contentType:"application/json;charset=utf-8",
			            dataType:"json",
			            contentType:"application/json;charset=utf-8",
			            dataType:"json",
			            success:function(res){
			                if(res.code == 200){
			                	layer.msg('创建成功！', {icon: 1});
			                	getMonthTask();
			                }else{
			                    layer.msg("操作失败");
							}
							// todo 关闭联系人层 & 清空选择人员
							$("#partiPeople").data("menbers").reset();
							$("#contacts").hide();
			                closeAllLayer();
			            },
			            error:function(msg){
			                console.log("Error:",msg);
			            }
			        });
				}
		 	//隐藏
	  		$('#cal_createPage').hide();
			});
		}
		//取消
		$("#cal_bottomCancelBtn").click(function(e){
			console.log("关闭");
			$("#cal_bottomBtn").unbind("click");
			layer.closeAll(); //关闭所有层
			//隐藏
	  		$('#cal_createPage').hide();
		});
		//捕获页
		layer.open({
		  	type: 1,
		  	shade: false,
	  		title: false, //不显示标题,
		  	area: ['350px', '560px'],
		  	content: $('#cal_createPage'), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
		  	cancel: function(){
		  		//隐藏
		  		console.log("ddd");
		  		$('#cal_createPage').hide();
//			    layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', {time: 5000});
		  		$("#cal_bottomBtn").unbind("click");
		  	}
		});
	}

//     var liNum;
//     var k = 1;
//     var flag = true;

//     var userIdsArr = [];


// function getPersonInfo(data){
// 	console.log("data:",data);//,/''+data.userCode+/',/''+data.userName+/'
// 	var k = 0;
//     var dataLi = "";
//     for(var i = 0; i<data.length; i++){
//     	dataLi += '<li id="'+data.userCode+'"><div><img src="../images/policeicon.png" alt=""><span>'+data.userName+'</span></div><span class="subscript" onclick="removerUser(this)">X</span></li>'
//     }
//     $(".addUser").before(data);
//     k++;
//     if(k > linNum - 2 && flag == true){
//        $(".a1 ul").append('<li onclick="moUp(1)" class="moUp">收起</li>');
//        flag = false;
//     }

//     userIdsArr.push(data.userName);
// }

// //查看更多参与人员
// function MoreUP(status){
//    if(status == 0){
//         $(".affPer").css({
//             width:"100%",
//             overflow:"visible",
//             height:"inherit"
//         });
//         $(".moUp").remove();
//         $(".affPerul").append('<li onclick="moUp(1)" class="moUp">收起</li>');
//      $(".a1 ul").append(' <li class="addUser" onclick="addData()"><img src="img/add.png" alt=""></li>');

//     }else {
//         $(".affPer").css({
//             width:"300px",
//             overflow:"hidden",
//             height:"66px"
//         });
//         $(".moUp").remove();
//         console.log("aaa",$(".a1 ul li").eq(3));
//         $(".affPer li").eq(3).before('<li onclick="moUp(0)" class="moUp">查看更多</li>');

//     }
// }

// //删除参与人员
// function removerUser(this_,userid,username){
//  $(this_).parent("li").remove();

//  userIdsArr.remove(data.userName);
//      k--;
//      if(k < linNum - 1){
//          $(".moUp").remove();
//      }
// }
	function clearUIData(){
		$("#titleTask").val("");
		$("#lacationTask").val("");
		$(".cal_startDate").val(""+new Date().Format("yyyy-MM-dd"));
		$(".cal_startTime").val(""+new Date().Format("hh:mm"));
		$(".cal_endDate").val(""+new Date().Format("yyyy-MM-dd"));
		$(".cal_endTime").val(""+new Date().Format("hh:mm"));
		$("#warningTask").find("option[val= 无]").attr("selected",true);
		$("#repeatTask").find("option[val=无]").attr("selected",true);
		$("#remarkTask").val("");
	}

	function reDisplayData(taskInfo){
		$("#titleTask").val(taskInfo.taskTopic)
		$("#lacationTask").val(taskInfo.taskLocation)
		if(!!taskInfo.taskFileUrl){
			$("#taskfileInfo").show();
			$("#fileInfo").attr("href",taskInfo.taskFileUrl)
		}else{
			$("#taskfileInfo").hide();
		}
		var startDT = taskInfo.taskStartTime.split(" ");
		var endDT = taskInfo.taskEndTime.split(" ");
		$(".cal_startDate").val(startDT[0]);
		$(".cal_startTime").val(startDT[1]);
		$(".cal_endDate").val(endDT[0]);
		$(".cal_endTime").val(endDT[1]);
		$("#warningTask").find("option[val= "+ taskInfo.taskWarring +"]").attr("selected",true);
		$("#repeatTask").find("option[val= "+ taskInfo.taskOverCount +"]").attr("selected",true);
		$("#remarkTask").val(taskInfo.taskOther);
		displayPartiPeople(taskInfo);
	}

	function displayPartiPeople(taskInfo){
		//参与人员
		if(taskInfo.partiPeople && taskInfo.partiPeopleName){
			// 去除首尾逗号
			var partiPeople = taskInfo.partiPeople.substring(1,taskInfo.partiPeople.length-1).split(',');
			var partiPeopleName = taskInfo.partiPeopleName.split(',');
			var data = [];
			for(var i=0,len=partiPeople.length; i<len; i++){
				if(partiPeople[i]){
					var item = {};
					item.userCode = partiPeople[i];
					// 假设code和name是一致的
					item.userName = partiPeopleName[i];
					data.push(item);
				}
			}
			$partiPeople.data("menbers").setData(data);
		}
	}
	//校验字段
	function checkFiled(){
		if($("#titleTask").val() == "")
			return false;
		if($(".cal_startDate").val() == "" &&
			$(".cal_startTime").val(startDT[1]) == ""
			&&$(".cal_endDate").val(endDT[0])== ""
			&&$(".cal_endTime").val(endDT[1])== ""){
				return false;
		}
		return true;
	}

	//获取面板的值
	function getVal(taskInfo){
		taskInfo.taskTopic = $("#titleTask").val();
		taskInfo.taskLocation = $("#lacationTask").val();
		taskInfo.taskStartTime = $(".cal_startDate").val() +" "+ $(".cal_startTime").val();
		taskInfo.taskEndTime = $(".cal_endDate").val()+ " "+$(".cal_endTime").val();

		// @20180323
		//-1无 0 事件开始时，其他为对应分钟
		//0 无 1 每天 2 每周 3 每两周 4 每月 5 每年
		// var ww = $("#warningTask").val();
		// var ree = $("#repeatTask").val();
		taskInfo.taskWarring = $("#warningTask").val();
		taskInfo.taskOverCount = $("#repeatTask").val();
		//获取partiPeople
		taskInfo.partiPeople = $("#partiPeople").data("menbers").getData()
			.reduce(function(pre, cur){
				if(typeof cur === "object"){
					pre += cur.userCode + ",";
				}
				return pre;
			}, ",");
		//-1无 0 事件开始时 其他为对应分钟
		// taskInfo.taskWarring = -1;
		// if(ww == "无" || ww == ""){
		// 	taskInfo.taskWarring = -1;
		// }else if(ww == "事件开始时"){
		// 	taskInfo.taskWarring = 0;
		// }else if(ww == "提前五分钟"){
		// 	taskInfo.taskWarring = 5;
		// }else {
		// 	taskInfo.taskWarring = 15;
		// }
		//0 无 1 每天 2 每周 3 每两周 4 每月 5 每年
		// taskInfo.taskOverCount = 0;
		// if(ree == "无"){
		// 	taskInfo.taskOverCount = 0;
		// }else if(ree == "每天"){
		// 	taskInfo.taskOverCount = 1;
		// }else if(ree == "每周"){
		// 	taskInfo.taskRepeatType = 2;
		// }else if(ree == "每两周"){
		// 	taskInfo.taskOverCount = 3;
		// }else if(ree ==  "每月"){
		// 	taskInfo.taskOverCount = 4;
		// }else if(ree ==  "每年"){
		// 	taskInfo.taskOverCount = 5;
		// }
		taskInfo.taskOther = $("#remarkTask").val();
		return taskInfo;
	}

	//开始日期
	laydate.render({
	  	elem: '.cal_startDate',
	  	format: 'yyyy-MM-dd',
	  	value:new Date(),
	  	done:function(value,date){
	  		$(".cal_endDate").val(new Date(value.replace(/-/g,'/')).Format("yyyy-MM-dd"));
	  	}
	});
	//结束日期
	var endDate = laydate.render({
	  	elem: '.cal_endDate',
	  	format:'yyyy-MM-dd',
	  	value:new Date(),
	  	done:function(value,date){
	  		console.log($(".cal_startDate").val());
	  		var startDate = new Date($(".cal_startDate").val().replace(/-/g,'/')).getTime();
	  		var endDate = new Date(value.replace(/-/g,'/')).getTime();
	  		if(startDate >= endDate){
	  			$(".cal_startDate").val(value);
	  		}
	  	}
	});
	//开始时间
	laydate.render({
	  	elem: '.cal_startTime',
	  	type: 'time',
	  	min:"8:00:00",
  		max:"18:00:00",
	  	value:new Date(),
	  	done:function(value,date){
	  	}
	});

	//结束时间
	laydate.render({
	  	elem: '.cal_endTime',
	  	type: 'time',
	  	value:new Date(),
	  	done:function(value,date){
	  	}
	});
   });

