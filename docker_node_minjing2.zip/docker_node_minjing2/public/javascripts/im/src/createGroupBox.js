function createGroupBox(){
	'use strict';
	
	var createCGroupBox = function(){
		var CGBOx = $('<div>').addClass('im_addBox').addClass('im_CreateBox');
		var addHead = $('<div>').addClass('im_addHead');
		var addtitlePic = $('<div>').addClass('im_addspanPic');
		var addtitle = $('<span>').addClass('im_addspanText').text("创建群组");
		var addRemove = $('<span>').addClass('im_addspanText').addClass('im_optionflagAdd').text("X");
		
		addtitlePic.appendTo(addHead);
		addtitle.appendTo(addHead);
		addRemove.appendTo(addHead);
		addHead.appendTo(CGBOx);
		
		var CGBody = $('<div>').addClass('im_CGBody');
		CGBody.appendTo(CGBOx);
		var bodyLeft = $('<div>').addClass('im_groupBodyLeft');
		bodyLeft.appendTo(CGBody);
		var searchArea = $('<div>').addClass('searchArea');
		var searchAreaInput = $('<input>').addClass('im_searchinput');
		var searchAreaImg = $('<img>').attr('src','./images/search.png');
		searchAreaInput.appendTo(searchArea);
		searchAreaImg.appendTo(searchArea);
		searchArea.appendTo(bodyLeft);
		var createGroup = $('<div>').addClass('im_createGroup').text('联系人');
		createGroup.appendTo(bodyLeft);
		var createGList = $('<div>').addClass('im_createCList');
		createGList.appendTo(bodyLeft);
		
		for(var i = 0;i<5;i++){
			var item = GetCreateItems();
			item.appendTo(createGList);
		}
		
		var bodyRight = $('<div>').addClass('im_groupBodyRight');
		bodyRight.appendTo(CGBody);
		var choosedGroup = $('<div>').addClass('im_choosedGroup').text('已选联系人');
		choosedGroup.appendTo(bodyRight);
		var choosedList = $('<div>').addClass('im_choosedList');
		choosedList.appendTo(bodyRight);
		
		for(var i = 0;i<5;i++){
			var item = GetChooseItems();
			item.appendTo(choosedList);
		}
		
		var CGBtnDiv = $('<div>').addClass('im_CGBtnDiv');
		var CGBtnCancle = $('<button>').addClass('im_CGcancle').text('取消');
		var CGBtnConfirm = $('<button>').addClass('im_CGconfirm').text('确定');
		CGBtnCancle.appendTo(CGBtnDiv);
		CGBtnConfirm.appendTo(CGBtnDiv);
		CGBtnDiv.appendTo(bodyRight);

		CGBOx.appendTo('body');
		//拖动
		$(function(){
			CGBOx.Tdrag({
				scope:"body",
    			handle:".im_addHead"
			});
		});
		
		addRemove.click(function(){
			CGBOx.remove();
		});
	}
	
	this.createCGroupBox = createCGroupBox;
}

function GetCreateItems(){
	var item = $('<div>').addClass('im_createItem');
	var createRoleItem = $('<div>').addClass('im_createRoleItem');
	var addRoleimg = $('<img>').addClass('im_addRoleImg').attr('src','./images/communicate/men.png');
	addRoleimg.appendTo(createRoleItem);
	createRoleItem.appendTo(item);
	var createText = $('<div>').addClass('im_createText');
	var nameP = $('<p>').addClass('im_createname').text("赵东来");
	var msgP = $('<p>').addClass('im_createmsg').text('快乐开开快乐快乐开开');
	nameP.appendTo(createText);
	msgP.appendTo(createText);
	createText.appendTo(item);
	var checkBoxDiv = $('<div>').addClass("im_createCheckBoxDiv");
	var checkBox = $('<div>').addClass('im_createCheck');
	checkBox.appendTo(checkBoxDiv);
	checkBoxDiv.appendTo(item);
	
	checkBox.click(function(e){
		$(e.target).hide();
	});
	
	item.click(function(e){
		console.log($(e.target).children(".im_createCheckBoxDiv"));
		$(e.target).children('.im_createCheckBoxDiv').children(".im_createCheck").show();
	});
	
	return item;
}

function GetChooseItems(){
	var chooseItem = $('<div>').addClass('im_createItem');
	var chooseRoleItem = $('<div>').addClass('im_createRoleItem');
	var chooseRoleimg = $('<img>').addClass('im_addRoleImg').attr('src','./images/communicate/men.png');
	chooseRoleimg.appendTo(chooseRoleItem);
	chooseRoleItem.appendTo(chooseItem);
	var createText1 = $('<div>').addClass('im_createText');
	var nameP1 = $('<p>').addClass('im_createname').text("赵东来");
	var msgP1 = $('<p>').addClass('im_createmsg').text('快乐开开快乐快乐开开');
	nameP1.appendTo(createText1);
	msgP1.appendTo(createText1);
	createText1.appendTo(chooseItem);
	var checkBoxDiv1 = $('<div>').addClass("im_createCheckBoxDiv");
	var checkBox1 = $('<div>').addClass('im_removechoosed');
	checkBox1.appendTo(checkBoxDiv1);
	checkBoxDiv1.appendTo(chooseItem);
	
	checkBox1.click(function(e){
		$(e.target).parent().parent().remove();
	});
	
	return chooseItem;
}
