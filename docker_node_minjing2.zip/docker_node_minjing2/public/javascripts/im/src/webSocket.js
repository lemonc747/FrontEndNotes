function webConnect(){
	var socket;
	// console.log(socket);
	
	//分发消息
	var dispatch;
	var init = function(func){
		dispatch = func;
	}
	
	var timestamp = new Date().getTime();
	
	var disconnect = function(){
		console.log("断开连接");
		socket.emit('disconnect', timestamp);
	}
	
	var connect = function(){
		console.log("连接");
		this.connectServer();
		//接收服务器应答验证消息
		socket.on("fromServer", function(msg) {
		   	console.log(msg);
	   	});
	   	//通讯
	   	socket.on("transfer",function(data){
			dispatch(data);
		});
	}
	
	var send = function(data){
//		console.log("发消息",data)
		socket.emit('transfer', data);
	}
	
	var connectServer = function(){
		socket = io.connect(httpUrl); //与服务器进行连接
		socket.on('connect', function() {
		    console.log("连接成功,当前的时间戳："+timestamp);
		    var data = {id:"6554"}
		    socket.emit('fromClient', data);
		});
	}
	
	this.init  = init;
	this.send = send;
	this.connect = connect;
	this.connectServer = connectServer;
	this.disconnect = disconnect; 
}
