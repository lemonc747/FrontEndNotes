function addFriendBox(){
	'use strict';
	
	var createAddFriendBox = function(){
		var addFBox = $('<div>').addClass('im_addBox');
		var addHead = $('<div>').addClass('im_addHead');
		var addtitlePic = $('<div>').addClass('im_addspanPic');
		var addtitle = $('<span>').addClass('im_addspanText').text("添加好友/群");
		var addRemove = $('<span>').addClass('im_addspanText').addClass('im_optionflagAdd').text("X");
		addtitlePic.appendTo(addHead);
		addtitle.appendTo(addHead);
		addRemove.appendTo(addHead);
		addHead.appendTo(addFBox);
		
		var addBody = $('<div>').addClass('im_addBody');
		var addChoiceDiv = $('<div>').addClass('im_addChoiceDiv');
		var addConnect = $('<span>').addClass('im_addConnect').text("联系人");
		var addGroup = $('<span>').addClass('im_addGroup').text("群组");
		addConnect.appendTo(addChoiceDiv);
		addGroup.appendTo(addChoiceDiv);
		addChoiceDiv.appendTo(addBody);
		
		var addInput =  $('<div>').addClass('im_addInput');
		var addSearchTip = $('<span>').addClass('im_addtext').text('通过警务云好查找：');
		var addSearchArea =  $('<div>').addClass('searchArea');
		var addSearchInput = $('<input>').addClass('im_searchinput');
		var addSearchImg = $('<img>').attr("src","./images/search.png");
		var addNextBtnDiv = $('<div>').addClass('im_addNextBtnDiv');
		var addNextBtn = $('<button>').addClass('im_addNext').text("下一步");
		
		addSearchTip.appendTo(addInput);
		addSearchInput.appendTo(addSearchArea);
		addSearchImg.appendTo(addSearchArea);
		addSearchArea.appendTo(addInput);
		addInput.appendTo(addBody);
		addNextBtn.appendTo(addNextBtnDiv);
		addNextBtnDiv.appendTo(addBody);
		
		addBody.appendTo(addFBox);
		
		var addBottom = $('<div>').addClass('im_addBottom');
		var addRoleInfo = $('<div>').addClass('im_addRoleInfo');
		var addRoleImg = $('<img>').attr("src","./images/communicate/men.png");
		var addRoleText = $('<span>').addClass('im_addRoleText').text('白百何（1825458584844');
		var addfriendBtnDiv = $('<div>').addClass('im_addNextBtnDiv');
		var addfriendBtn = $('<button>').addClass('im_addNext').text("加为好友");
		
		addRoleImg.appendTo(addRoleInfo);
		addRoleText.appendTo(addRoleInfo);
		addRoleInfo.appendTo(addBottom);
		addfriendBtn.appendTo(addfriendBtnDiv);
		addfriendBtnDiv.appendTo(addBottom);
		
		addBottom.appendTo(addFBox);
		
		addFBox.appendTo('body');
		//拖动
		$(function(){
			addFBox.Tdrag({
				scope:"body",
    			handle:".im_addHead"
			});
		});
		addRemove.click(function(){
			addFBox.remove();
		});
		//隐藏
		addBottom.css({
				'display': 'none'
			});
		addNextBtnDiv.click(function(){
			addBottom.css({
				'display': ''
			});
		});
		addfriendBtnDiv.click(function(){
			addBottom.css({
				'display': 'none'
			});
		});
		activeChoic(1);
		addConnect.click(function(e){
			activeChoic(1);
		});
		addGroup.click(function(e){
			activeChoic(2);
		});
		function activeChoic(flag){
			addConnect.css({
				'background-color': 'white',
				'color':'grey'
			});
			addGroup.css({
				'background-color': 'white',
				'color':'grey'
			});
			if(flag==1){
				addConnect.css({
					'background-color': 'rgba(74,137,220,1)',
					'color':'white'
				});
			}
			if(flag==2){
				addGroup.css({
					'background-color': 'rgba(74,137,220,1)',
					'color':'white'
				});
			}
		}
	}
	
	this.createAddFriendBox = createAddFriendBox;
}
