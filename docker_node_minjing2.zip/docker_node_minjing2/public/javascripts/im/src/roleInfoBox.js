function RoleInfoBox(){
	'use strict';
	'use strict';
	//创建聊天窗口
	var createChatBox;
	//发送邮件
	var sendEmail;
	//好友动态
	var friendState;
	
	var init = function(func){
		createChatBox = func.createChatBox;
		friendState = func.friendState
		sendEmail = func.sendEmail;
	}
	
	var createRoleInfoBox = function(){
	
		var RoleBox = $("<div>").addClass("im_roleInfoBox");
		var RoleUp = $("<div>").addClass("im_roleUp");
		RoleUp.appendTo(RoleBox);
		
		var RoleUpHead = $("<div>").addClass("im_roleHead");
		RoleUpHead.appendTo(RoleUp);
		
		var RoleUpHPic = $("<div>").addClass("im_roleHImagePic");
		var RoleUpHImg = $("<img>").addClass("im_roleHImage").attr("src","./images/policeicon.png");
		RoleUpHImg.appendTo(RoleUpHPic);
		var RoleUpSexImg = $("<img>").addClass("im_rolsexImage").attr("src","./images/communicate/sex.png");
		var RoleUpRemove = $("<div>").addClass("im_remove").text("X");
		RoleUpSexImg.appendTo(RoleUpHead);
		RoleUpRemove.appendTo(RoleUpHead);
		RoleUpHPic.appendTo(RoleUpHead)
		
		var RoleMiddle = $("<div>").addClass("im_roleMiddle");
		RoleMiddle.appendTo(RoleBox);
		var RoleMText = $("<div>").addClass("im_roleText");
		
		var RoleName =  $("<p>").addClass("im_roleName").text("赵东来");
		var RoleDep =  $("<p>").addClass("im_roleDep").text("深圳市公安局");
		var RoleFuncs = $("<div>").addClass("im_roleFuncs");
		
		var MsgFuncImage = $("<img>").addClass("im_funImage").attr("src","./images/communicate/message.png");
		var EmailFuncImage = $("<img>").addClass("im_funImage").attr("src","./images/communicate/email.png");
		var DTFuncImage = $("<img>").addClass("im_funImage").attr("src","./images/communicate/dongtai_active.png");
		MsgFuncImage.appendTo(RoleFuncs);
		EmailFuncImage.appendTo(RoleFuncs);
		DTFuncImage.appendTo(RoleFuncs);
		
		RoleName.appendTo(RoleMText);
		RoleDep.appendTo(RoleMText);
		RoleFuncs.appendTo(RoleMText);
		RoleMText.appendTo(RoleMiddle);
		
		var RoleDown = $("<div>").addClass("im_roleDown");
		RoleDown.appendTo(RoleBox);
		
		var RoleDownTL = $("<div>").addClass("im_roleTextList");
		RoleDownTL.appendTo(RoleDown);

		for (var i = 0 ; i < 5 ; i++ ) {
			var textItem = createTextItem();
			textItem.appendTo(RoleDownTL);
		}
		
		RoleBox.appendTo('body');
		//拖动
		$(function(){
			RoleBox.Tdrag({
				scope:"body",
    			handle:".im_roleUp"
			});
		});
		
		RoleUpRemove.click(function(e){
			$(e.target).parent().parent().parent().remove();
		});
		
		//发消息
		MsgFuncImage.click(function(){
			createChatBox("6554");
		});
		//发邮件
		EmailFuncImage.click(function(){
			sendEmail();
		});
		//动态
		DTFuncImage.click(function(){
			friendState();
		});
		
		
	}
	
	this.createRoleInfoBox = createRoleInfoBox;
	this.init = init;
}

function createTextItem(){
	var textItem =  $("<div>").addClass("im_roleTextItem");
	var textTitle = $("<div>").addClass("im_title").text("公司名");
	textTitle.appendTo(textItem);
	var textContent = $("<div>").addClass("im_contents").text("黑洞的科技有");
	textContent.appendTo(textItem);
    return textItem;
}
