var httpUrl = "http://172.19.255.102:8888";
//index.js
//消息列表
var msgList =new msgList();
//初始化
	var createChatBox;
	var createPerson;
	var sendEmail;
	var friendState;
	var deteleFriend;
	var removeConv;
var func = {
	createChatBox:createFloatChatBox,
	createPerson:createFloatPersonBox,
	sendEmail:createFloatCEmail,
	friendState:CreateFloatState,
	deteleFriend:CreateFloatDeteleF,
	removeConv:removeConv
};
//初始化注册函数
msgList.init(func);
//当前的消息列表的item 
var msgItemList = [];
//消息列表的创建
var selfImid =  "6554";
var param = {imid:selfImid};
$.post(httpUrl+'/msgList',param,function(res){
//		console.log(res.data);
		msgList.createMsgList(res.data);
		msgItemList = msgList.itemArray;
});

//通讯录
var addressList = new addressList();
addressList.init(func);
//第一次请求
GetAdressList(httpUrl+"/org/allOrg/childOrg",null,addressList.createAddressList);
function GetAdressList(url,params,callback){
    //console.log(url);
	$.get(url,function(res){
		var ss = [];
		//console.log(res.result);
		ss.push(res.result);
		callback(ss);
	});
}

//webSocket处理
 // var webConnect = new webConnect();
 // webConnect.init(receive);
 // webConnect.connect();
 
function send(c_id,msgContent){
	var cData;
	for(var i = 0; i<chatBox1.chatBoxArray.length; i++){
		if(c_id == chatBox1.chatBoxArray[i].cData.c_id){
			cData = chatBox1.chatBoxArray[i].cData;
			break;
		}
	}
//	console.log(cData);
//	console.log(c_id,msgContent);
	//封装消息发送出去
	var sendData = {
		msg_id: new Date().getTime(),
		imid: cData.imid,
		send_id:cData.imid,
		rec_id:cData.rec_id,
		msgbody:msgContent,
		send_time: new Date().getTime(),
		msg_type:1,
		send_flag:4,
		record_time:new Date().getTime(),
		//会话id
		c_id:c_id
	}
	webConnect.send(sendData);
	//消息列表更新
	for(var i = 0 ;i < msgItemList.length; i++){
		if(c_id == msgItemList[i].converData.c_id){
			msgList.refreshMsgOrUrRead(msgItemList[i].item,msgContent,0);
			break;
		}
	}
	msgList.refreshMsgOrUrRead();
}

function receive(data){
	//找到那个item
	var item;
	for(var i = 0; i<chatBox1.chatBoxArray.length; i++){
		if(data.c_id == chatBox1.chatBoxArray[i].cData.c_id){
			item = chatBox1.chatBoxArray[i].chatItem;
			break;
		}
	}
	chatBox1.getMsg(item.children(".im_chatBody"),data.msgbody);
	//消息列表更新
	for(var i = 0 ;i < msgItemList.length; i++){
		if(data.c_id == msgItemList[i].converData.c_id){
			msgList.refreshMsgOrUrRead(msgItemList[i].item,data.msgbody,0);
			break;
		}
	}
}

function disconnect(){
	webConnect.disconnect();
}

function connect(){
	webConnect.connect();
}

	
//聊天框		
var chatBox1 = new chatBox();
	chatBox1.init(send);
	
var addFBox = new addFriendBox();
var CGBox = new createGroupBox();
var roleInfoBox = new RoleInfoBox();
	roleInfoBox.init(func);
function createFloatChatBox(rec_imid){
	var selfImid =  "6554";
	var param = {imid:selfImid,rec_id:rec_imid};
//	console.log(msgItemList);
//	console.log(rec_imid);
	//排除已经存在的会话
	for(var i = 0; i<msgItemList.length; i++){
		if(rec_imid == msgItemList[i].converData.rec_id){
			//创建box
		    createBox(msgItemList[i].converData);
			return;
		}
	}
	
	//请求创建新的 会话
	$.post(httpUrl+'/createConv',param,function(res){
		res = {
			imgSrc:null,
			name:res.userName,
			msg:res.lastWord,
			unReadMsgCount:res.unread,
			c_id:res.c_id,
			imid:res.imid,
			rec_id:res.rec_id
		}
		var newItem = msgList.addItem(res);
		//创建一个聊天浮动块
		createBox(res);
	});
	
	function createBox(data){
		//创建一个聊天浮动块
		var isCreated = false;
		for(var i = 0; i<chatBox1.chatBoxArray.length; i++){
			
			if(data.c_id == chatBox1.chatBoxArray[i].cData.c_id){
				isCreated = true;
				break;
			}
			isCreated = false;
		}
		if(!isCreated){
			chatBox1.createChatBox(data);
		}
	}
}

function createFloatCEmail(obj){
	console.log("创建邮件");
}

function CreateFloatState(obj){
	console.log("创建好友动态");
	//显示在iframe上面
	changePage("好友动态","hisDynamic.html");
}

function CreateFloatDeteleF(obj){
	console.log("创建删除好友界面");
}

function createFloatPersonBox(){
	roleInfoBox.createRoleInfoBox();
}

function removeConv(item){
	for(var i=0; i<msgItemList.length; i++){
		if(item == msgItemList[i].item){
			//请求创建新的 会话
			var param = {c_id:msgItemList[i].converData.c_id}
			$.post(httpUrl+'/deleteConv',param,function(res){
				console.log(res);
			});
		}
	}
}

//选择通讯录还是消息列表  还是添加好友
function showNaviBar(index){
	var divArray = $(".im_navibar");
	$(divArray[0]).children("img").attr("src","images/communicate/msg.png")
	$(divArray[0]).children("div").css({"color":"gray"});
	$(divArray[1]).children("img").attr("src","images/communicate/address.png")
	$(divArray[1]).children("div").css({"color":"gray"});
	if(index == 1){
		$("#list").css({"display":"none"});
		$("#address").css({"display":"none"});
		$(divArray[0]).children("img").attr("src","images/communicate/msg1.png")
		$(divArray[0]).children("div").css({"color":"rgba(74,137,220,1)"});
		$("#list").css({"display":""});
	}
	if(index == 2){
		$("#list").css({"display":"none"});
		$("#address").css({"display":"none"});
		$(divArray[1]).children("img").attr("src","images/communicate/address1.png")
		$(divArray[1]).children("div").css({"color":"rgba(74,137,220,1)"});
		$("#address").css({"display":""});
	}
}

//添加好友的菜单
$($(".im_navibar")[2]).contextPopup({
	      items: [
	        {label:'添加好友/群',      
	        	action:function() {
	        		addFBox.createAddFriendBox();
	        	}
	        },
	        {label:'创建群组',   
	        	action:function() { 
	        			CGBox.createCGroupBox();
	        	}
	        },
	      ],
	      showEvent:"contextmenu click",
   });

function imChangeSkin(skinStyle){
	if(skinStyle){
		//右键界面
		$("#im_contextMeCSS").attr("href","./css/im/jquery.contextmenu_blue.css");
		//聊天界面
		$("#im_chatBoxCss").attr("href","./css/im/chatBox_blue.css");
		//添加好友
		$("#im_addFBCss").attr("href","./css/im/addFriendBox_blue.css");
		//创建群组
		$("#im_CGCss").attr("href","./css/im/createGroup_blue.css");
		//个人资料
		$("#im_RoleInfoCss").attr("href","./css/im/roleInfoBox_blue.css");
	}else{
		//右键界面
		$("#im_contextMeCSS").attr("href","./css/im/jquery.contextmenu.css");
		//聊天界面
		$("#im_chatBoxCss").attr("href","./css/im/chatBox.css");
		//添加好友
		$("#im_addFBCss").attr("href","./css/im/addFriendBox.css");
		//创建群组
		$("#im_CGCss").attr("href","./css/im/createGroup.css");
		//个人资料
		$("#im_RoleInfoCss").attr("href","./css/im/roleInfoBox.css");
	}
}

//调用一次
imChangeSkin(!isWhiteSkin);

