function msgList(){
	'use strict';
	//创建聊天窗口
	var createChatBox;
	//人物详情
	var createPerson;
	//发送邮件
	var sendEmail;
	//好友动态
	var friendState;
	//删除好友
	var deteleFriend;
	//删除会话
	var removeConv;
	
	//消息item列表数组
	var itemArray = [];
	
	var init = function(func){
		createChatBox = func.createChatBox;
		createPerson = func.createPerson;
		friendState = func.friendState
		sendEmail = func.sendEmail;
		deteleFriend = func.deteleFriend;
		removeConv = func.removeConv;
	}
	var CreatItemDiv = function(dd) {
		var imgSrc = null,
			name = dd.name,
			msg = dd.msg,
			unReadMsgCount = dd.unReadMsgCount;
	    var im_item = $("<div>").addClass("im_item");
	    imgSrc = "images/communicate/men.png";
	    var headImage = $("<img>").addClass("im_headImage").attr("src",imgSrc).attr("isclick","1");
	    var textDiv = $("<div>").addClass("im_text");
	    var nameP = $("<p>").addClass("im_name").text(name);
	
	    //		//处理下内容过长
	    //		if(msg.length > 10){
	    //			msg = msg.substring(0,10);
	    //		}
	    //		
	    var msgP = $("<p>").addClass("im_msg").text(msg);
	    
	    var unReadMsgDiv = $("<div>").addClass("im_unReadMsg").text(unReadMsgCount);
		
		im_item.click(function(e){
            if($(e.target).attr("isclick") == "1"){
                return;
            }
    		createChatBox(dd.rec_id);
    	});
    	
    	im_item.contextPopup({
	      items: [
	        {label:'查看资料',      
	        	action:function() { createPerson(); } },
	        {label:'发送邮件',   
	        	action:function() { sendEmail(); } },
	        {label:'查看好友动态',   
	        	action:function() { friendState(); }},
	        {label:'发起聊天',   
	        	action:function() { createChatBox(dd.rec_id); } },
        	{label:'移除该对话',   
        		action:function() { removeItem(im_item);  im_item.remove(); removeConv(im_item);} },
    		{label:'删除好友',   
        		action:function() { deteleFriend(); } }
	      ]
	    });
	    
	    headImage.click(function(e){
	    	//点击头像查看好友动态
            friendState();
    	});
    	
    	function removeItem(im_item){
    		var newArray = [];
    		for(var i =0 ; i <itemArray.length; i++){
    			if(im_item != itemArray[i].item){
    				newArray.push(itemArray[i]);
    			}
    		}
    		itemArray = newArray;
    	}
    	
	    headImage.appendTo(im_item);
	    nameP.appendTo(textDiv);
	    msgP.appendTo(textDiv);
	    textDiv.appendTo(im_item);
	    unReadMsgDiv.css({"display":"none"});
	    if(parseInt(unReadMsgCount)>0){
	    	unReadMsgDiv.css({"display":""});
	    }
	    unReadMsgDiv.appendTo(im_item);
	    return im_item;
	}
	
	var createMsgList = function(data){
		var dd = [];
		for(var i = 0; i < data.length; i++){
			dd.push({ imgSrc:null,
				name:data[i].userName,
				msg:data[i].lastWord,
				unReadMsgCount:data[i].unread,
				c_id:data[i].c_id,
				imid:data[i].imid,
				rec_id:data[i].rec_id
			});
		}
		
		var x = $('#list');
		//清空
		x.empty();
		for (var i = 0; i < dd.length; i++) {
		    var item = CreatItemDiv(dd[i]);
		    item.attr("c_id",dd[i].c_id).attr("imid",dd[i].imid);
		    item.appendTo(x);
		    //add array
		    //将item 和 数据以json的形式 加入到数组中 
		    itemArray.push({item:item,converData:dd[i]});
		}
		
	}
	
	/**
	 *  @param jq对象
	 *  @param 最新消息
	 *  @param 未读的消息
	 */
	var refreshMsgOrUrRead = function(item,msg,ureadCount){
		if(!!item){
			item.children(".im_text").children(".im_msg").text(msg);
			if(parseInt(ureadCount)>0){
	    		unReadMsgDiv.css({"display":"none"});
	   		}
			item.children(".im_unReadMsg").text(ureadCount);
			//将原来的item移除来 但不移除jq对象和事件
			item.detach();
			item.prependTo($("#list"));
		}
	}
	
	///添加一个item到头部 参数是一个会话
	var addItem = function(converData){
		var imgSrc = null;
		var i= 0;
	 	var item = CreatItemDiv(converData);
	 	item.attr("c_id",converData.c_id);
		item.attr("imid",converData.imid);
	 	item.prependTo($("#list"));
	    //add array
	    //添加到数组头部
	    itemArray.unshift({item:item,converData:converData});
	}
	
	this.createMsgList = createMsgList;
	this.refreshMsgOrUrRead = refreshMsgOrUrRead;
	this.addItem = addItem;
	this.init = init;
	this.itemArray = itemArray;
}
	
//通讯录操作
function addressList(){
	'use strict';
	//创建聊天窗口
	var createChatBox;
	var createPerson;
	var sendEmail;
	var friendState;
	var deteleFriend;
	var init = function(func){
		createChatBox = func.createChatBox;
		createPerson = func.createPerson;
		friendState = func.friendState
		sendEmail = func.sendEmail;
		deteleFriend = func.deteleFriend;
		$(".im_backDiv").mouseover(function(e){
			$(".im_backDiv").children("div").css({"color":"rgba(74,137,220,1)"});
			$(".im_backDiv").children("img").attr("src","images/communicate/im_back1.png");
		});
		
		$(".im_backDiv").mouseout(function(e){
			$(".im_backDiv").children("div").css({"color":"gray"});
			$(".im_backDiv").children("img").attr("src","images/communicate/im_back.png");
		});
		//给头一个index
		currentHOrg.push(-1);
		//返回按钮(写的有点乱)
		$(".im_backDiv").click(function(e){
			//处理层级的 主要是一个类似于栈的结构 ，主要就是当只有两个元素时候，不出两个元素了
//			console.log(currentHOrg);
			if(currentHOrg.length > 2){
				$(".im_backDiv").css({"display":""});
				var orgidd = currentHOrg.pop();
				orgidd = currentHOrg[currentHOrg.length-1];
//				console.log(orgidd);
				if(!!orgidd){
					getResquest(orgidd);
				}
			}else{
				currentHOrg = [];
				currentHOrg.push(-1);
				$(".im_backDiv").css({"display":"none"});
				//第一次请求
				GetAdressList(httpUrl+"/org/allOrg/childOrg",null,createAddressList);
				function GetAdressList(url,params,callback){
					$.get(url,function(res){
						var ss = [];
						ss.push(res.result);
						callback(ss);
					});
				}
			}
		});
	}
	//走过层的数组
	var currentHOrg = [];
	
	var createAddressList = function(result){
// 		console.log("createAddressList:",result);
		var personArray  = [];
		var departMent = [];
		var data;
		for(var i = 0 ;i < result.length; i++){
			data = result[i];
           // console.log("createAddressList data:",data);
            //判断是人还是部门
			if(!!data.imid){
				personArray.push({imid:data.imid,
									imgSrc:"images/communicate/men.png",
									name:data.userName,
									department:data.policeRank,
									orgId:data.orgId
								});
				
			}else{
				departMent.push({ _id:data._id,
									imgSrc:"images/communicate/department.png",
									name:data.orgName,
									department:data.orgPath,
									parentId:data.parentId,
									orgId:data.orgId
							});
			}
		}
		var addressList = $('#address');
		//清空
		addressList.empty();
		for (var i = 0; i < personArray.length; i++) {
		    var item = CreatItemDiv(personArray[i].imid,personArray[i].orgId,personArray[i].imgSrc,personArray[i].name,personArray[i].department);
		    item.appendTo(addressList);
		}
		
		for (var i = 0; i < departMent.length; i++) {
		    var item = CreatItemDiv(null,departMent[i].orgId,departMent[i].imgSrc,departMent[i].name,departMent[i].department);
		    item.appendTo(addressList);
		}
		addressList.animate({scrollTop: 'px'}, 500);
	}

	var CreatItemDiv = function(imid,orgId,imgSrc, name, department) {
	    var item = $("<div>").addClass("im_item").attr("orgId",orgId).attr("imid",imid);
	    var headImage = $("<img>").addClass("im_headImage").attr("src",imgSrc );
	    headImage.appendTo(item);
	    var textDiv = $("<div>").addClass("im_text");
	    var nameP = $("<p>").addClass("im_name").text(name);
	    nameP.appendTo(textDiv);
	    if(!!imid){
	    	var msgP = $("<p>").addClass("im_msg").text(department);
	    	msgP.appendTo(textDiv);
	    }
	    textDiv.appendTo(item);
	    
	    item.click(function(e){
			var orgidd = parseInt(item.attr("orgId"));
			var imid = parseInt(item.attr("imid"));
			if(!!imid){
				createChatBox(imid);
			}else{
				getResquest(orgidd);
				currentHOrg.push(orgidd);
//				console.log(currentHOrg);
				$(".im_backDiv").css({"display":""});
			}
    	});
    	//区别部门还是人
    	if(!!imid){
	    	//右键菜单
	    	item.contextPopup({
		      items: [
		        {label:'查看资料',      
		        	action:function() { createPerson(); } },
		        {label:'发送邮件',   
		        	action:function() { sendEmail(); } },
		        {label:'查看好友动态',   
		        	action:function() { friendState(); }},
		        {label:'发起聊天',   
		        	action:function() { createChatBox(imid); } },
	    		{label:'删除好友',   
	        		action:function() { removeItem(item);  item.remove();  deteleFriend(); } }
		      ]
		    });
	    }
	    return item;
	}
	
	var re = [];
	function getResquest(orgId){
		var departMentUrl  = httpUrl+"/org/orgName/o";
		var personUrl = httpUrl+"/org/orgName/p";
		//用来保存用户和部门的合集
		re = [];
		var par = {orgId :orgId+""}
		$.post(personUrl,par,function(res){
			for(var i = 0; i < res.result.length; i++){
				re.push(res.result[i]);
			}
			$.post(departMentUrl,par,function(res){
				for(var i = 0; i < res.result.length; i++){
					re.push(res.result[i]);
				}
                console.log("00000000000000000000:",re)
				createAddressList(re);
			});
		});
	}

    this.createAddressList = createAddressList;
	this.init = init;
}
