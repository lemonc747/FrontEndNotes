function chatBox(){
	'use strict';
	//上条消息的时间
	var lastMsgTime;
	//头像的src
	var formUserIcon;
	var selfuserIcon;
	//当前发送到服务器的消息函数回调（处理好的消息格式）
	var sendCFunc;
	
	var chatBoxArray = [];
	var z_index = 99;
	
	var init = function(sendFunc){
		sendCFunc = sendFunc;
	}
	
	var createChatBox= function(converData){
		var chatBox = $("<div>").addClass("im_chatBox").attr("c_id",converData.c_id);
		//让新建的都想显示在最上层
		z_index++;
		chatBox.css({"z-index":z_index});
		var id = chatBox.attr("id");
		var chatHead = $("<div>").addClass("im_chatHead");
		var chatName = $("<span>").addClass("im_spanText").text(converData.name);
//		var sub = $("<span>").addClass("im_spanText").addClass("im_optionflagSub").text("-");
		var add = $("<span>").addClass("im_spanText").addClass("im_optionflagAdd").text("x");
		
//		sub.click(function(e){
//			var deleteIndex = -1;
//			for(var i = 0; i<chatBoxArray.length; i++){
//				if(chatBox == chatBoxArray[i].chatItem){
//					deleteIndex = i;
//					break;
//				}
//			}
//			if(deleteIndex !=-1){
//				chatBoxArray.splice(deleteIndex,1)
//			}
//			chatBox.remove();
//		});
		
		add.click(function(){
			var deleteIndex = -1;
			for(var i = 0; i<chatBoxArray.length; i++){
				if(chatBox == chatBoxArray[i].chatItem){
					deleteIndex = i;
					break;
				}
			}
			if(deleteIndex !=-1){
				chatBoxArray.splice(deleteIndex,1)
			}
			chatBox.remove();
		});
		
		chatName.appendTo(chatHead);
//		sub.appendTo(chatHead);
		add.appendTo(chatHead);
		chatHead.appendTo(chatBox);
		
		var chatBody = $("<div>").addClass("im_chatBody");
		
		chatBody.appendTo(chatBox);
		
		var chatBottom = $("<div>").addClass("im_chatBottom");
		var iconGroup = $("<div>").addClass("im_iconGroup");
		
		var imgPath = ['images/communicate/biaoqing.png','images/communicate/photo.png','images/communicate/time.png'];
		for(var i = 0 ; i< imgPath.length;i++){
			var icon = $("<img>").addClass("im_icon").attr("src",imgPath[i]);
			icon.appendTo(iconGroup);
		}
		iconGroup.appendTo(chatBottom);
		var chatInputDiv = $("<div>").addClass("im_chatInputDiv");
		var input = $("<input>").addClass("im_chatInput");
		input.appendTo(chatInputDiv);
		chatInputDiv.appendTo(chatBottom);
		
		var buttonDiv = $("<div>").addClass("im_buttonDiv");
		var butto = $("<button>").addClass("im_buttonSend").text("发 送");
		butto.appendTo(buttonDiv);
		buttonDiv.appendTo(chatBottom);
		chatBottom.appendTo(chatBox);
		chatBox.appendTo("body");
		$(function(){
			chatBox.Tdrag({
				scope:"body",
    			handle:".im_chatHead"
			});
		});
		var that = this;
		butto.click(function(e){
			var msgContent = $(e.target).parent().parent().find(".im_chatInput").val();
			if(msgContent!=""){
				var chatBody = $(e.target).parent().parent().parent();
				var c_id = chatBody.attr("c_id");
				chatBody = chatBody.find(".im_chatBody");
				that.sendMsg(chatBody,msgContent);
				$(e.target).parent().parent().find(".im_chatInput").val("");
				that.sendToServer(c_id,msgContent);
			}
		});
		//请求聊天记录
		var parm_chatRecord = {imId:converData.imid,recId:converData.rec_id};
		$.post(httpUrl+'/getCRecordList',parm_chatRecord,function(res){
//			console.log("返回聊天记录");
//			console.log(res);
			for(var i = 0 ; i < res.length ; i++){
				if(res[i].send_id == converData.imid){
					sendMsg(chatBody,res[i].msg_body);
				}else{
					getMsg(chatBody,res[i].msg_body);
				}
			}
		});
		//添加到chatboxlist
		chatBoxArray.push({chatItem:chatBox,cData:converData});
	}
	
	//获取消息
	var getMsg = function(chatBodyDi,msgText){
		var chatItem = $("<div>").addClass("im_chatItem");
		var img ,chatContent;
		img = $("<img>").addClass("im_chatItemHeadImage").attr("src","./images/communicate/men.png");
		chatContent = $("<div>").addClass("im_chatContent").text(msgText);;
		img.appendTo(chatItem);
		chatContent.appendTo(chatItem);
		chatItem.appendTo(chatBodyDi);
		
		//处理好样式的效果
//		console.log(chatItem.height());
//		console.log("chatItem的宽：",chatContent.width());
		if(chatContent.width()>180){
			chatContent.css({"width":"250",
							'word-break':'break-all'});
		}
		//移动到最下面
		$(chatBodyDi).scrollTop($(chatBodyDi)[0].scrollHeight);
	}
	
	//发送消息
	var sendMsg = function(chatBodyDi,msgText){
		var chatItem = $("<div>").addClass("im_chatItem");
		var img ,chatContent;
		img = $("<img>").addClass("im_chatItemHeadImage").addClass("im_chRight").attr("src","./images/communicate/men.png");
		chatContent = $("<div>").addClass("im_chatContent").addClass("im_cCRight").text(msgText);
		img.appendTo(chatItem);
		chatContent.appendTo(chatItem);
		chatItem.appendTo(chatBodyDi);
		//处理好样式的效果
//		console.log(chatItem.height());
//		console.log("chatItem的宽：",chatContent.width());
		if(chatContent.width()>180){
			chatContent.css({"width":"250",
							'word-break':'break-all'});
		}	
		//移动到最下面
		$(chatBodyDi).scrollTop($(chatBodyDi)[0].scrollHeight );
	}
	
	var displayTimeLine = function(chatBodyDi,msgText){
		var chatTime = $("<div>").addClass("im_chatTimeLine").text(msgText);
		chatTime.appendTo(chatBodyDi);
	}
	
	var sendToServer = function(c_id,CMsgJson){
		sendCFunc(c_id,CMsgJson);
	}
	
	this.init = init;
	this.createChatBox = createChatBox;
	this.getMsg = getMsg;
	this.sendMsg = sendMsg;
	this.displayTimeLine = displayTimeLine;
	this.sendToServer = sendToServer;
	this.chatBoxArray = chatBoxArray;
}
