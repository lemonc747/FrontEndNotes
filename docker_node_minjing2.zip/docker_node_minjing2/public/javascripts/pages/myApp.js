
const access_token = parent.my_token || sessionStorage.getItem('access_token');


$(function(){
  $("#leval1 li:first-child").addClass("changeColor");
  $('.dropdown-menu').on('click', function(e) {
      var $target = $(e.target);
      $target.is('li') && $('#text').text($target.text())
  });
   //自身换肤操作
  changeBgcolor(!parent.isWhiteSkin);
  getallApp();//全部应用
  getClassB();//二级分类(下拉框)
});

//    获取全部应用
function getallApp(){
  parent.XHSDK.ajax({
      url:uiURL+"/front/app/getAllAppNew",
      type:"post",
      contentType: "application/json;charset=utf-8",
      data: '{"accessToken":"'+my_token+'","appDic":1,"appClassify":"'+my_class+'"}',
      success:function(result){
          var allApp="";
          if(result.code==200 && result.data.result && result.data.result.length > 0){
              $(".all_f").css("display","block");
              for(var i=0;i<result.data.result.length;i++){
                  var description=result.data.result[i].describe;
                  if(description!==null){
                      description=description.replace(/[\r\n]/g, "");
                  }
                  allApp+='<li id="3_'+result.data.result[i].appId+'" onclick="appDetail(this)"><div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" style="position: relative;height: 100%;"><div class="myCheckbox" ><input type="checkbox" ></div><span class="myApp_appColor" style="float: left;position: relative; top: 24%;width:45px;height:45px"><img src="'+result.data.result[i].appIcon+'" alt=""></span><div class="allApp_text" ><h5 >'+result.data.result[i].appName+'</h5><span class="decripte">'+(description==null?'':"应用说明："+description)+'</span></div></div>' +
                          '<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 paddT" style="text-align: center"><span  class="collect coll_num"  onclick="collect_App(this,\''+result.data.result[i].appName+'\',\''+result.data.result[i].buildDept+'\',\''+description+'\',\''+result.data.result[i].installDate+'\',\''+result.data.result[i].appId+'\')"><b >收藏</b></span></div><div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 paddT .myApp_btn">'+(result.data.result[i].isInstall==0?'<input type="button" class="btn btn-default" onclick="installApp(this,0)" value="安装"/>':'<input type="button" class="btn btn-default" onclick="allApp_removeallApp(this,0)" value="卸载"/>')+'  <input type="button" class="btn btn-default" onclick="commentApp(this,\''+result.data.result[i].appName+'\',\''+result.data.result[i].buildDept+'\',\''+description+'\',\''+result.data.result[i].installDate+'\',\''+result.data.result[i].appId+'\')" value="评论"/></div></li>'
              }
              $("#allApp").html(allApp);
    $("#allApp").prepend('<div class="allApp_count" style="font-size: 12px;margin-bottom: 10px;">全部应用共 <span>'+result.data.count+'</span> 款软件</div>')

               collectData();//加载已收藏数据
          }
          // else if(result.code == 603){
          //     layer.confirm('登录超时'+result.cmd, {
          //         btn: ['确定'] //按钮
          //     }, function(){
          //         window.location.href="http://172.19.255.102:88/login.html?access_token="+ my_token;
          //     });
          // }
          else{
               allApp+='<li class="noapp" >无此类应用</li>';
              $(".all_f").css("display","none");
              $("#allApp").html(allApp);
              //console.log("Error:res.code=",result.code);
          }
      },error:function(mesg){
          console.log("error"+mesg) ;
      }
  });
}