const path = require('path');

module.exports = {
    devtool: "cheap-source-map",
    entry:  {
        'bundle/index': './public/js/index.js',
        'bundle/dependencies': './public/js/dependencies.js',
        'previewIframe/bundle/dependencies': './public/js/dependencies.js',
        'previewIframe/bundle/index': './public/js/preview/entryPhone.js',
        'bundle/indexPreview': './public/js/preview/entryPC.js'
    },
    output: {
        filename: "[name].bundle.js",
        path: path.resolve(__dirname, 'public')
    },
    module: {
        rules: [
            {
                test: require.resolve('jquery'),
                use: [{
                    loader: `expose-loader`,
                    options: 'jQuery'
                },{
                    loader: `expose-loader`,
                    options: '$'
                }]
            },
            {
                test: require.resolve('@shopify/draggable'),
                use: [{
                    loader: `expose-loader`,
                    options: `Draggable`
                }]
            },
            {
                test: /\.js$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                  loader: 'babel-loader',
                  options: {
                    presets: ['@babel/preset-env']
                  }
                }
              }
        ]
    },
    // watch: true,
    // watchOptions: {
    //     aggregateTimeout: 1000,
    //     poll: 1000,
    //     ignored: /node_modules/
    // }
}