const path = require('path');

module.exports = {
    entry:  {
        index: './public/js/index.js',
        dependencies: './public/js/dependencies.js'
    },
    output: {
        filename: "[name].bundle.js",
        path: path.resolve(__dirname, 'public/bundle')
    },
    module: {
        rules: [
            {
                test: require.resolve('jquery'),
                use: [{
                    loader: `expose-loader`,
                    options: 'jQuery'
                },{
                    loader: `expose-loader`,
                    options: '$'
                }]
            },
            {
                test: require.resolve('@shopify/draggable'),
                use: [{
                    loader: `expose-loader`,
                    options: `Draggable`
                }]
            },
            {
                test: /\.js$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                  loader: 'babel-loader',
                  options: {
                    presets: ['@babel/preset-env']
                  }
                }
              }
        ]
    }
}