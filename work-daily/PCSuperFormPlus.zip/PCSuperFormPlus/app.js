﻿var express = require('express');
var app = express();
var bodyParser = require("body-parser");
//引入压缩模块
var packZip = require("./server/pack-zip.js");

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
////日志模块
//var log = require("./server/utils/logUtils.js").init();
var server = require('http').createServer(app);
//var io = require('socket.io')(server);
app.use('/', express.static(__dirname + '/public'));
server.listen(13344, function() {
    var host = server.address().address
    var port = server.address().port
    console.log("listen "+ host+":"+port);
});

//获取压缩包
app.post("/pack",function(req,res){
   var data = req.body;
   //打包方法初始化
   packZip.init(__dirname+"/public/previewIframe/");
   packZip.packZipFunc(data,callback);
   function callback(zipName){
     var zipInfo = {};
     zipInfo.zipName = zipName;
     res.json({result:zipInfo});
   }
});
