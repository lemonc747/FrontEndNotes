//API接口js
//1、req.body
//2、req.query
//3、req.params

function init(app) {
	//获取压缩包
	app.post("/pack", function (req, res) {
		var id = req.body.formId;
		var dataHandle = function (data) {
			res.json({result: data});
		}
		dbDao.getPerson(dataHandle, id);
	});
};

module.exports = {
    init: init
};
