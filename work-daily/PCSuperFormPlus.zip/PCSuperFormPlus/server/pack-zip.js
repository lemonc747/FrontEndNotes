var archiver = require('archiver');
var fs = require('fs');
var path = require('path');

var dirname;
function init(src){
  dirname = src;
}

function startZipFile(func){
    var outputFileName  = "previewIframe";
    var output = fs.createWriteStream('./public/'+outputFileName+'.zip');
    var archive = archiver('zip');

    output.on('close', function() {
      console.log(archive.pointer() + ' total bytes');
      console.log('archiver has been finalized and the output file descriptor has closed.');
      if(!!func){
          func(outputFileName);
      }
    });

    archive.on('error', function(err) {
      throw err;
    });
    archive.pipe(output);
    archive
      .directory('./public/previewIframe', 'previewIframe')
      .finalize();
}

function packZipFunc(data,func){
  //构建一个json对象
  var jsonConfig = {};
  jsonConfig.formId = data.formId;

  var sourceFile = path.join(dirname, "previewphone.html");
  var destPath = path.join(dirname, "index.html");

  fs.readFile(sourceFile,'utf-8',function(err,data){
      data +=  '<script> var jsonConfig = '+ JSON.stringify(jsonConfig) +'</script>';
      fs.writeFile(destPath,data,'utf-8',function(err){
          if(err)throw err;
          console.log('写入成功！');
          //打包输出
          startZipFile(func);
      });
  });
}

module.exports = {
    init:init,
    packZipFunc:packZipFunc
};
