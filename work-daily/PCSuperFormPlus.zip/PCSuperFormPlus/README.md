

## structure

### build tools
- 表单组件-原型：weui
- 基础组件-原型：sui
- 前端工作流：gulp
- 模块化：webpack

### 项目结构
按功能分类
- 组件
    - 组件UI
    - 组件类
    - 组件JS拓展
- 组件属性
- 模板管理
- 页面管理
- 预览
- 拖拽和排序
- 

data structure
- 公共数据采用localStorage，统一前缀`_xh_global`
- component instance
- 


### dom structure
支撑DOM结构的选择器

- #head
- .container-layout
    - #xh-sidebar
        - #xh-sidebar-header
            - `Array`: div[data-xh-content-id=*],*代表`xh-sidebar-content`中对应ID的内容域
        - #xh-sidebar-content
            - #sidebar-pages
            - #sidebar-components
                - `Array`: div.xh-sidebar-content-header,显示子内容域的名称
                - `Array`: div.xh-sidebar-content-box,子内容域的公共Class,也有区分的class如下：
                    - .sidebar-base-components：基础组件
                    - .sidebar-service-components：服务组件
                    - .sidebar-form-components：表单组件
            - #sidebar-templates

### 拖拽和排序
previewPhone暂时只支持两层
- pagemain
    - divBox
        - divBox

1. divBox[type!=base]可以拖拽到divBox[type=base]
2. 外层divBox可以排序
3. 内层divBox只能删除，不能排序
4. 所有divBox都能正常设置属性

### src structure

- bundle
- css
- fonts
- js
    - module：按照功能逐级分类
    - lib
    - utils
- index.js

### js structure guide

- preview|预览
    - preview|电脑预览
    - 。。。
- component|组件
    - 


### task
|优先级|紧急|不紧急|
|:---:|:---:|:---:|
|重要|1|3|
|不重要|2|4|

1. 数据的结构和获取 1
2. 容器组件的拖拽 1
3. 统一组件 3
3. webpack打包配置 4
4. css打包 3
5. css源码 3