

## structure

## build tools
- 表单组件：weui
- 基础组件：sui
- 前端工作流：gulp
- 模块化：webpack



### dom structure
支撑DOM结构的选择器

- #head
- .container-layout
    - #xh-sidebar
        - #xh-sidebar-header
            - `Array`: div[data-xh-content-id=*],*代表`xh-sidebar-content`中对应ID的内容域
        - #xh-sidebar-content
            - #sidebar-pages
            - #sidebar-components
                 - `Array`: div.xh-sidebar-content-header,显示子内容域的名称
                - `Array`: div.xh-sidebar-content-box,子内容域的公共Class,也有区分的class如下：
                    - .sidebar-base-components：基础组件
                    - .sidebar-service-components：服务组件
                    - .sidebar-form-components：表单组件
            - #sidebar-templates

### src structure

- css
- fonts
- js
    - lib
    - utils
- index.js

### js structure guide

- preview|预览
    - preview|电脑预览
    - 。。。
- component|组件
    - 