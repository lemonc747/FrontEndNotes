
function getFormMSg(id){
  console.log("getFormMSg");
  var ajaxParam = {};
  ajaxParam.ids = [];
  ajaxParam.ids.push(id);
  var data;
  $.ajax({
        url:formMsgUrl+"/formMsg/selectByFormIds",
        type: "POST",
        async:false,
        contentType: "application/json;charset=utf-8",
        data: JSON.stringify(ajaxParam),
        dataType: "json",
        success: function(res) {
            if(res.code== 200){
                data = JSON.parse(res.data[0].formMsg.formJson);
                var widgets = res.data[0].widgets;
                for(var i = 0; i < data.length; i++){
                  data[i].Key = widgets[i].itemKey;
                }
            }
        },
        error: function(msg) {
            console.log("Error:" + msg);
        }
    });
    return data;
}
