
/**单行输入 */
var SIMPLEINPUT = 0;
/**多行输入 */
var TEXTAREA = 1;
/**单选框 */
var RADIO = 2;
/**多选框 */
var CHECKBOX = 3;
/**下拉框 */
var SELECT = 4;
/**数字 */
var NUMBER = 5;
/**时间日期 */
var DATE = 6;
/**勾选框（开关） */
var SWITCH = 7;
/**级联(地区级联) */
var CASCADER = 8;
/**文本栏 */
var TEXT = 9;
/**评分 */
var SCORE = 10;
/**分割线 */
var SPLITLINE = 11;

var formMsgUrl = "http://20.97.6.62:8080/xinghuo-apaas-superform/";

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}

//重新定义个全局变量
var formTepComArr = GetQueryString("formsg");
formTepComArr= decodeURI(formTepComArr);
console.log(formTepComArr);
var str=window.location.search;
var formset =  str.substring(str.indexOf("&"));
formset=formset.substring(formset.indexOf("=")+1);
formset= decodeURI(decodeURI(formset));
console.log(formset);
if(!!formTepComArr){
  try {
      formTepComArr = JSON.parse(formTepComArr);
      formset =JSON.parse(formset);
  } catch (e) {
      //获取ajax请求 拿到fromJSON
      formTepComArr = getFormMSg(formTepComArr);
  } finally {
      console.log("dfsdsdfs");
      //加到画布中去
      previewPageLoad($("#preview"));
  }
}

//更新Previewlayer的数据
parent.refreshShowJSON(formTepComArr);
