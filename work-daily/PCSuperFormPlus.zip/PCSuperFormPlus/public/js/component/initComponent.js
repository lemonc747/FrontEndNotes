/**
 * 部分组件的初始化
 */
var common = require('../utils/common');

/**
 * 导航栏
 */
$(document).on("click", "weui-navbar__item", function(){
    common.toggleClass(this, "weui-bar__item_on");
    var position = $(this).attr("data-navbar-num");
    var container = $(this).parent().parent();
    container.find(".weui-tab__panel[")
    
})