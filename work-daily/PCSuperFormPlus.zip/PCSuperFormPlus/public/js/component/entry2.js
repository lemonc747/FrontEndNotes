var common = require('../utils/common'),
    dragUtils = require('../utils/dragUtils'),
    global = require('../utils/global');
var Draggable = require('@shopify/draggable'),
    template = require('./template'),
    editComponent = require('./editComponent'),
    canvasSetting = require('../attribute/canvasSetting'),
    compStyle = require('../attribute/component_style');

//test
var retrieve = require('./retrieve');

var newComp,
    newCompDom;

var $container = $("#xh-container"),
    $sidebar_header = $("#xh-sidebar-header"),
    $sidebar_content = $("#xh-sidebar-content"),
    $sidebar_components = $("#sidebar-components"),
    $sidebar_templates =$("#sidebar-templates"),
    baseCompsDom = [],
    // 游标悬浮位于的目标容器
    targetBelowCursor,
    // 上一次悬浮的target，用于对比targetBelowCursor
    lastCompBelowCursor;

// event:切换sidebar标签页
$sidebar_header.on("click", "div[data-xh-content-id]", function(){
    event.preventDefault();
    var content_id = this.getAttribute("data-xh-content-id");//$(this).attr("data-xh-content-id");
    common.toggleClass(this, "active");
    if(content_id == "sidebar-templates"){
        canvasSetting.getTemplate(1);
    }
    common.toggleClass("#"+content_id, "active");
});

// event: 切换components内容块
$sidebar_components.on("click", ".xh-sidebar-content-header", function(){
    common.toggleClass(this, "active", ".xh-sidebar-content-header");
})
// event: 切换templates内容块
$sidebar_templates.on("click", ".xh-sidebar-content-header", function(){
    common.toggleClass(this, "active", ".xh-sidebar-content-header");
})

// 初始化components九宫格
//组件库 的基础组件，服务组件，表单组件
$sidebar_components.find(".sidebar-form-components").append(initCompsDom("form"));
$sidebar_components.find(".sidebar-base-components").append(initCompsDom("base"));
$sidebar_components.find(".sidebar-service-components").append(initCompsDom("service"));


/**
 * 初始化components九宫格
 * @param {string} type 内置类型
 */
function initCompsDom(type){
    var compsHtml = [],
        temp    = template.grid,
        components   = template[type],
        id      = components.id,
        name    = components.nameZh,
        icon    = components.icon;
    for(var i=0, length=id.length; i<length; i++){
        compsHtml.push(temp.replace("{{id}}", id[i]).replace("{{name}}",name[i])
            .replace('{{icon}}', icon[i]).replace('{{type}}', type));
    }
    return compsHtml.join('');
}


//实现拖拽
var draggable = new Draggable.Draggable(document.querySelectorAll('#sidebar-components'), {
    draggable: '.xh-components-unit',
});

draggable.on('mirror:created', function(evt){
    var target  = evt.originalSource,
        //type    = target.getAttribute("data-xh-comps-type");
        type = "Input";
    newComp = retrieve(type);
    $(evt.mirror).empty().addClass("xh-components-unit-mirror").append(newComp.info.preview);
});

draggable.on('drag:stop', function(evt){
    console.log(evt);
    var eventData = event && event.detail.data || evt.data.sensorEvent.data;
    if(newCompDom){
        if(dragUtils.isOverContainer("#pagemain", eventData.clientX, eventData.clientY)){
            newCompDom.querySelector('.viewBox').style.visibility = 'visible';
        }else{
            newCompDom.remove();
        }
    }
    newCompDom = null;
    lastCompBelowCursor = null;
});

/**
 * 判断cursor
 * 1. isOverContainer:是否在手机屏幕pageMain内
 * 2. getTargetBelowCursor：是否在某个组件内
 * 3. divBox_next: 检查子容器内
 * 4. 目前仅支持1层嵌套
 */
draggable.on('drag:move', (function dragMove(){
    var //interval = 50,
        timeoutId = 0,
        timer = + new Date(),
        timerInterval = 500,
        isOnProgress = false,
        doTask = function(evt){
            var target  = evt.originalSource,
                compsId = target.getAttribute("data-xh-comps-id"),
                type    = target.getAttribute("data-xh-comps-type"),
                tc      = document.querySelector("#pagemain"),
                scrollTop = tc.scrollTop,
                eventData = event && event.detail.data || evt.data.sensorEvent.data;
            // 检查鼠标位置
            if(dragUtils.isOverContainer("#pagemain", eventData.clientX, eventData.clientY)){
                // 检查是否已经存在
                // 此处返回的时jq-obj，转换为dom
                debugger;
                if( !newCompDom ){
                    newCompDom = newComp.render();
                    //newCompDom = editComponent(compsId, type).get(0);
                    newCompDom.querySelector('.viewBox').style.visibility = 'hidden';
                    newCompDom.style.border = '1px dashed black';
                }
                // 跟随cursor移动组件
                // 目前仅支持1层嵌套，由于查找dom的局限性。todo:优化查找支持复杂嵌套
                targetBelowCursor = dragUtils.getTargetBelowCursor("#pagemain>.divBox", eventData.clientX, eventData.clientY+scrollTop);
                if( targetBelowCursor ){
                    if( type!=="base" ){
                        var targetChild = dragUtils.getTargetBelowCursor(".divBox_child", eventData.clientX, eventData.clientY+scrollTop, targetBelowCursor);
                        if(targetChild && targetChild !== lastCompBelowCursor){
                            lastCompBelowCursor = targetChild;
                            // targetChild.innerHTML = '';
                            targetChild.append(newCompDom);
                            return;
                        }
                    }
                    if( targetBelowCursor !== lastCompBelowCursor){
                        lastCompBelowCursor = targetBelowCursor;
                        targetBelowCursor.after(newCompDom);
                    }
                }
            }
        };
    return function(evt){
        //为了保持灵敏，分流防抖都不合适，采用标识开关，并采用防抖的思路保证最后一次运行；
        if(!isOnProgress){
            isOnProgress = true;
            doTask(evt);
            isOnProgress = false;
        }
    }
}()));

