### Super Component 
组件基类

properties
- default data
- 

private methods
- init
- test

public methods
- getData: 组件的属性对象
- 

### components


1.容器组件支持嵌套基础组件
2.
