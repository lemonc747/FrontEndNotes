### 1
面向对象，以类的方式组织组件。基类有公共属性和方法，组件类继承并拓展。

### Super Component 
组件基类

properties
- default data
- 

private methods
- init
- test

public methods
- getData: 组件的属性对象
- 

### components



