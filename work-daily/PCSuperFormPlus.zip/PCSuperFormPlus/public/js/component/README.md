### 1
面向对象，以类的方式组织组件。基类有公共属性和方法，组件类继承并拓展。

### Super Component 
组件基类

properties
- default data
- 

private methods
- init
- test

public methods
- getData: 组件的属性对象
- 

### data
template：
{
    "key": "b4edd19f-be2f-4986-bd2a-d3dbcc267827",
    "val": {
        "typeNum": "1",
        "styleObj": {},
        "viewStyleObj": {},
        "type": "TEXTAREA",
        "label": "文本域",
        "decs": "请设置对表单的描述",
        "placeholder": "请输入提示语",
        "disable": false,
        "readonly": false,
        "required": false,
        "minnumber": 0,
        "maxnumber": 200
    }
},
{
    "key": "35a42bae-6f51-4dc7-a871-27782bd61734",
    "val": {
        "typeNum": "2",
        "styleObj": {},
        "viewStyleObj": {},
        "type": "RADIO",
        "label": "单选框",
        "decs": "请设置对表单的描述",
        "disable": false,
        "readonly": true,
        "required": true,
        "options": [
            {
                "id": 1527673635674,
                "value": "选项",
                "selected": false
            }
        ]
    }
}

