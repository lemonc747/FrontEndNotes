
var common = require('../utils/common'),
    dragUtils = require('../utils/dragUtils'),
    global = require('../utils/global');
var Draggable = require('@shopify/draggable'),
    template = require('./template'),
    editComponent = require('./editComponent'),
    canvasSetting = require('../attribute/canvasSetting'),
    compStyle = require('../attribute/component_style');

/**
 * 初始化组件部分
 */
$(function(){
    var $container = $("#xh-container"),
        $sidebar_header = $("#xh-sidebar-header"),
        $sidebar_content = $("#xh-sidebar-content"),
        $sidebar_components = $("#sidebar-components"),
        $sidebar_templates =$("#sidebar-templates"),
        baseCompsDom = [],
        // 拖动组件的临时变量
        compNew,
        targetBelowCursor,
        compBelowCursor;

    // event:切换sidebar标签页
    $sidebar_header.on("click", "div[data-xh-content-id]", function(){
        event.preventDefault();
        var content_id = this.getAttribute("data-xh-content-id");//$(this).attr("data-xh-content-id");
        common.toggleClass(this, "active");
        if(content_id == "sidebar-templates"){
            canvasSetting.getTemplate(1);
        }
        common.toggleClass("#"+content_id, "active");
    });

    // event: 切换components内容块
    $sidebar_components.on("click", ".xh-sidebar-content-header", function(){
        common.toggleClass(this, "active", 1);
    })
    // event: 切换templates内容块
    $sidebar_templates.on("click", ".xh-sidebar-content-header", function(){
        common.toggleClass(this, "active", 1);
    })

    // 初始化components九宫格
    //组件库 的基础组件，服务组件，表单组件
    $sidebar_components.find(".sidebar-form-components").append(initCompsDom("form"));
    $sidebar_components.find(".sidebar-base-components").append(initCompsDom("base"));
    $sidebar_components.find(".sidebar-service-components").append(initCompsDom("service"));


    //实现拖拽
    var draggable = new Draggable.Draggable(document.querySelectorAll('#sidebar-components'), {
        draggable: '.xh-components-unit',
    });
    draggable.on('mirror:created', function(evt){
        var target  = evt.originalSource,
            compsId = target.getAttribute("data-xh-comps-id"),
            type    = target.getAttribute("data-xh-comps-type"),
            comps   = template[type],
            index   = comps.id.indexOf(compsId),
            dom     = comps.container.replace('{{name}}', comps.nameZh[index]).replace('{{content}}', comps.template[index]);
        $(evt.mirror).empty().addClass("xh-components-unit-mirror").append(dom);
    });
    // draggable.on('drag:stop', function(evt){
    //     console.log(evt);
    //     var target  = evt.originalSource,
    //         compsId = target.getAttribute("data-xh-comps-id"),
    //         type    = target.getAttribute("data-xh-comps-type"),
    //         tc      = document.querySelector("#pagemain");
    //     if(dragUtils.isOverContainer("#pagemain", event.detail.data.clientX, event.detail.data.clientY)){
    //         try{
    //             if(type==="form"){
    //                 addCompentBox(parseInt(compsId));
    //                 //styleInit();
    //                 // $(".divBox").click();
    //             }else if(type == "services"){
    //             }else{
    //                 addContainerComponents(compsId, type);
    //             }
    //         }catch(e){
    //             console.log("Dragger stop event | error:"+e.message);
    //         }
    //         tc.scrollTop = tc.scrollHeight;
    //     }
    // });
    draggable.on('drag:stop', function(evt){
        console.log(evt);
        var eventData = event && event.detail.data || evt.data.sensorEvent.data;
        if(compNew){
            if(dragUtils.isOverContainer("#pagemain", eventData.clientX, eventData.clientY)){
                compNew.querySelector('.viewBox').style.visibility = 'visible';
            }else{
                compNew.remove();
            }
        }
        compNew = null;
        compBelowCursor = null;
    });

    /**
     * 判断cursor
     * 1. isOverContainer:是否在手机屏幕pageMain内
     * 2. getTargetBelowCursor：是否在某个组件内
     * 3. divBox_next: 检查子容器内
     */
    draggable.on('drag:move', (function dragMove(){
        var //interval = 50,
            timeoutId = 0,
            timer = + new Date(),
            timerInterval = 500,
            isOnProgress = false,
            doTask = function(evt){
                var target  = evt.originalSource,
                    compsId = target.getAttribute("data-xh-comps-id"),
                    type    = target.getAttribute("data-xh-comps-type"),
                    tc      = document.querySelector("#pagemain"),
                    scrollTop = tc.scrollTop,
                    eventData = event && event.detail.data || evt.data.sensorEvent.data;
                // 检查鼠标位置
                if(dragUtils.isOverContainer("#pagemain", eventData.clientX, eventData.clientY)){
                    // 检查是否已经存在
                    // 此处返回的时jq-obj，转换为dom
                    if( !compNew ){
                            compNew = editComponent(compsId, type).get(0);
                            compNew.querySelector('.viewBox').style.visibility = 'hidden';
                            compNew.style.border = '1px dashed black';
                    }
                    // 跟随cursor移动组件
                    targetBelowCursor = dragUtils.getTargetBelowCursor("#pagemain .divBox", eventData.clientX, eventData.clientY+scrollTop);    
                    if(targetBelowCursor && targetBelowCursor !== compBelowCursor){
                        compBelowCursor = targetBelowCursor;
                        compBelowCursor.after(compNew);
                    }
                }
            };
        return function(evt){
            // if(new Date().getTime() - timer > timerInterval && !isOnProgress){
            //     console.log(evt);
            //     isOnProgress = true;
            //     doTask(evt);
            //     timer = new Date().getTime();
            //     isOnProgress = false;
            //     clearTimeout(timeoutId);
            //     timeoutId = setTimeout(function(){doTask(evt);}, timerInterval*1.5);
            // }
            //为了保持灵敏，分流防抖都不合适，采用标识开关，并采用防抖的思路保证最后一次运行；
            if(!isOnProgress){
                // console.log(evt);
                isOnProgress = true;
                doTask(evt);
                isOnProgress = false;
            }
        }
    }()));


    // save form
    $("#saveForm").click(canvasSetting.saveForm);


    //手机容器内拖拽 ---------------------------------------------------------------------
    var container = document.getElementById("pagemain");

    var option = {
        draggable:".divBox",
        
        handle:".dragHandle",
        delay:100,
    };

    var dragableSort = new Draggable.Sortable(container,option);
    dragableSort.on('sortable:stop', function(event){ 
        console.log('sortable:stop',event);
        var newIndex = event.newIndex;
        var oldIndex = event.oldIndex;
        // console.log(newIndex,oldIndex);
        if(newIndex >= 0 && oldIndex>= 0){
            sortDargUp(newIndex,oldIndex);
        }
    });


    /**移动排序 
     * 交换数组的两个值
    */
    function sortDargUp(index1,index2){
        // console.log(index1,index2);
        var temp,
            formTepComArr = global.getData('formTepComArr');
        temp = formTepComArr[index1];
        formTepComArr[index1] = formTepComArr[index2];
        formTepComArr[index2] = temp;
    }




    /**
     * 初始化components九宫格
     * @param {string} type 内置类型
     */
    function initCompsDom(type){
        var compsHtml = [],
            temp    = template.grid,
            components   = template[type],
            id      = components.id,
            name    = components.nameZh,
            icon    = components.icon;
        for(var i=0, length=id.length; i<length; i++){
            compsHtml.push(temp.replace("{{id}}", id[i]).replace("{{name}}",name[i])
                .replace('{{icon}}', icon[i]).replace('{{type}}', type));
        }
        return compsHtml.join('');
    }


});