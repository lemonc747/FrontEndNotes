/**
 * 表单组件：单行输入
 */

var global = require('../utils/global'),
    Component = require('./component');

var info = {
    type: "form",
    id: "0",
    name: "SIMPLEINPUT",
    nameZh: "单行输入",
    icon: "fa-minus",
    preview: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
    template: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
}

var Input = function(options){
    debugger;
    this.info = info;
    Component.call(this);
};

Input.prototype = $.extend({}, Component.prototype, {constructor: Input}, {
    more: function(){
        console.log("input.more");
    },
    y: 1
});

// Input.prototype = Object.create(Component.prototype);
// Input.prototype.constructor = Input;

// Input.prototype.x = function(){
    
// }

module.exports = Input;