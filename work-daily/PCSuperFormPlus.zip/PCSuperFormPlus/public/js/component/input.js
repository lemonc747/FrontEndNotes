/**
 * 表单组件：单行输入
 */

var global = require('../utils/global'),
    Component = require('./component');

var TEMPLATE = {
    sort: "form",
    id: "0",
    type: "SIMPLEINPUT",
    name: "单行输入",
    icon: "fa-minus",
    preview: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
    template: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
}

var PROPERTIES = {
    type: TEMPLATE.type,
    label: TEMPLATE.name,
    desc: "请设置对表单的描述",
    placeholder: "请输入提示语",
    disabled: false,
    readonly: false,
    required: false,
    minnumber: 0,
    maxnumber: 200
}



var Input = function(options){        
    this.TEMPLATE = Object.create(TEMPLATE);
    this.PROPERTIES = Object.create(PROPERTIES);
    Component.call(this, options, PROPERTIES);
    this._init();
};
 
Object.assign(Input.prototype, Component.prototype, {constructor: Input}, {
    _init: function(){
        this._defineProperties();
    },
    _defineProperties: function(){
            
    }
});


module.exports = Input;