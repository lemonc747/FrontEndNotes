/**
>name               >type       >description
TEMPLATE            const       每个组件的模板常量
PH                  const       组件class占位符，通常与properties中的字段对应
BOX                 const       容器区域selector
TEMPLATE_ATTRS      object      属性表单模板
CLS                 o           通用class

*/

/**
 * 组件Types集合
 * 1. 组件类型type      小写
 * 2. 文件名            小写
 * 3. component.type   小写
 * 4. 构造函数          首字母大写，其他小写
 */
var COMPONENT_TYPES = {
    "form": ["input"],
    "base": [],
    "service": []
}




/**
 * DOM标识
 * var              selector            detail
 * BOX              #pagemain           区域
 * BOX_ATTRIBUTE    #component_attr_box 属性区域
 * BOX_STYLE        #component_style    样式区域
 * 
 */
var BOX = {
    main: "#pagemain",
    attributeParent: "#component_attr",
    attribute: "#component_attr_box",
    style: "#component_style",

    //集合：disabled & readOnly & required
    disabledSet: "component_disabled_set",
},
    // key : [selector, cssName, val]
    BOX_STYLE = {
        textAlign:          ["textAlign", "text-align", ""],
        verticalAlign:      ["verticalAlign", "vertical-align", ""],
        fontFamily:         ["fontFamily", "font-family", "normal"],//option
        fontSize:           ["fontSize", "font-size", "12"],
        fontSizeUnit:       ["fontSizeUnit", "", "px"],
        textStyle:          ["textStyle", "", ""],
        fontColor:          ["#style_font_color", "", "rgb(204, 204, 204)"],//id
        bgColor:            ["#style_bg_color", "", "rgb(255, 255, 255)"],//id
        opacity:            ["opacity", "", ""],
        opacityUnit:        ["opacityUnit", "", "%"],
        borderStyle:        ["borderStyle", "", "none"],//option
        borderWidth:        ["borderWidth", "", "0"],
        borderWidthUnit:    ["borderWidthUnit", "", "px"],
        borderColor:        ["#style_border_color", "", "rgb(255, 255, 255)"],//id
        borderRadius:       ["borderRadius", "", "0"],
        borderRadiusUnit:   ["borderRadiusUnit", "", "px"],
        letterSpacing:      ["letterSpacing", "", "0",],
        letterSpacingUnit:  ["letterSpacingUnit", "", "%"],
        lineHeight:         ["lineHeight", "", ""],
        zIndex:             ["zIndex", "", ""],
        paddingTop:         ["paddingTop", "", "0",],
        paddingTopUnit:     ["paddingTopUnit", "", "px"],
        paddingBottom:      ["paddingBottom", "", "0",],
        paddingBottomUnit:  ["paddingBottomUnit", "", "px"],
        paddingLeft:        ["paddingLeft", "", "0",],
        paddingLeftUnit:    ["paddingLeftUnit", "", "px"],
        paddingRight:       ["paddingRight", "", "0",],
        paddingRightUnit:   ["paddingRightUnit", "", "px"],
        marginTop:          ["marginTop", "", "0",],
        marginTopUnit:      ["marginTopUnit", "", "px"],
        marginBottom:       ["marginBottom", "", "0",],
        marginBottomUnit:   ["marginBottomUnit", "", "px"],
        marginLeft:         ["marginLeft", "", "0",],
        marginLeftUnit:     ["marginLeftUnit", "", "px"],
        marginRight:        ["marginRight", "", "0",],
        marginRightUnit:    ["marginRightUnit", "", "px"],
        overflow:           ["overflow", "", "hidden"],//option
    }

// common class
var CLS = {
    component:      'divBox',
    viewBox:        'viewBox',
    selected:       "selected",
    active:         "active",
    remove:         'selectTagRemove',
    drag:           'dragHandle'

    
}

// 属性值对应的class占位符
var PH = {
    label:          'component_label',
    desc:           'component_desc',
    placeholder:    'component_placeholder',
    disabled:       'component_disabled',
    readonly:       'component_readonly',
    required:       'component_required'
};

var TEMPLATE_ATTRS = {
    label: 
    '<div class="form-group col-md-12" style="margin-top: 10px">'+
        '<label class="col-md-12 control-label">表单项名称</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.label+'" placeholder="请输入表单项名称">'+
        '</div>'+
    '</div>',
    desc: 
    '<div class="form-group col-md-12">'+
        '<label class="col-md-12 control-label">表单项描述</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.desc+'" placeholder="请输入对表单项的描述">'+
        '</div>'+
    '</div>',
    placeholder:
    '<div class="form-group col-md-12">'+
        '<label class="col-md-12 control-label">表单项输入提示</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.placeholder+'" placeholder="请输入提示语">'+
        '</div>'+
    '</div>',
    disabledSet:
    '<div class="form-group col-md-12 '+BOX.disabledSet+'">'+
        '<label class="col-md-12 control-label">表单项控制</label>'+
        '<div class="col-md-12">' +
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.disabled+'"> 禁用'+
                '</label>'+
            '</div>'+
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.readonly+'"> 只读'+
                '</label>'+
            '</div>'+
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.required+'"> 必填'+
                '</label>'+
            '</div>'+
        '</div>'+
    '</div>'
}

module.exports = {
    BOX:                BOX,
    BOX_STYLE:          BOX_STYLE,  
    PH:                 PH,
    CLS:                CLS,
    TEMPLATE_ATTRS:     TEMPLATE_ATTRS,
    COMPONENT_TYPES:    COMPONENT_TYPES,
}