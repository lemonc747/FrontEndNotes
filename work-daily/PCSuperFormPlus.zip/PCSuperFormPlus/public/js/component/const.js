/**
>name               >type       >description
TEMPLATE            const       每个组件的模板常量
PH                  const       组件class占位符，通常与properties中的字段对应
BOX                 const       容器区域selector
TEMPLATE_ATTRS      object      属性表单模板
CLS                 o           通用class

*/






/**
 * DOM标识
 * var              selector            detail
 * BOX_MAIN         #pagemain           组件区域
 * BOX_ATTRIBUTE    #component_attr_box 属性区域
 * BOX_STYLE        #component_style    样式区域
 * 
 */
var BOX = {
    main: "#pagemain",
    attributeParent: "#component_attr",
    attribute: "#component_attr_box",
    style: "#component_style",

    //集合：disabled & readOnly & required
    disabledSet: "component_disabled_set",
}


var CLS = {
    component:      'divBox',
    selected:       "selected",
    active:         "active",
    remove:         'selectTagRemove',
    drag:           'dragHandle'

    
}

var PH = {
    label:          'component_label',
    desc:           'component_desc',
    placeholder:    'component_placeholder',
    disabled:       'component_disabled',
    readonly:       'component_readonly',
    required:       'component_required'
};

var TEMPLATE_ATTRS = {
    label: 
    '<div class="form-group col-md-12" style="margin-top: 10px">'+
        '<label class="col-md-12 control-label">表单项名称</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.label+'" placeholder="请输入表单项名称">'+
        '</div>'+
    '</div>',
    desc: 
    '<div class="form-group col-md-12">'+
        '<label class="col-md-12 control-label">表单项描述</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.desc+'" placeholder="请输入对表单项的描述">'+
        '</div>'+
    '</div>',
    placeholder:
    '<div class="form-group col-md-12">'+
        '<label class="col-md-12 control-label">表单项输入提示</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control '+PH.placeholder+'" placeholder="请输入提示语">'+
        '</div>'+
    '</div>',
    disabledSet:
    '<div class="form-group col-md-12 '+BOX.disabledSet+'">'+
        '<label class="col-md-12 control-label">表单项控制</label>'+
        '<div class="col-md-12">' +
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.disabled+'"> 禁用'+
                '</label>'+
            '</div>'+
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.readonly+'"> 只读'+
                '</label>'+
            '</div>'+
            '<div class="checkbox">'+
                '<label>'+
                    '<input type="checkbox" class="'+PH.required+'"> 必填'+
                '</label>'+
            '</div>'+
        '</div>'+
    '</div>'
}

module.exports = {
    BOX:                BOX,
    PH:                 PH,
    CLS:                CLS,
    TEMPLATE_ATTRS:     TEMPLATE_ATTRS
}