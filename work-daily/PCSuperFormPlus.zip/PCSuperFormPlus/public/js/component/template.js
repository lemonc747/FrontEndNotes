
var template = {
    // component icons
    grid: ['<div class="xh-components-unit" data-xh-comps-id="{{id}}" data-xh-comps-type="{{type}}">',
        '<i class="fa {{icon}}"></i>',
        '<span>{{name}}</span>',
    '</div>'].join(''),
    type: ["base", "service", "form"],

    //component title
    container: '<div class="xh-components-title component_Name">{{name}}</div>{{content}}',

    /**
     * 快速检索
     * retrieve缓存检索结果
     * 结构：retrieve.key.val
     */
    getComponent: function(){
        var retrieve =  {},
            that = this;
        return function(key, val){
            if( retrieve[key] && retrieve[key][val]){
                return retrieve[key][val];
            }
            var types = that.type,
                len=types.length;
            for(var i=0; i<len; i++){
                var templateArr = that[types[i]],
                    arrLen = templateArr.length,
                    index = templateArr[key].indexOf(val+'');
                if(index !== -1){
                    var result = {
                        type: types[i],
                        index: index,
                        id: templateArr.id[index], 
                        template: templateArr.template[index],
                        name: templateArr.name[index]
                    };
                    if( !retrieve[key] ){
                        retrieve[key] = {};
                    }
                    retrieve[key][val] = result;
                    return result;
                }
            }
        }
    }(),

       /**
     * 根据Name获取对应的模板
     */
    getComponentByID: function(id){
        return this.getComponent("id", id);
    },

    //返回int
    getCompIDByName: function(name){
        return parseInt(this.getComponent("name", name).id);
    },


};

 /**
  * 模板：表单组件
  */
template.form = {
    container: '<div class="xh-components-title component_Name">{{name}}</div>{{content}}',
    // 通过ID取index: template.form.id.indexOf(id);
    // id统一为string，因为在设置为data属性时会转为string
    id: ['0','1','2','3','4','5','6','7','8','9','10','11'],
    name: ['SIMPLEINPUT','TEXTAREA','RADIO','CHECKBOX','SELECT','NUMBER','DATE',
        'SWITCH','CASCADER','TEXT','SCORE','SPLITLINE'],
    nameZh: ['单行输入','多行输入','单选框','多选框','下拉框','数字','时间日期',
        '勾选框','地区级联','文本栏','评分','分割线'],
    icon:["fa-minus","fa-bars","fa-dot-circle-o","fa-check-square-o","fa-chevron-down","fa-sort-numeric-asc","fa-calendar",
        "fa-toggle-on","fa-globe","fa-sticky-note-o","fa-star-o","fa-minus-square-o"],
    template: [
        //单行输入
        ['<div class="weui-cells">',
            '<div class="weui-cell">',
            '<div class="weui-cell__bd">',
                '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
            '</div>',
            '</div>',
        '</div>'].join(''),
        //多行输入
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<textarea class="weui-textarea component_inputTip"  placeholder="请输入文本" rows="3"></textarea>',
            '<div class="weui-textarea-counter"><span>0</span>/200</div>',
            '</div>',
        '</div>'].join(''),
        //单选
        ['<div class="weui-cells weui-cells_radio" style="margin-top:0px;">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x110">',
            '<div class="weui-cell__bd">',
            '<p>cell standard</p>',
            '</div>',
            '<div class="weui-cell__ft">',
            '<input type="radio" class="weui-check" name="radio1" id="x101">',
            '<span class="weui-icon-checked"></span>',
            '</div>',
            '</label>',
        '</div>'].join(''),
        //多选
        ['<div class="weui-cells weui-cells_checkbox">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s110">',
            '<div class="weui-cell__hd">',
            '<input type="checkbox" class="weui-check" name="checkbox1" id="s110" checked="checked">',
            '<i class="weui-icon-checked"></i>',
            '</div>',
            '<div class="weui-cell__bd">',
            '<p>standard is dealt for u.</p>',
            '</div>',
        '</label>'].join(''),
        //下拉框
        ['<div class="weui-cell" style="background-color:#fff">',
            '<input class="weui-input component_inputTip" type="text" value="选项">',
        '</div>'].join(''),
        //数字
        ['<div class="weui-cell"  style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<label for="" class="weui-label component_Name">数字</label>',
            '<input class="weui-input" type="number" pattern="[0-9]*" placeholder="请输入数字">',
            '</div>',
        '</div>'].join(''),
        //日期
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="date" value="">',
            '</div>',
        '</div>'].join(''),
        //勾选框
        ['<label for="weuiAgree" class="weui-agree" style="background-color:#fff">',
            '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">',
            '<span class="weui-agree__text"><span class="component_Name">同意</span>',
            ' <a href="javascript:void(0);"> <span class="component_linkContent">《相关条款》</span></a>',
            '</span>',
        '</label>'].join(''),
        //级联
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<label for="" class="weui-label component_Name">选择地区</label>',
            '<input type="text" class="weui-input component_inputTip" id="city-picker" value="省 市 区/县" />',
            '</div>',
        '</div>'].join(''),
        //文本
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" value="请输入文本">',
            '</div>',
        '</div>'].join(''),
        //评分
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
                // '<span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span>',
                '<span class="fa fa-star"></span><span class="fa fa-star-half-o"></span><span class="fa fa-star-o"></span>',
            '</div>',
        '</div>'].join(''),
        //分割线
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<hr style=""/>',
            '</div>',
        '</div>'].join('')
    ]
}


/**
 * 模板：基础组件
 * 
 * 容器组件：子容器标识 `divBox_next`
 */
template.base = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    id: ['100','101','102','103','104','105','106'],
    name: ['GRID','FLEX','TABBAR','NAVBAR','SEARCH','ICON','PICTURE'],
    nameZh: ['九宫格','flex布局','标签页','导航栏','搜索框','图标','图片'],
    icon:["fa-th","fa-arrows-alt","fa-navicon","fa-bars","fa-search","fa-font-awesome","fa-image"],
    template: [
        // grid
        ['<div class="weui-grids">',
            circleStr('<a href="javascript:;" class="weui-grid"><div style="padding:10px;margin:0px;" class="weui-grid-inner"><div class="weui-grid__icon">'+
                '<img src="../../images/timg.jpg" alt="">'+
            '</div><p class="weui-grid__label divBox_next">Grid</p></div></a>', 6),
        '</div>'].join(''),
        // flex
                // style="margin: 5px;padding: 0 10px;background-color: #ebebeb;height: 2.3em;'+
        //     'line-height: 2.3em;text-align: center;color: #cfcfcf;"
        ['<div class="weui-flex">',
            circleStr('<div class="weui-flex__item"><div class="divBox_child" style="min-height:50px;border: 1px solid #cfcfcf;"></div></div>', 3),
        '</div>'].join(''),
        // navbar
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-navbar">',
                '<div data-navbar-num="first" class="weui-navbar__item weui-bar__item_on">选项一</div>',
                '<div data-navbar-num="second" class="weui-navbar__item">选项二</div>',
                '<divdata-navbar-num="third" class="weui-navbar__item">选项三</div>',
            '</div>',
            '<div data-navbar-num="first" class="weui-tab__panel">content</div>',
            '<div data-navbar-num="second" class="weui-tab__panel">content</div>',
            '<div data-navbar-num="third" class="weui-tab__panel">content</div>',
        '</div>'].join(''),
        // tabbar
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-tab__panel">content</div>',
            '<div class="weui-tabbar">',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<span style="display: inline-block;position: relative;">',
                        '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                        '<span class="weui-badge" style="position: absolute;top: -2px;right: -13px;">8</span>',
                    '</span>',
                    '<p class="weui-tabbar__label">微信</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                    '<p class="weui-tabbar__label">通讯录</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item weui-bar__item_on">',
                    '<span style="display: inline-block;position: relative;">',
                        '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                        '<span class="weui-badge weui-badge_dot" style="position: absolute;top: 0;right: -6px;"></span>',
                    '</span>',
                    '<p class="weui-tabbar__label">发现</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                    '<p class="weui-tabbar__label">我</p>',
                '</a>',
            '</div>',
        '</div>'].join(''),
        // search
        ['<div class="weui-search-bar" id="searchBar">',
            '<form class="weui-search-bar__form">',
                '<div class="weui-search-bar__box">',
                    '<i class="weui-icon-search"></i>',
                    '<input type="search" class="weui-search-bar__input" id="searchInput" placeholder="搜索" required="">',
                    '<a href="javascript:" class="weui-icon-clear" id="searchClear"></a>',
                '</div>',
                '<label class="weui-search-bar__label" id="searchText" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">',
                   '<i class="weui-icon-search"></i>',
                    '<span>搜索</span>',
                '</label>',
            '</form>',
            '<a href="javascript:" class="weui-search-bar__cancel-btn" id="searchCancel">取消</a>',
        '</div>'].join(''),
        // icon
        ['<div class="icon_sp_area">',
            '<i class="weui-icon-success"></i>',
        '</div>'].join(''),
        //image
        ['<div style="width:100%;" class=""><img style="width:100%;" src="http://img.zcool.cn/community/0142135541fe180000019ae9b8cf86.jpg@1280w_1l_2o_100sh.png"></div>'].join('')
    ]
}

/**
 * 模板：服务组件
 */
template.service = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    id: ['1000','1001','1002'],
    name: ['UPLOADFILE','THUMBSERVICE','COMMENTSERVICE'],
    nameZh: ['上传文件','点赞服务','评论服务'],
    icon:["fa-th","fa-arrows-alt","fa-navicon"],
    template: [
        // upLoadFile
        ['<div class="weui-grids">',
            circleStr('<a href="javascript:;" class="weui-grid"><p class="weui-grid__label">Grid</p></a>', 6),
        '</div>'].join(''),
        // thumbService
        ['<div class="weui-flex">',
            circleStr('<div class="weui-flex__item"><div style="margin: 5px;padding: 0 10px;background-color: #ebebeb;height: 2.3em;'+
            'line-height: 2.3em;text-align: center;color: #cfcfcf;">flex</div></div>', 3),
        '</div>'].join(''),
        // commentService
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-navbar">',
                '<div class="weui-navbar__item weui-bar__item_on">选项一</div>',
                '<div class="weui-navbar__item">选项二</div>',
                '<div class="weui-navbar__item">选项三</div>',
            '</div>',
            '<div class="weui-tab__panel">content</div>',
        '</div>'].join('')
    ]
}

/**
* 叠加time次string
* @param {*} str 
* @param {*} time 
*/
function circleStr(str, time){
   var result = '';
   for(var i=0; i<time; i++){
       result += str;
   }
   return result;
}

// init
(function init(){
    // step 1: id的快捷索引
    var types = template.type,
        len=types.length;
    for(var i=0; i<len; i++){
        var templateArr = template[types[i]],
            arrLen = templateArr.id.length;
        for(var j=0; j<arrLen; j++){
            template[templateArr.name[j]] = templateArr.id[j];
        }
    }
}());


module.exports = template;
