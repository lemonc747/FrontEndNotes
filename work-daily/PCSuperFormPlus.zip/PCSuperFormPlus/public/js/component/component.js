var common = require('../utils/common'),
    C = require('./const');

/**
 * this.data:
 * 
 * name             type        description
 * _options         object      初始化时的options对象, NOTICE: 可用属性以_options为准则
 * properties       object      定义defineProperties属性的对象
 * TEMPLATE         const       每个组件的模板常量
 */
var Component = function(options, child_ptions){
    this._options = Object.assign({}, child_ptions, typeof options === 'object' && options);
    this._super_init();
    window.test = this;
}

Component.prototype = { 
    constructor: Component,

    /*********************** private methods ************************/
    _super_init: function(){
        this._super_defineProperties();
    },

    _super_defineProperties: function(){
        var that = this,
            options = this._options,
            _value = {};
        this.properties = {};
        var commonProperties = {
            // component id 
            key: {
                get: function(){
                    console.log("component.key:"+_value.key);
                    return _value.key;
                },
                set: function(val){
                    _value.key = val;
                }
            },
            // component type
            type: {
                get: function(){
                    return _value.type;
                },
                set: function(val){
                    _value.type = val;
                }
            },

            label: {
                get:function(){
                    return _value.label;
                },
                set: function(val){
                    //attribute dom
                    if(!that._isAttrBoxInit()){
                        var $label = $(C.TEMPLATE_ATTRS.label);
                        $label.appendTo($(C.BOX.attribute));
                        $label.find("."+C.PH.label).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.label = result;
                        });
                    }
                    //component dom
                    $("#"+that.key).find("."+C.PH.label).text(val);
                    _value.label = val;
                }
            },
            desc: {
                get:function(){
                    return _value.desc;
                },
                set: function(val){
                    if(!that._isAttrBoxInit()){
                        var $desc = $(C.TEMPLATE_ATTRS.desc);
                        $desc.appendTo($(C.BOX.attribute));
                        $desc.find("."+C.PH.desc).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.desc = result;
                        });
                    }
                    $("#"+that.key).find("."+C.PH.desc).text(val);
                    _value.desc = val;
                }
            },

            placeholder: {
                get:function(){
                    return _value.placeholder;
                },
                set: function(val){
                    if(!that._isAttrBoxInit()){
                        var $placeholder = $(C.TEMPLATE_ATTRS.placeholder);
                        $placeholder.appendTo($(C.BOX.attribute));
                        $placeholder.find("."+C.PH.placeholder).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.placeholder = result;
                        });
                    }
                    //component dom
                    $("#"+that.key).find("."+C.PH.placeholder).attr("placeholder",val);
                    _value.placeholder = val;
                }
            },

            disabled:{
                get:function(){
                    return _value.disabled;
                },
                set: function(val){
                    debugger;
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.disabled).prop("checked", val).on("keyup", function(e){
                            
                            debugger;
                            var result = $(this).prop("checked");
                            that.properties.disabled = result;
                        });
                    }
                    _value.disabled = val;
                }
            },

            readonly:{
                get:function(){
                    return _value.readonly;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.readonly).prop("checked", val).on("keyup", function(e){
                            var result = $(this).prop("checked");
                            that.properties.readonly = result;
                        });
                    }
                    _value.readonly = val;
                }
            },

            required:{
                get:function(){
                    return _value.required;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.required).prop("checked", val).on("keyup", function(e){
                            var result = $(this).prop("checked");
                            that.properties.required = result;
                        });
                    }
                    _value.required = val;
                }
            },
        };
        //遍历有效的属性
        for(var item in options){
            if(commonProperties[item]){
                Object.defineProperty(this.properties, item, commonProperties[item]);
            }
        }
    },

    _isAttrBoxInit :function(){
        var key = $(C.BOX.attribute).data("key");
        return this.key && key && this.key === key;
    },

    /*********************** public methods ************************/

    formatOptionsToData: function(){

    },

    formatDataToOptions: function(){

    },

    setAllStyle: function(){

    },

    /**
     * entry1: create component
     * 
     * 1. create component instance
     * 2. create component dom
     * 3. create attribute dom
     * 4. update style dom
     * 5. watch attribute & style
     */
    load: function(){
        var key = this.key,
            key_attr = $(C.BOX.attribute).data("key"),
            component = document.querySelector("#"+key);
        if(!key || !component){
            component = this.createComponent();
        }
        this.loadProperties(this._options);
    },

    /**
     * entry2: selcted
     * 
     * selected component: update attributes form
     */
    selected: function(){
        var key = this.key,
            key_attr = $(C.BOX.attribute).data("key"),
            component = document.querySelector("#"+key);
        if(!key || !component){
            component = this.createComponent();
        }
        
        // init attributes & style form
        if(!key_attr || key_attr!== key){
            this.loadProperties(this.properties);
        }
    },

    /**
     * load component attributes, create attributes-C.BOX
     */
    loadProperties: function(options){
        for(var item in options){
            this.properties[item] = options[item];
        }
        //last step: mark selected component-key
        $(C.BOX.attribute).data("key", this.key);
        this._selectedStyle();
    },

    _selectedStyle: function(){
        var comp = $("#"+this.key);
        $(C.BOX.main).find("."+C.CLS.component).removeClass(C.CLS.selected);
        comp.addClass(C.CLS.selected);
        comp.find("."+C.CLS.remove).show();
        comp.find("."+C.CLS.drag).show();
        //?
        $("#sidebar-nav-tabs2").find('li').eq(0).addClass("active").siblings().removeClass("active");
        $(C.BOX.attributeParent).addClass(C.CLS.active).siblings().removeClass(C.CLS.active);
    },


    /**
     * 
     */
    renderStyleForm: function(){

    },

    /**
     * entry3:
     * 可单独创建组件的preview-dom
     */
    createComponent: function(){
        var key = common.guid(),
            preview = this.TEMPLATE.preview;
        var divBox = $("<div>").append("<div class='viewBox'>"+preview+"</div>")
            .addClass("divBox").addClass("."+C.CLS.selected).attr("id",key);
        // save data
        this.key = key;
        divBox.data("instance", this);
        //divBox.css({"border":"1px dashed black","position":"relative"});
        //setInputDisabled(divBox);
        var deleteBtn = $("<i>").addClass("fa fa-trash-o").attr("aria-hidden",true).addClass("selectTagRemove")
                .css({"position":"absolute","color":"red","right": "10px","top":"5px","font-size":"15px"});
        var dragBtn = $("<i>").addClass("fa fa-arrows").attr("aria-hidden",true).addClass("dragHandle")
                .css({"position":"absolute","font-weight":"bold",'color':'black',"right": "32px","top":"7px","font-size":"15px"});
        deleteBtn.appendTo(divBox);
        dragBtn.appendTo(divBox);
        deleteBtn.click(function () {
            var that = this;
            layer.confirm('确定移除该组件?', function(index){
                $(that).parent().remove();
                layer.close(index);
            });
        });
        divBox.appendTo($(C.BOX.main));
        return divBox;
    },

    /**
     * 手机预览：组件包含所有功能
     */
    renderPreview: function(){

    }

}




module.exports = Component;