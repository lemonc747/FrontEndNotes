var global = require('../utils/global'),
    common = require('../utils/common');

/**
 * 
 */
var DEFAULT = {
    key: 0,
    type: "",
    val: {
        typeNum: -1
    },
    styleObj: {

    },
    viewStyleObj: {

    },
    itemId: -1,
    jqObjID: -1,
    
}



var Component = function(){
    // this.
    this.data = 
    this._init();
}

Component.prototype = {
    constructor: Component,

    /*********************** private methods ************************/
    _init: function(){

    },

    _defineProperties: function(){
        Object.defineProperties();
    },

    /*********************** public methods ************************/

    getData: function(){

    }
}




module.exports = Component;