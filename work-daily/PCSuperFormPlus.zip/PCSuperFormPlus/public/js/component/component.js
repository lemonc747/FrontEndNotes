var global = require('../utils/global'),
    common = require('../utils/common');

/**
 * 内部属性为扁平结构，在输入和输出data时组织
 */
var default_info = {
    key: 0,
    type: "",
    val: {
        typeNum: -1
    },
    styleObj: {

    },
    viewStyleObj: {

    },
    preview: "",
    template: "",
    itemId: -1,
    jqObjID: -1,
    //是否已经初始化
    hasInit: false,
}

var default_attributes = {

};

/**
 * DOM标识
 */
var dom = {

}


var Component = function(options){
    this.options = options && typeof options === "object" ? 
        options : this._default_attributes;
    this._init();
}

Component.prototype = {
    constructor: Component,

    _default_info: default_info,
    _default_attributes: default_attributes,
    _dom: dom,

    /*********************** private methods ************************/
    _init: function(){
        debugger;
        //info
        this.info = $.extend({}, this._default_info, this.info||{});
        //more
        this.more && this.more();

        //this.hasInit = true;
    },

    _defineProperties: function(){
        // Object.defineProperties(this,
        // {

        // });
    },

    /*********************** public methods ************************/

    // dom: CONST_DOM_SELECTOR,

    getData: function(){

    },

    render: function(){
        return $(this.info.template).get(0);
    }
}




module.exports = Component;