

var global = require('../utils/global');
var common = require('../utils/common');
var styleInit = require('../attribute/styleInit');
var compStyle = require('../attribute/component_style'),
    compAttr = require('../attribute/component_attr'),
    template = require('../component/template');

/**
 * 初始化事件
 * bug: 事件委托和冒泡，导致点击内部divBox会触发两次
 */
(function init(){
    function selectComponent(target){
        styleInit.styleInit();
        var clickeKey = $(target).data("key");
        compAttr.cancelAllSelect();
        var clickData = getKeyData(clickeKey);
        if(!!clickData){
            styleInit.styleRuturn(clickData.val.styleObj);//样式回流
            compStyle.getStyleObj(clickData);
            compAttr.addSelect($('#'+clickData.jqObjID));
            //设置当前选中的
            compAttr.clickHaveSelectCom(clickData);
        }
    }
    //点击选中
    $(document).on("click","#pagemain>.divBox",function () {
        console.log(1);
        selectComponent(this);
    });
    $('#pagemain').on("click",".divBox_child>.divBox",function () {
        console.log(2);
        event.stopPropagation()
        selectComponent(this);
    });
}());

/**
 * 添加组件到预览
 * @param {Number} compsId 
 */
function addComponent(compsId, type){
    var container = template.container,
        comps   = template[type],
        index   = comps.id.indexOf(compsId),
        compStr     = container.replace('{{name}}', comps.nameZh[index]).replace('{{content}}', comps.template[index]);
    var compEl = createSelectCompentJQ(compStr);
    if(!!compEl){
        compEl.appendTo($("#pagemain"));
        global.setData('currentComJqID', compEl.attr("id"));
        //组装表单设置项
        compAttr.assembleSettingMeun(compsId);
    }
    return compEl;
}

/**创建选中的效果*/
function createSelectCompentJQ(componentStr){
    var divBox = $("<div>").append("<div class='viewBox'>"+componentStr+"</div>").addClass("divBox").attr("id",common.guid());
    divBox.css({"border":"1px dashed yellow","position":"relative"});
    setInputDisabled(divBox);
    var deleteBtn = $("<i>").addClass("fa fa-trash-o").attr("aria-hidden",true).addClass("selectTagRemove")
            .css({"position":"absolute","color":"red","right": "10px","top":"5px","font-size":"15px"});
    var dragBtn = $("<i>").addClass("fa fa-arrows").attr("aria-hidden",true).addClass("dragHandle")
            .css({"position":"absolute","font-weight":"bold",'color':'black',"right": "32px","top":"7px","font-size":"15px"});
    deleteBtn.appendTo(divBox);
    dragBtn.appendTo(divBox);
    deleteBtn.click(function () {
        var that = this;
        //移除控件还要移除相应的数据,key为控件唯一的标识
        var key=$(this).parent().data("key");
        layer.confirm('确定移除该组件?', function(index){
            //移除控件
            $(that).parent().remove();
            //移除formTemArr里面的数据
            if(!!key){
                removeKeyData(key);
            }
            layer.close(index);
        });
    });
    //移动
    dragBtn.click(function () {

    });


    return divBox;
}

/**让jq内所有的input框禁用 */
function setInputDisabled(divJq){
    for(var i = 0 ; i< divJq.find("input").length;i++){
        $(divJq.find("input")[i]).attr("disabled","disabled");
    }
}

/**移除UI相应的数据key */
function removeKeyData(key){
    var formTepComArr = global.getData('formTepComArr'),
        tempArr = [];
    for(var i = 0; i < formTepComArr.length; i++){
        if(formTepComArr[i].key != key){
            tempArr.push(formTepComArr[i]);
        }
    }
    global.setData('formTepComArr', tempArr);
}

/**找到相应的数据*/
function getKeyData(key){
    var formTepComArr = global.getData('formTepComArr');
    for(var i = 0; i < formTepComArr.length; i++){
        if(formTepComArr[i].key == key){
            // update selectedCompIndex 
            global.setSelectedIndex(i);
            return formTepComArr[i];
        }
    }
    return null;
}

// /**数组中的某个元素上移动一个位置 */
// function upInArray(key){
//     var temp,
//         formTepComArr = global.getData('formTepComArr');
//     for(var i = 0 ; i< formTepComArr.length; i++){
//         if(formTepComArr[i].key == key&& i != 0){
//             temp = formTepComArr[i];
//             formTepComArr[i] = formTepComArr[i-1];
//             formTepComArr[i-1] = temp;
//             break;
//         }
//     }
// }

// /**数组中的某个元素下移动一个位置 */
// function downInArray(key){
//     var temp,
//         formTepComArr = global.getData('formTepComArr');
//     for(var i = 0 ; i< formTepComArr.length; i++){
//         if(formTepComArr[i].key == key&& i <= formTepComArr.length-1){
//             temp = formTepComArr[i];
//             formTepComArr[i] = formTepComArr[i+1];
//             formTepComArr[i+1] = temp;
//             break;
//         }
//     }
// }

module.exports = addComponent;