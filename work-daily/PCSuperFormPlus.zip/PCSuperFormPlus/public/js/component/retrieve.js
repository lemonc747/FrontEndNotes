
// components
var C       = require('./const'),
    COMPONENT_TYPES = C.COMPONENT_TYPES,
    component = {};

// 遍历component types，引入对应的构造函数
for( var sort in COMPONENT_TYPES){
    var types = COMPONENT_TYPES[sort];
    for(var i=0,len=types.length; i<len; i++){
        var type = types[i].toLowerCase();
        component[type]= require("./"+type);
    }
}

/**
 * 检索
 * @param {object} options 
 */
var retrieve = function(options){
    var type = options && typeof options === "objext" ? options.type : options,
        comp = new component[type]();
    return comp;
}


module.exports = retrieve;


