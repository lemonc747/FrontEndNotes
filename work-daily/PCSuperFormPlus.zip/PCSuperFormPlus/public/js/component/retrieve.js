
// components
var //components  = require("./component"),
    Input        = require("./input"),
    Flex        = require("./flex");


/**
 * 组件Type集合
 */
var map = {
    "form": [],
    "base": [],
    "service": []
}

/**
 * 检索
 * @param {object} options 
 */
var retrieve = function(options){
    var type = options && typeof options === "objext" ? options.type : options,
        comp = eval('new '+type+'()');
    return comp;
}


module.exports = retrieve;


