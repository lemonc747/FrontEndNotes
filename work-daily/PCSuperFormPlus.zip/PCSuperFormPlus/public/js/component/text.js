/**
 * 表单组件：单行输入
 */

var global = require('../utils/global'),
    Component = require('./component');

var Text = function(){
    Component.call(this);
};

var attribute = {
    type: "form",
    id: "0",
    name: "SIMPLEINPUT",
    nameZh: "单行输入",
    icon: "fa-minus",
    preview: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
    template: 
    ['<div class="weui-cells">',
        '<div class="weui-cell">',
        '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
        '</div>',
        '</div>',
    '</div>'].join(''),
}

Text.prototype = $.extend({}, Component.prototype, {constructor: Text}, {
    x: function(){

    },
    y: 1
})

// Text.prototype = Object.create(Component.prototype);
// Text.prototype.constructor = Text;

// Text.prototype.x = function(){
    
// }