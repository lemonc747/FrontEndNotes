var global = require('../utils/global'),
    Component = require('./component');

var Text = function(){
    Component.call(this);
};

Text.prototype = Object.create(Component.prototype);
Text.prototype.constructor = Text;

Text.prototype.x = function(){
    
}