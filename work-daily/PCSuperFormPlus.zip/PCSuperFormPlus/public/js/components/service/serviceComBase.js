/*
 * @Author: lanjian
 * @Date: 2018-06-05 15:07:46
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-05 15:31:46
 * @Content desc: 服务组件基类
 */


import ComponentBase from '../componentBase'

class ServiceComBase extends ComponentBase{

    constructor(options){
        super(options);
    }
}

export default ServiceComBase;