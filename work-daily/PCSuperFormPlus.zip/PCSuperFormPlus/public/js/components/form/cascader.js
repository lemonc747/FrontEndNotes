/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  地区级联
 */

import common from '../../utils/common';
import FormComBase from './formComBase';

var template = {
    type: "cascader",
    name: "地区级联",
    icon: "fa-globe",
    preview:
    ['<div class="weui-cell" style="background-color:#fff">',
        '<div class="weui-cell__bd">',
        '<label for="" class="weui-label component_label">选择地区</label>',
        '<input type="text" class="weui-input component_placeholder" id="city-picker" value="省 市 区/县" />',
        '</div>',
    '</div>'].join(''),
    template:
    ['<div class="weui-cell" style="background-color:#fff">',
        '<div class="weui-cell__bd">',
        '<label for="" class="weui-label component_label">选择地区</label>',
        '<input type="text" class="weui-input component_placeholder" id="city-picker" value="省 市 区/县" />',
        '</div>',
    '</div>'].join(''),
};

var defaultData = {
    type: template.type,
    properties: {
        label: template.name,
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        minnumber: 0,
        maxnumber: 200
    }
}

class Cascader extends FormComBase{

    constructor(options){
        super();
        this.init(options);
    }

    init(options){
        this.defineOwnProperties();
        this.renerDom();
        options = options || defaultData;
        this.setData(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

    defineOwnProperties(){
        this.definePropertyModel();
    }

}

module.exports = Cascader;