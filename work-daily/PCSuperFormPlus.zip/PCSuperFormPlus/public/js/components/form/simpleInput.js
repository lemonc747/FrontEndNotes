/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  简单文本输入框
 */

import FormComBase from './formComBase';

// var template = {
//     type: "simpleInput",
//     name: "单行输入",
//     icon: "fa-minus",
//     preview:
//         ['<div class="weui-cells">',
//             '<div class="weui-cell">',
//             '<div class="weui-cell__bd">',
//                 '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
//             '</div>',
//             '</div>',
//         '</div>'].join(''),
//     template:
//     ['<div class="weui-cells">',
//         '<div class="weui-cell">',
//         '<div class="weui-cell__bd">',
//             '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
//         '</div>',
//         '</div>',
//     '</div>'].join(''),
// };



var template = {
    type: "simpleInput",
    name: "单行输入",
    template:
        ['<div class="weui-cells">',
            '<div class="weui-cell">',
            '<div class="weui-cell__bd">',
                '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
            '</div>',
            '</div>',
        '</div>'].join(''),
    properties: {
        label: "单行输入",
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        // minnumber: 0,
        // maxnumber: 200
    },
    style:{

    }
}

class SimpleInput extends FormComBase{

    constructor(options){
        super(template);
        this.init(options);
        window.test = this;
    }

    init(options){
        this.renerDom();
        this.render(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

}

module.exports = SimpleInput