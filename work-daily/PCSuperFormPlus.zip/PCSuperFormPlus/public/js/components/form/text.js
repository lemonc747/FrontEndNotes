/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  文本栏
 */

import common from '../../utils/common';
import FormComBase from './formComBase';

var template = {
    type: "text",
    name: "文本栏",
    icon: "fa-sticky-note-o",
    preview:
    ['<div class="weui-cell" style="background-color:#fff">',
        '<div class="weui-cell__bd">',
        '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
        '</div>',
    '</div>'].join(''),
    template:
    ['<div class="weui-cell" style="background-color:#fff">',
        '<div class="weui-cell__bd">',
        '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
        '</div>',
    '</div>'].join(''),
};

var defaultData = {
    type: template.type,
    properties: {
        label: template.name,
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        minnumber: 0,
        maxnumber: 200
    }
}

class Text extends FormComBase{

    constructor(options){
        super();
        this.init(options);
    }

    init(options){
        this.defineOwnProperties();
        this.renerDom();
        options = options || defaultData;
        this.setData(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

    defineOwnProperties(){
        this.definePropertyModel();
    }

}

module.exports = Text;