/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  勾选框
 */

import common from '../../utils/common';
import FormComBase from './formComBase';

var template = {
    type: "switch",
    name: "勾选框",
    icon: "fa-toggle-on",
    preview:
    ['<label for="weuiAgree" class="weui-agree" style="background-color:#fff">',
        '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">',
        '<span class="weui-agree__text"><span class="component_label">同意</span>',
        ' <a href="javascript:void(0);"> <span class="component_placeholder">《相关条款》</span></a>',
        '</span>',
    '</label>'].join(''),
    template:
    ['<label for="weuiAgree" class="weui-agree" style="background-color:#fff">',
        '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">',
        '<span class="weui-agree__text"><span class="component_label">同意</span>',
        ' <a href="javascript:void(0);"> <span class="component_placeholder">《相关条款》</span></a>',
        '</span>',
    '</label>'].join(''),
};

var defaultData = {
    type: template.type,
    properties: {
        label: template.name,
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        minnumber: 0,
        maxnumber: 200
    }
}

class Switch extends FormComBase{

    constructor(options){
        super();
        this.init(options);
    }

    init(options){
        this.defineOwnProperties();
        this.renerDom();
        options = options || defaultData;
        this.setData(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

    defineOwnProperties(){
        this.definePropertyModel();
    }

}

module.exports = Switch;