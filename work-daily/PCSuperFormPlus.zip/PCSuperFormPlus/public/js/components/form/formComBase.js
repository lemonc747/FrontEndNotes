/*
 * @Author: lanjian
 * @Date: 2018-06-05 15:07:46
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-05 15:31:26
 * @Content desc: 表单组件基类
 */


import ComponentBase from '../componentBase'

class FormComBase extends ComponentBase{

    constructor(options){
       super(options);
    }


}

export default FormComBase;