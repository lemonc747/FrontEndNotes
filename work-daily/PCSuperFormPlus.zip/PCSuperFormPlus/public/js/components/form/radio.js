/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  单选框
 */

import common from '../../utils/common';
import FormComBase from './formComBase';

var template = {
    type: "radio",
    name: "单选框",
    icon: "fa-dot-circle-o",
    preview:
        ['<div class="weui-cells weui-cells_radio" style="margin-top:0px;">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x110">',
            '<div class="weui-cell__bd">',
            '<p>cell standard</p>',
            '</div>',
            '<div class="weui-cell__ft">',
            '<input type="radio" class="weui-check" name="radio1" id="x101">',
            '<span class="weui-icon-checked"></span>',
            '</div>',
            '</label>',
        '</div>'].join(''),
    template:
        ['<div class="weui-cells weui-cells_radio" style="margin-top:0px;">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x110">',
            '<div class="weui-cell__bd">',
            '<p>cell standard</p>',
            '</div>',
            '<div class="weui-cell__ft">',
            '<input type="radio" class="weui-check" name="radio1" id="x101">',
            '<span class="weui-icon-checked"></span>',
            '</div>',
            '</label>',
        '</div>'].join(''),
};

var defaultData = {
    type: template.type,
    properties: {
        label: template.name,
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        minnumber: 0,
        maxnumber: 200
    }
}

class Radio extends FormComBase{

    constructor(options){
        super();
        this.init(options);
    }

    init(options){
        this.defineOwnProperties();
        this.renerDom();
        options = options || defaultData;
        this.setData(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

    defineOwnProperties(){
        this.definePropertyModel();
    }

}

module.exports = Radio;