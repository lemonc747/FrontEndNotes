/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:16:04
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-04 20:18:554
  * @Content desc:  评分
 */

import common from '../../utils/common';
import FormComBase from './formComBase';

var template = {
    type: "score",
            name: "评分",
            icon: "fa-star-o",
            preview:
            ['<div class="weui-cell" style="background-color:#fff">',
                '<div class="weui-cell__bd">',
                    '<span class="fa fa-star"></span><span class="fa fa-star-half-o"></span><span class="fa fa-star-o"></span>',
                '</div>',
            '</div>'].join(''),
            template:
            ['<div class="weui-cell" style="background-color:#fff">',
                '<div class="weui-cell__bd">',
                    '<span class="fa fa-star"></span><span class="fa fa-star-half-o"></span><span class="fa fa-star-o"></span>',
                '</div>',
            '</div>'].join(''),
};

var defaultData = {
    type: template.type,
    properties: {
        label: template.name,
        desc: "请设置对表单的描述",
        placeholder: "请输入提示语",
        disabled: false,
        readonly: false,
        required: false,
        minnumber: 0,
        maxnumber: 200
    }
}

class Score extends FormComBase{

    constructor(options){
        super();
        this.init(options);
    }

    init(options){
        this.defineOwnProperties();
        this.renerDom();
        options = options || defaultData;
        this.setData(options);
    }

    renerDom(){
        this.$self.append("<div class='viewBox'>"+template.template+"</div>")
    }

    defineOwnProperties(){
        this.definePropertyModel();
    }

}

module.exports = Score;