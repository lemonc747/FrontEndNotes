var common = require('../utils/common'),
    C = require('../const/const');

/**
 * this.data:
 *
 * name             type        description
 * _options         object      初始化时的options对象, NOTICE: 可用属性以_options为准则
 * properties       object      定义defineProperties属性的对象
 * TEMPLATE         const       每个组件的模板常量
 *
 * TIPS：
 * 1. 组件类型type，与构造函数同名，统一为小写
 *
 *
 */
var Component = function(options, child_ptions){
    this._options = Object.assign({}, child_ptions, typeof options === 'object' && options);
    this._super_init();
    window.test = this;
}

/**
 * 初始化组件样式的事件，执行一次
 */
Component.initStyleEvents= function(){
    //判断是否已经初始化
    if($(C.BOX.attribute).data("isStyleInited")){
        return;
    }
    $(C.BOX.attribute).data("isStyleInited", true);

    var $S = $(C.BOX.style),
        getSelected = function(){
            var key = $(C.BOX.attribute).data("key");
            return $("$#"+key).data("instance");

        },
        myEvents = function(key){
            $S.find(C.STYLE[key][0]).unbind("change").change(function(){
                var component = getSelected();
                if(component){
                    component.style[key] = $this.val();
                }
            });
        };


    $S.find(C.STYLE.textAlign[0]).find('button').unbind("click").click(function(){
        var $this = $(this),
        component = getSelected();
        if(component){
            component.style.textAlign = $this.data("value");
        }
        $this.removeClass('btn-default').addClass('btn-primary');
        $this.siblings().addClass('btn-default').removeClass('btn-primary');
    });
    $S.find(C.STYLE.verticalAlign[0]).find('button').unbind("click").click(function(){
        var $this = $(this),
        component = getSelected();
        if(component){
            component.style.verticalAlign = $this.data("value");
        }
        $this.removeClass('btn-default').addClass('btn-primary');
        $this.siblings().addClass('btn-default').removeClass('btn-primary')
    });
    myEvents("fontFamily");
    myEvents("fontSize");
    myEvents("fontSizeUnit");
    $S.find(C.STYLE.textStyle[0]).find('button').unbind("click").click(function(){
        // todo
        var component = getSelected();
        var result = [];
        $(this).toggleClass("btn-primary").parent().find("btn-primary")
        .each(function(item, index){
            result.push($(this).attr("data-value"));
        });
        if(component){
            component.style.textStyle = result;
        }
    });
    myEvents("fontColor");
    myEvents("bgColor");
    myEvents("opacity");
    myEvents("borderStyle");
    myEvents("borderWidth");
    myEvents("borderWidthUnit");
    myEvents("borderColor");
    myEvents("borderRadius");
    myEvents("borderRadiusUnit");
    myEvents("letterSpacing");
    myEvents("letterSpacingUnit");
    myEvents("lineHeight");
    myEvents("zIndex");
    myEvents("paddingTop");
    myEvents("paddingTopUnit");
    myEvents("paddingBottom");
    myEvents("paddingBottomUnit");
    myEvents("paddingLeft");
    myEvents("paddingLeftUnit");
    myEvents("paddingRight");
    myEvents("paddingRightUnit");
    myEvents("marginTop");
    myEvents("marginTopUnit");
    myEvents("marginBottom");
    myEvents("marginBottomUnit");
    myEvents("marginLeft");
    myEvents("marginLeftUnit");
    myEvents("marginRight");
    myEvents("marginRightUnit");
    myEvents("overflow");

};

Component.prototype = {
    constructor: Component,

    /*********************** private methods ************************/
    _super_init: function(){
        this.key = common.guid();
        Component.initStyleEvents();
        this._super_defineProperties();
        this._super_defineStyles();
    },

    _super_defineProperties: function(){
        var that = this,
            $comp = $("#"+this.key),
            options = this._options,
            _value = {};
        this.properties = {};
        var commonProperties = {
            // component id
            key: {
                enumerable: true,
                get: function(){
                    console.log("component.key:"+_value.key);
                    return _value.key;
                },
                set: function(val){
                    _value.key = val;
                }
            },
            // component type
            type: {
                enumerable: true,
                get: function(){
                    return _value.type;
                },
                set: function(val){
                    _value.type = val;
                }
            },

            label: {
                enumerable: true,
                get:function(){
                    return _value.label;
                },
                set: function(val){
                    //attribute dom
                    if(!that._isAttrBoxInit()){
                        var $label = $(C.TEMPLATE_ATTRS.label);
                        $label.appendTo($(C.BOX.attribute));
                        $label.find("."+C.PH.label).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.label = result;
                        });
                    }
                    //component dom
                    $comp.find("."+C.PH.label).text(val);
                    _value.label = val;
                }
            },
            desc: {
                enumerable: true,
                get:function(){
                    return _value.desc;
                },
                set: function(val){
                    if(!that._isAttrBoxInit()){
                        var $desc = $(C.TEMPLATE_ATTRS.desc);
                        $desc.appendTo($(C.BOX.attribute));
                        $desc.find("."+C.PH.desc).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.desc = result;
                        });
                    }
                    $comp.find("."+C.PH.desc).text(val);
                    _value.desc = val;
                }
            },

            placeholder: {
                enumerable: true,
                get:function(){
                    return _value.placeholder;
                },
                set: function(val){
                    if(!that._isAttrBoxInit()){
                        var $placeholder = $(C.TEMPLATE_ATTRS.placeholder);
                        $placeholder.appendTo($(C.BOX.attribute));
                        $placeholder.find("."+C.PH.placeholder).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.properties.placeholder = result;
                        });
                    }
                    //component dom
                    $comp.find("."+C.PH.placeholder).attr("placeholder",val);
                    _value.placeholder = val;
                }
            },

            disabled:{
                enumerable: true,
                get:function(){
                    return _value.disabled;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.disabled).prop("checked", val).on("click", function(e){
                            var result = $(this).prop("checked");
                            that.properties.disabled = result;
                        });
                    }
                    _value.disabled = val;
                }
            },

            readonly:{
                enumerable: true,
                get:function(){
                    return _value.readonly;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.readonly).prop("checked", val).on("click", function(e){
                            var result = $(this).prop("checked");
                            that.properties.readonly = result;
                        });
                    }
                    _value.readonly = val;
                }
            },

            required:{
                enumerable: true,
                get:function(){
                    return _value.required;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isAttrBoxInit()){
                        var $container = $(C.BOX.attribute),
                            $disabledSet = $container.find('.'+C.BOX.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(C.TEMPLATE_ATTRS.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+C.PH.required).prop("checked", val).on("click", function(e){
                            console.log("component required clicked!");
                            var result = $(this).prop("checked");
                            that.properties.required = result;
                        });
                    }
                    _value.required = val;
                }
            },
        };
        //遍历有效的属性
        for(var item in options){
            if(commonProperties[item]){
                Object.defineProperty(this.properties, item, commonProperties[item]);
            }
        }
    },

    /**
     * 定义：样式字段
     * 
     * 组件样式(style)和组件属性(attribute)的一个区别：
     * - style是固定的，所有组件公共样式选项
     * - style事件监听注册一次即可
     * - attribute由组件不同而不同，每次选中或初始化重新绘制，并重新绑定事件
     */
    _super_defineStyles: function(){
        this.style = {};
        var myStyle = this.style,
            STYLE   = C.STYLE,
            //$comp = $("#"+this.key),
            $viewBox = $("#"+this.key).find("."+C.CLS.viewBox),
            $STYLE = $(C.BOX.style),
            _value = {},
            //通用的定义样式的方式
            _defineEachStyle= function(key, comboKey, isUnit){
                return {
                    enumerable: true,
                    set: function(val){
                        _value[key] = val;
                        if(combokey && myStyle[combokey]){
                            val = isUnit ? (myStyle[comboKey]+val) : (val+myStyle[comboKey]);
                        }
                        $viewBox.css(C.STYLE[key][1], val);
                        // 样式表单更新
                        $STYLE.find(C.STYLE[key][0]).val(val);
                    }
                }
            },
            commonStyle = {
                textAlign:{
                    enumerable: true,
                    set: function(val){
                        _value.textAlign = val;
                        $viewBox.css(C.STYLE.textAlign[1], val);
                        var $s = $STYLE.find(C.STYLE.textAlign[0]).find("button[data-value ="+val+"]");
                        $s.removeClass('btn-default').addClass('btn-primary');
                        $s.siblings().addClass('btn-default').removeClass('btn-primary');
                    }
                },
                verticalAlign:{
                    enumerable: true,
                    set: function(val){
                        _value.textAlign = val;
                        $viewBox.css(C.STYLE.verticalAlign[1], val);
                        var $s = $STYLE.find(C.STYLE.verticalAlign[0]).find("button[data-value ="+val+"]");
                        $s.removeClass('btn-default').addClass('btn-primary');
                        $s.siblings().addClass('btn-default').removeClass('btn-primary');
                    }
                },
                fontFamily:_defineEachStyle("fontFamily"),
                fontSize:_defineEachStyle("fontSize", "fontSizeUnit", false),
                fontSizeUnit:_defineEachStyle("fontSizeUnit", "fontSize", true),
                textStyle:{
                    enumerable: true,
                    set: function(val){
                        _value.textStyle = val;
                        if(val && val.includes){
                            if(val.includes("bold")){
                                $viewBox.css("font-weight", val);
                            }
                            if(val.includes("italic")){
                                $viewBox.css("font-style", val);
                            }
                            if(val.includes("underline")){
                                $viewBox.css("text-decoration", val);
                            }
                        }
                        
                    }
                },
                fontColor:_defineEachStyle("fontColor"),
                bgColor:_defineEachStyle("bgColor"),
                opacity:_defineEachStyle("opacity"),
                borderStyle:_defineEachStyle("borderStyle"),
                borderWidth:_defineEachStyle("borderWidth", "borderWidthUnit", false),
                borderWidthUnit:_defineEachStyle("borderWidthUnit", "borderWidth", true),
                borderColor:_defineEachStyle("borderColor"),
                borderRadius:_defineEachStyle("borderRadius", "borderRadiusUnit", false),
                borderRadiusUnit:_defineEachStyle("borderRadiusUnit", "borderRadius", true),
                letterSpacing:_defineEachStyle("letterSpacing", "letterSpacingUnit", false),
                letterSpacingUnit:_defineEachStyle("letterSpacingUnit", "letterSpacing", true),
                lineHeight:_defineEachStyle("lineHeight"),
                zIndex:_defineEachStyle("zIndex"),
                overflow:_defineEachStyle("overflow"),
                paddingTop:_defineEachStyle("paddingTop", "paddingTopUnit", false),
                paddingTopUnit:_defineEachStyle("paddingTopUnit", "paddingTop", true),
                paddingBottom:_defineEachStyle("paddingBottom", "paddingBottomUnit", false),
                paddingBottomUnit:_defineEachStyle("paddingBottomUnit", "paddingBottom", true),
                paddingLeft:_defineEachStyle("paddingLeft", "paddingLeftUnit", false),
                paddingLeftUnit:_defineEachStyle("paddingLeftUnit", "paddingLeft", true),
                paddingRight:_defineEachStyle("paddingRight", "paddingRightUnit", false),
                paddingRightUnit:_defineEachStyle("paddingRightUnit", "paddingRight", true),
                marginTop:_defineEachStyle("marginTop", "marginTopUnit", false),
                marginTopUnit:_defineEachStyle("marginTopUnit", "marginTop", true),
                marginBottom:_defineEachStyle("marginBottom", "marginBottomUnit", false),
                marginBottomUnit:_defineEachStyle("marginBottomUnit", "marginBottom", true),
                marginLeft:_defineEachStyle("marginLeft", "marginLeftUnit", false),
                marginLeftUnit:_defineEachStyle("marginLeftUnit", "marginLeft", true),
                marginRight:_defineEachStyle("marginRight", "marginRightUnit", false),
                marginRightUnit:_defineEachStyle("marginRightUnit", "marginRight", true),
            };
        Object.defineProperties(myStyle, commonStyle);
    },

    
    /**
     * load component attributes, create attributes-C.BOX
     */
    _loadProperties: function(options){
        $(C.BOX.attribute).empty();
        for(var item in options){
            this.properties[item] = options[item];
        }
        //last step: mark selected component-key
        $(C.BOX.attribute).data("key", this.key);
        //this._selectedStyle();
    },

    _loadStyles: function(){
        for(var item in options){
            this.style[item] = style[item];
        }
    },

    //给组件添加选中的样式
    _addSelectedStyle: function(){
        var comp = $("#"+this.key);
        $(C.BOX.main).find("."+C.CLS.component).removeClass(C.CLS.selected);
        comp.addClass(C.CLS.selected);
        comp.find("."+C.CLS.remove).show();
        comp.find("."+C.CLS.drag).show();
        //?
        $("#sidebar-nav-tabs2").find('li').eq(0).addClass("active").siblings().removeClass("active");
        $(C.BOX.attributeParent).addClass(C.CLS.active).siblings().removeClass(C.CLS.active);
    },

    /**
     * isInit=true: 标识“组件属性+样式区域”初始化完成
     * isInit=false: 返回是否初始化完成
     */
    _isAttrBoxInit :function(isInit){
        if(isInit){
            $(C.BOX.attribute).data("key", this.key);
            return true;
        }else{
            var key = $(C.BOX.attribute).data("key");
            return this.key && key && this.key === key;
        }
    },

    /*********************** public methods ************************/

    /**
     * entry1: create component
     *
     * 1. create component instance
     * 2. create component dom
     * 3. create attribute dom
     * 4. update style dom
     * 5. watch attribute & style
     */
    load: function(){
        // 1. create component instance
        var key = this.key,
            //key_attr = $(C.BOX.attribute).data("key"),
            component = document.querySelector("#"+key);
        if(!key || !component){
            component = this.createComponent();
        }
        // 2. component-attribute
        this._loadProperties(this._options);
        this._loadStyles();
        this._addSelectedStyle();
    },

    /**
     * entry2: selcted
     *
     * selected component: update attributes form
     */
    select: function(){
        // 1. create component instance
        var key = this.key,
            key_attr = $(C.BOX.attribute).data("key"),
            component = document.querySelector("#"+key);
        if(!key || !component){
            component = this.createComponent();
        }

        if(!key_attr || key_attr!== key){
            this._loadProperties(this.properties);
            this._addSelectedStyle();
        }

    },


    /**
     * entry3:
     * 可单独创建组件的preview-dom
     */
    createComponent: function(){
        var preview = this.TEMPLATE.preview,
            key     = this.key;
        var divBox = $("<div>").append("<div class='viewBox'>"+preview+"</div>")
            .addClass("divBox").addClass(C.CLS.selected).attr("id",key);
        // save data
        divBox.data("instance", this);
        //setInputDisabled(divBox);
        var deleteBtn = $("<i>").addClass("fa fa-trash-o").attr("aria-hidden",true).addClass("selectTagRemove")
                .css({"position":"absolute","color":"red","right": "10px","top":"5px","font-size":"15px"});
        var dragBtn = $("<i>").addClass("fa fa-arrows").attr("aria-hidden",true).addClass("dragHandle")
                .css({"position":"absolute","font-weight":"bold",'color':'black',"right": "32px","top":"7px","font-size":"15px"});
        deleteBtn.appendTo(divBox);
        dragBtn.appendTo(divBox);
        deleteBtn.click(function () {
            var that = this;
            layer.confirm('确定移除该组件?', function(index){
                $(that).parent().remove();
                layer.close(index);
            });
        });
        divBox.appendTo($(C.BOX.main));
        return divBox;
    },

    /**
     * 手机预览：组件包含所有功能
     */
    renderPreview: function(){
    }
}

module.exports = Component;