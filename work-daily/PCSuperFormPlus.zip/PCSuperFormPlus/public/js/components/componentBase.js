/*
 * @Author: lanjian
 * @Date: 2018-06-04 20:04:34
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-05 11:14:47
 * @Content desc: 组件基类
 */

// import _ from 'loadsh';
// import $ from 'jquery';
// import C from '../const/const';
/**------------------------ const ------------------------------- */
/**
>name               >type       >description
attrPH              const       组件class占位符，通常与properties中的字段对应
attrTemplates       c           公共组件属性dom模板
boxs                const       容器区域selector
styleMap            object      样式
CLS                 o           通用class

*/


/**
 * DOM标识
 * var              selector                detail
 * BOX              #pagemain               区域
 * ATTRIBUTE        #component_attr_box     属性区域
 * STYLE            #component_style        样式区域
 *
 */
var boxs = {
    main: "#pagemain",
    attributeParent: "#component_attr",
    attribute: "#component_attr_box",
    style: "#component_style",
    //集合：disabled & readOnly & required
    disabledSet: "component_disabled_set",
}

// key : [selector, cssName, val]
var styleMap = {
    textAlign:          [".textAlign", "textAlign", ""],
    verticalAlign:      [".verticalAlign", "verticalAlign", ""],
    fontFamily:         [".fontFamily", "fontFamily", "normal"],//option
    fontSize:           [".fontSize", "fontSize", "12"],
    fontSizeUnit:       [".fontSizeUnit", "fontSize", "px"],
    textStyle:          [".textStyle", "", ""],
    fontColor:          ["#style_font_color", "color", "rgb(204, 204, 204)"],//id
    bgColor:            ["#style_bg_color", "backgroundColor", "rgb(255, 255, 255)"],//id
    opacity:            [".opacity", "opacity", ""],
    borderStyle:        [".borderStyle", "borderStyle", "none"],//option
    borderWidth:        [".borderWidth", "borderWidth", "0"],
    borderWidthUnit:    [".borderWidthUnit", "borderWidth", "px"],
    borderColor:        ["#style_border_color", "borderColor", "rgb(255, 255, 255)"],//id
    borderRadius:       [".borderRadius", "borderRadius", "0"],
    borderRadiusUnit:   [".borderRadiusUnit", "borderRadius", "px"],
    letterSpacing:      [".letterSpacing", "letterSpacing", "0",],
    letterSpacingUnit:  [".letterSpacingUnit", "letterSpacing", "%"],
    lineHeight:         [".lineHeight", "lineHeight", ""],
    zIndex:             [".zIndex", "zIndex", ""],
    paddingTop:         [".paddingTop", "paddingTop", "0",],
    paddingTopUnit:     [".paddingTopUnit", "paddingTop", "px"],
    paddingBottom:      [".paddingBottom", "paddingBottom", "0",],
    paddingBottomUnit:  [".paddingBottomUnit", "paddingBottom", "px"],
    paddingLeft:        [".paddingLeft", "paddingLeft", "0",],
    paddingLeftUnit:    [".paddingLeftUnit", "paddingLeft", "px"],
    paddingRight:       [".paddingRight", "paddingRight", "0",],
    paddingRightUnit:   [".paddingRightUnit", "paddingRight", "px"],
    marginTop:          [".marginTop", "marginTop", "0",],
    marginTopUnit:      [".marginTopUnit", "marginTop", "px"],
    marginBottom:       [".marginBottom", "marginBottom", "0",],
    marginBottomUnit:   [".marginBottomUnit", "marginBottom", "px"],
    marginLeft:         [".marginLeft", "marginLeft", "0",],
    marginLeftUnit:     [".marginLeftUnit", "marginLeft", "px"],
    marginRight:        [".marginRight", "marginRight", "0",],
    marginRightUnit:    [".marginRightUnit", "marginRight", "px"],
    overflow:           [".overflow", "overflow", "hidden"],//option
}

// component common class
var compClass = {
    container:      'divBox',
    viewBox:        'viewBox',
    selected:       "only-selected",
    outline:        "only-outline",
    active:         "active",
    remove:         'selectTagRemove',
    drag:           'dragHandle'
}

// attribute placeholder: 属性值对应的class占位符
var attrPH = {
    label:          'component_label',
    desc:           'component_desc',
    placeholder:    'component_placeholder',
    disabled:       'component_disabled',
    readonly:       'component_readonly',
    required:       'component_required'
};

// default properties 
var commonProperties = {
    label: {
        value: "请输入标题",
        template:     
            '<div class="form-group col-md-12" style="margin-top: 10px">'+
                '<label class="col-md-12 control-label">表单项名称</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control '+attrPH.label+'" placeholder="请输入表单项名称">'+
                '</div>'+
            '</div>',
        set: function(component, val){
            component.$self.find("."+attrPH.label).text(val);
        },
        bindSetting:function($setting, component){
            $setting.find("."+attrPH.label).on("keyup", function(e){
                component.data.properties.label = $(this).val();
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.label).val(val);
        }
    },
    desc: {
        value: "请输入标题",
        template: 
            '<div class="form-group col-md-12">'+
                '<label class="col-md-12 control-label">表单项描述</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control '+attrPH.desc+'" placeholder="请输入对表单项的描述">'+
                '</div>'+
            '</div>',
        set: function(component, val){
            component.$self.find("."+attrPH.desc).text(val);
        },
        bindSetting:function($setting, component){
            $setting.find("."+attrPH.desc).on("keyup", function(e){
                component.data.properties.desc = $(this).val();
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.desc).val(val);
        }
    },
    placeholder: {
        value: "请输入标题",
        template: 
            ['<div class="form-group col-md-12">',
                '<label class="col-md-12 control-label">表单项输入提示</label>',
                '<div class="col-md-12">',
                    '<input type="text" class="form-control '+attrPH.placeholder+'" placeholder="请输入提示语">',
                '</div>',
            '</div>'].join(''),
        //get: undefined,
        set: function(component, val){
            component.$self.find("."+attrPH.placeholder).attr("placeholder",val);
        },
        bindSetting:function($setting, component){
            debugger;
            $setting.find("."+attrPH.placeholder).on("keyup", function(e){
                component.data.properties.placeholder = $(this).val();
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.placeholder).val(val);
        }
    },
    disabled: {
        value: "请输入标题",
        template: 
            ['<div class="col-md-12">',
                '<div class="checkbox">',
                    '<label>',
                        '<input type="checkbox" class="'+attrPH.disabled+'"> 禁用',
                    '</label>',
                '</div>',
            '</div>'].join(''),
        bindSetting:function($setting, component){
            $setting.find("."+attrPH.disabled).on("click", function(e){
                component.data.properties.disabled = $(this).prop("checked");
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.disabled).prop("checked", val);
        }
    },
    readonly: {
        value: "请输入标题",
        template: 
            ['<div class="col-md-12">',
                '<div class="checkbox">',
                    '<label>',
                        '<input type="checkbox" class="'+attrPH.readonly+'"> 禁用',
                    '</label>',
                '</div>',
            '</div>'].join(''),
        bindSetting:function($setting, component){
            $setting.find("."+attrPH.readonly).on("click", function(e){
                component.data.properties.readonly = $(this).prop("checked");
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.readonly).prop("checked", val);
        }
    },
    required: {
        value: "请输入标题",
        template: 
            ['<div class="col-md-12">',
                '<div class="checkbox">',
                    '<label>',
                        '<input type="checkbox" class="'+attrPH.required+'"> 禁用',
                    '</label>',
                '</div>',
            '</div>'].join(''),
        bindSetting:function($setting, component){
            $setting.find("."+attrPH.required).on("click", function(e){
                component.data.properties.required = $(this).prop("checked");
            });
        },
        loadSetting: function($setting, val){
            $setting.find("."+attrPH.required).prop("checked", val);
        }
    }
}

// // attribute template
// var attrTemplates = {
//     label:
//     '<div class="form-group col-md-12" style="margin-top: 10px">'+
//         '<label class="col-md-12 control-label">表单项名称</label>'+
//         '<div class="col-md-12">'+
//             '<input type="text" class="form-control '+attrPH.label+'" placeholder="请输入表单项名称">'+
//         '</div>'+
//     '</div>',
//     desc:
//     '<div class="form-group col-md-12">'+
//         '<label class="col-md-12 control-label">表单项描述</label>'+
//         '<div class="col-md-12">'+
//             '<input type="text" class="form-control '+attrPH.desc+'" placeholder="请输入对表单项的描述">'+
//         '</div>'+
//     '</div>',
//     placeholder:
//     '<div class="form-group col-md-12">'+
//         '<label class="col-md-12 control-label">表单项输入提示</label>'+
//         '<div class="col-md-12">'+
//             '<input type="text" class="form-control '+attrPH.placeholder+'" placeholder="请输入提示语">'+
//         '</div>'+
//     '</div>',
//     disabledSet:
//     '<div class="form-group col-md-12 '+boxs.disabledSet+'">'+
//         '<label class="col-md-12 control-label">表单项控制</label>'+
//         '<div class="col-md-12">' +
//             '<div class="checkbox">'+
//                 '<label>'+
//                     '<input type="checkbox" class="'+attrPH.disabled+'"> 禁用'+
//                 '</label>'+
//             '</div>'+
//             '<div class="checkbox">'+
//                 '<label>'+
//                     '<input type="checkbox" class="'+attrPH.readonly+'"> 只读'+
//                 '</label>'+
//             '</div>'+
//             '<div class="checkbox">'+
//                 '<label>'+
//                     '<input type="checkbox" class="'+attrPH.required+'"> 必填'+
//                 '</label>'+
//             '</div>'+
//         '</div>'+
//     '</div>'
// }


class Component{
    constructor(template){
        if (new.target === Component) {
            throw new Error('组件基类不能实例化');
        }
        this.$self = null;
        this._init(template);
    }

    //public

    // setData(data){
    //     data = data || this.data;
    //     //复制属性 & 渲染
    //     this.data.key = data.key || this.data.key;
    //     this.data.type = data.type || this.data.type;
    //     this._loadProperties(data.properties);
    //     this._loadStyles(data.style);
    //     this._addSeletedStyle();
    // }

    getData(){
        return Object.create(this.data);
    }

    getKey(){
        return this.data.key;
    }

    getProperty(key){
        return this.data.properties[key];
    }
    
    // setProperty(key, value){
    //     this.data.properties[key] = value;
    // }

    // getStyle(key){
    //     return this.data.properties[key];
    // }

    getDom(){
        return this.$self;
    }

    // /**
    //  * 被选中的方法
    //  */
    // selected(){
    //     var key = this.data.key,
    //         key_attr = $(boxs.attribute).data("key");
    //     if(!key_attr || key_attr!== key){
    //         this._bindBaseStyleEvent();            
    //         this.setData();
    //     }
    // }

    /**
     * 绘制
     * 1. 给组件添加选中样式
     * 2. properties
     * 3. style
     */
    render(data){    
        data = data || this.data;
        this.data.key = data.key || this.data.key;
        this.data.type = data.type || this.data.type;
        //属性
        this._loadProperties(data.properties);
        this._loadAndBindPropertiesSetting();
        //样式
        this._loadStyles(data.style);
        this._bindBaseStyleEvents();   
        //选中效果
        this._addSeletedStyle();
    }

    /**
     * 添加dom
     * @param {需要添加到的dom} dom
     */
    appendToBody(dom){
        if(!!dom){
            this.$self.appendTo(dom);
        }else{
            this.$self.appendTo($("#pagemain"));
        }
    }

    /**组件拖动中的处理 */
    dragMove(){
        this._addSeletedStyle();
        this.$self.addClass(compClass.outline);
    }

    /**组件停止拖动的处理 */
    dragStop(){
        this.$self.removeClass("only-outline");
    }

    destroy(){
        if(!!this.$self){
            this.$self.remove();
            this.$self = null;
        }
    }

    // /**
    //  * 自定义拓展property
    //  * @param {obj} obj 
    //  * prop: property name
    //  * get(val): val为默认值，返回自定义值，执行自定义操作; obj.get==undefined时返回val
    //  * set(val): 
    //  * settingDom(that): 创建属性设置区域,that表示该组件实例
    //  */
    // definePropertyModel(obj){
    //     if(!obj || !obj.prop ){
    //         return;
    //     }
    //     Object.defineProperty(this.data.properties, obj.prop,{
    //         enumerable: true,
    //         get:function(){
    //             return obj.get&& obj.get instanceof Function ?
    //                 obj.get(_value.label) : _value.label;
    //         },
    //         set: function(val){
    //             if(obj.set&& obj.set instanceof Function){
    //                 obj.set(val);
    //             }
    //             _value.label = val;
    //             // todo ????

    //                 // if(!that._isSelected()){
    //                 //     var $label = $(attrTemplates.label);
    //                 //     $label.appendTo($(boxs.attribute));
    //                 //     $label.find("."+attrPH.label).val(val).on("keyup", function(e){
    //                 //         var result = $(this).val();
    //                 //         that.data.properties.label = result;
    //                 //     });
    //                 // }
    //                 // //component dom
    //                 // that.$self.find("."+attrPH.label).text(val);
    //                 // _value.label = val;
                
    //         }
    //     })
    // }

    /*--------------------------------      private methods     ------------------------------*/

    //添加选中效果
    _addSeletedStyle(){
        //移除其他组件的选中状态
        $(boxs.main).find("."+compClass.container)
            .removeClass(compClass.selected).removeClass(compClass.outline);
        this.$self.addClass("only-selected");
        // 选中"组件属性"区域
        $("#sidebar-nav-tabs2").find('li').eq(0).addClass("active").siblings().removeClass("active");
        $(boxs.attributeParent).addClass(compClass.active).siblings().removeClass(compClass.active);
    }

    _init(template){
        this._initData(template);
        this._initDom();
        //定义属性
        this._initOwnPropeties(template.properties);
        this._defineProperties();
        // this._defineBaseProperties();
        //style尚未修改
        this._bindBaseStyleEvents();
        this._defineStyles();
    }

    // define data structure
    _initData(template){
        // todo ?
        this.const = {};
        this.const.name = template.name;
        this.const.template = template.template;
        this.data = {};
        this.data.type = template.type;
        this.data.key = this._getuuid();
        //公共属性
        this.data.properties = {};
        this.data.style = {};
    }

    _getuuid(){
        return 'xh'+'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            let r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
            return v.toString(16);
        });
    }

    //初始化容器
    _initDom(){
        var divBox = $("<div>").addClass("divBox").addClass("only-selected").attr("id",this.data.key);
        divBox.data("instance", this);
        var deleteBtn = $("<i>").addClass("fa fa-trash-o").attr("aria-hidden",true).addClass("selectTagRemove")
                .css({"position":"absolute","color":"red","right": "10px","top":"5px","font-size":"15px"});
        var dragBtn = $("<i>").addClass("fa fa-arrows").attr("aria-hidden",true).addClass("dragHandle")
                .css({"position":"absolute","font-weight":"bold",'color':'black',"right": "32px","top":"7px","font-size":"15px"});
        deleteBtn.appendTo(divBox);
        dragBtn.appendTo(divBox);
        deleteBtn.click(()=>{
            layer.confirm('确定移除该组件?', function(index){
                $(this).parent().remove();
                layer.close(index);
            });
        });
        this.$self = divBox;
    }

    //加载属性数据
    _loadProperties(data){
        debugger;
        $(boxs.attribute).empty();
        for(var item in data){
            this.data.properties[item] = data[item];
        }
        //last step: mark selected component-key
        $(boxs.attribute).data("key", this.data.key);
    }

    //加载样式数据
    _loadStyles(data){
        for(var item in data){
            this.data.style[item] = data[item];
        }
    }

    /**
     * isInit=true: 标识“组件属性+样式区域”初始化完成
     * isInit=false: 返回是否初始化完成
     */
    _isSelected(isInit){
        if(isInit){
            $(boxs.attribute).data("key", this.data.key);
            return true;
        }else{
            var key = $(boxs.attribute).data("key");
            return this.data.key && key && this.data.key === key;
        }
    }

    /**
     * 初始化properties模板
     * 
     * 参照ownProperties，整合commonProperties中已有的属性
     * 仅添加ownProperties中有的字段
     * ownProperties.key为string时，表示value值，其他内容为默认，copy commonP中的其他内容
     */
    _initOwnPropeties(ownProperties){
        for(var item in ownProperties){
            var property = ownProperties[item],
                commonProperty = commonProperties[item];
            if(typeof property !== 'object'){
                if(typeof commonProperty !== 'object'){
                    throw new Error("property<"+item+"> define uncorrect, please modify template.properties."+item);
                }
                ownProperties[item] = Object.create(commonProperties[item]);
                ownProperties[item].value = property;
            }
            //更新默认值
            this.data.properties[item] = ownProperties[item].value;
        }
        this.const.properties = ownProperties;
    }
    
    /**
     * 设置区域：修改value & 绑定事件
     * tip：先修改值后绑定，避免多次触发事件
     */
    _loadAndBindPropertiesSetting(){
        var myproperties = this.const.properties;
        for(var item in myproperties){
            var property = myproperties[item];
            var $setting = $(property.template).appendTo($(boxs.attribute));
            property.loadSetting && property.loadSetting($setting, this.data.properties[item]);
            property.bindSetting && property.bindSetting($setting, this);
    
        }
    }
    
    //定义属性
    _defineProperties(){
        var _value = {};
        var myproperties = this.const.properties;
        var descriptors = {};
        for(var item in myproperties){
            var property = myproperties[item];
            descriptors[item] = {
                enumerable: true,
                get: (function(p, i){
                    return function(){
                        var result = p.get && p.get instanceof Function
                            && p.get();
                        return result || _value[i];
                    }
                })(property, item),
                set: (function(p, i){
                    return function(){
                        debugger;
                        var result = p.set && p.set instanceof Function
                            && p.set();
                        return result || _value[i];
                        console.log("properties.set =>"+i);
                        console.log("property>",p);
                    }
                })(property, item),
                // set: (function(val){
                //     var result = property.set && property.set instanceof Function
                //         && property.set(value);
                //     _value[item] = result || val;
                //     console.log("properties.set =>"+item);
                //     console.log("property>",property);
                // })()
            }
        }
        Object.defineProperties(this.data.properties, descriptors);
    }

    /**
     * 定义：组件属性, 未启用
     */
    _defineBaseProperties(){
        var that = this,
            _value = {};
        var commonProperties = {
            label: {
                enumerable: true,
                get:function(){
                    return _value.label;
                },
                set: function(val){
                    //attribute dom
                    if(!that._isSelected()){
                        var $label = $(attrTemplates.label);
                        $label.appendTo($(boxs.attribute));
                        $label.find("."+attrPH.label).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.data.properties.label = result;
                        });
                    }
                    //component dom
                    that.$self.find("."+attrPH.label).text(val);
                    _value.label = val;
                }
            },
            desc: {
                enumerable: true,
                get:function(){
                    return _value.desc;
                },
                set: function(val){
                    if(!that._isSelected()){
                        var $desc = $(attrTemplates.desc);
                        $desc.appendTo($(boxs.attribute));
                        $desc.find("."+attrPH.desc).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.data.properties.desc = result;
                        });
                    }
                    that.$self.find("."+attrPH.desc).text(val);
                    _value.desc = val;
                }
            },
            placeholder: {
                enumerable: true,
                get:function(){
                    return _value.placeholder;
                },
                set: function(val){
                    if(!that._isSelected()){
                        var $placeholder = $(attrTemplates.placeholder);
                        $placeholder.appendTo($(boxs.attribute));
                        $placeholder.find("."+attrPH.placeholder).val(val).on("keyup", function(e){
                            var result = $(this).val();
                            that.data.properties.placeholder = result;
                        });
                    }
                    that.$self.find("."+attrPH.placeholder).attr("placeholder",val);
                    _value.placeholder = val;
                }
            },
            disabled:{
                enumerable: true,
                get:function(){
                    return _value.disabled;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isSelected()){
                        var $container = $(boxs.attribute),
                            $disabledSet = $container.find('.'+boxs.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(attrTemplates.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+attrPH.disabled).prop("checked", val).on("click", function(e){
                            var result = $(this).prop("checked");
                            that.data.properties.disabled = result;
                        });
                    }
                    _value.disabled = val;
                }
            },
            readonly:{
                enumerable: true,
                get:function(){
                    return _value.readonly;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isSelected()){
                        var $container = $(boxs.attribute),
                            $disabledSet = $container.find('.'+boxs.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(attrTemplates.disabledSet);
                            $disabledSet.appendTo($container);
                        }
                        $disabledSet.find("."+attrPH.readonly).prop("checked", val).on("click", function(e){
                            var result = $(this).prop("checked");
                            that.data.properties.readonly = result;
                        });
                    }
                    _value.readonly = val;
                }
            },
            required:{
                enumerable: true,
                get:function(){
                    return _value.required;
                },
                set: function(val){
                    //disabled, readOnly, required
                    if(!that._isSelected()){
                        var $container = $(boxs.attribute),
                            $disabledSet = $container.find('.'+boxs.disabledSet);
                        if($disabledSet.length<1){
                            $disabledSet = $(attrTemplates.disabledSet);
                            $disabledSet.appendTo($container);
                        }

                        $disabledSet.find("."+attrPH.required).prop("checked", val).on("click", function(e){
                            console.log("component required clicked!");
                            var result = $(this).prop("checked");
                            that.data.properties.required = result;
                        });
                    }
                    _value.required = val;
                }
            },
        };
        //遍历有效的属性
        for(var item in commonProperties){
            if(commonProperties[item]){
                Object.defineProperty(this.data.properties, item, commonProperties[item]);
            }
        }
    }

    /**
     * 定义：样式字段
     */
    _defineStyles(){
        var myStyle = this.data.style,
            that = this,
            STYLE   = styleMap,
            $STYLE = $(boxs.style),
            _value = {},
            //通用的定义样式的方式
            _defineEachStyle= function(key, comboKey, isUnit){
                return {
                    enumerable: true,
                    get:function(){
                        return _value[key];
                    },
                    set: function(val){
                        _value[key] = val;
                        // 样式表单更新
                        $STYLE.find(styleMap[key][0]).val(val);
                        if(comboKey){
                            //combo值：取值或默认值
                            var comboVal = myStyle[comboKey] || styleMap[comboKey][2];
                            val = isUnit ? (comboVal+val) : (val+comboVal);
                        }
                        that.$self.find("."+compClass.viewBox)[0].style[styleMap[key][1]] = val;
                    }
                }
            },
            commonStyle = {
                textAlign:{
                    enumerable: true,
                    get:function(){
                        return _value.textAlign;
                    },
                    set: function(val){
                        _value.textAlign = val;
                        that.$self.find("."+compClass.viewBox)[0].style.textAlign = val;
                        var $s = $STYLE.find(styleMap.textAlign[0]).find("button[data-value="+val+"]");
                        $s.removeClass('btn-default').addClass('btn-primary');
                        $s.siblings().addClass('btn-default').removeClass('btn-primary');
                    }
                },
                verticalAlign:{
                    enumerable: true,
                    get:function(){
                        return _value.verticalAlign;
                    },
                    set: function(val){
                        _value.textAlign = val;
                        that.$self.find("."+compClass.viewBox)[0].style.verticalAlign = val;
                        var $s = $STYLE.find(styleMap.verticalAlign[0]).find("button[data-value ="+val+"]");
                        $s.removeClass('btn-default').addClass('btn-primary');
                        $s.siblings().addClass('btn-default').removeClass('btn-primary');
                    }
                },
                fontFamily:_defineEachStyle("fontFamily"),
                fontSize:_defineEachStyle("fontSize", "fontSizeUnit", false),
                fontSizeUnit:_defineEachStyle("fontSizeUnit", "fontSize", true),
                textStyle:{
                    enumerable: true,
                    get:function(){
                        return _value.textStyle;
                    },
                    set: function(val){
                        _value.textStyle = val;
                        var viewBox = that.$self.find("."+compClass.viewBox)[0];
                        if(val && val.includes){
                            if(val.includes("bold")){
                                viewBox.style.fontWeight = "bold";
                            }
                            if(val.includes("italic")){
                                viewBox.style.fontStyle = "italic";
                            }
                            if(val.includes("underline")){
                                viewBox.style.textDecoration = "underline";
                            }
                        }
                    }
                },
                fontColor:_defineEachStyle("fontColor"),
                bgColor:_defineEachStyle("bgColor"),
                opacity:_defineEachStyle("opacity"),
                borderStyle:_defineEachStyle("borderStyle"),
                borderWidth:_defineEachStyle("borderWidth", "borderWidthUnit", false),
                borderWidthUnit:_defineEachStyle("borderWidthUnit", "borderWidth", true),
                borderColor:_defineEachStyle("borderColor"),
                borderRadius:_defineEachStyle("borderRadius", "borderRadiusUnit", false),
                borderRadiusUnit:_defineEachStyle("borderRadiusUnit", "borderRadius", true),
                letterSpacing:_defineEachStyle("letterSpacing", "letterSpacingUnit", false),
                letterSpacingUnit:_defineEachStyle("letterSpacingUnit", "letterSpacing", true),
                lineHeight:_defineEachStyle("lineHeight"),
                zIndex:_defineEachStyle("zIndex"),
                overflow:_defineEachStyle("overflow"),
                paddingTop:_defineEachStyle("paddingTop", "paddingTopUnit", false),
                paddingTopUnit:_defineEachStyle("paddingTopUnit", "paddingTop", true),
                paddingBottom:_defineEachStyle("paddingBottom", "paddingBottomUnit", false),
                paddingBottomUnit:_defineEachStyle("paddingBottomUnit", "paddingBottom", true),
                paddingLeft:_defineEachStyle("paddingLeft", "paddingLeftUnit", false),
                paddingLeftUnit:_defineEachStyle("paddingLeftUnit", "paddingLeft", true),
                paddingRight:_defineEachStyle("paddingRight", "paddingRightUnit", false),
                paddingRightUnit:_defineEachStyle("paddingRightUnit", "paddingRight", true),
                marginTop:_defineEachStyle("marginTop", "marginTopUnit", false),
                marginTopUnit:_defineEachStyle("marginTopUnit", "marginTop", true),
                marginBottom:_defineEachStyle("marginBottom", "marginBottomUnit", false),
                marginBottomUnit:_defineEachStyle("marginBottomUnit", "marginBottom", true),
                marginLeft:_defineEachStyle("marginLeft", "marginLeftUnit", false),
                marginLeftUnit:_defineEachStyle("marginLeftUnit", "marginLeft", true),
                marginRight:_defineEachStyle("marginRight", "marginRightUnit", false),
                marginRightUnit:_defineEachStyle("marginRightUnit", "marginRight", true),
            };
        Object.defineProperties(myStyle, commonStyle);
    }

    

    //初始化组件样式的事件
    _bindBaseStyleEvents(){
        var that = this;
        var key = this.data.key;
        // //判断是否已经初始化
        // if($(boxs.attribute).data("isStyleInited")){
        //     return;
        // }
        // $(boxs.attribute).data("isStyleInited", true);

        var $S = $(boxs.style),
            getSelected = function(){
                //var key = $(boxs.attribute).data("key");
                return $("#"+key).data("instance");

            },
            myEvents = function(key){
                $S.find(styleMap[key][0]).unbind("change").change(function(){
                    // var component = getSelected();
                    // if(component){
                    //     component.data.style[key] = $(this).val();
                    // }
                    that.data.style[key] = $(this).val();
                });
            };


        $S.find(styleMap.textAlign[0]).find('button').unbind("click").click(function(){
            var $this = $(this);
            that.data.style.textAlign = $this.attr("data-value");
            $this.removeClass('btn-default').addClass('btn-primary');
            $this.siblings().addClass('btn-default').removeClass('btn-primary');
        });
        $S.find(styleMap.verticalAlign[0]).find('button').unbind("click").click(function(){
            var $this = $(this);
            that.data.style.verticalAlign = $this.attr("data-value");
            $this.removeClass('btn-default').addClass('btn-primary');
            $this.siblings().addClass('btn-default').removeClass('btn-primary')
        });
        myEvents("fontFamily");
        myEvents("fontSize");
        myEvents("fontSizeUnit");
        $S.find(styleMap.textStyle[0]).find('button').unbind("click").click(function(){
            // todo
            //var component = getSelected();
            var result = [];
            $(this).toggleClass("btn-primary").parent().find("btn-primary")
            .each(function(item, index){
                result.push($(this).attr("data-value"));
            });
            that.data.style.textStyle = result;
            // if(component){
            //     component.data.style.textStyle = result;
            // }
        });
        myEvents("fontColor");
        myEvents("bgColor");
        myEvents("opacity");
        myEvents("borderStyle");
        myEvents("borderWidth");
        myEvents("borderWidthUnit");
        myEvents("borderColor");
        myEvents("borderRadius");
        myEvents("borderRadiusUnit");
        myEvents("letterSpacing");
        myEvents("letterSpacingUnit");
        myEvents("lineHeight");
        myEvents("zIndex");
        myEvents("paddingTop");
        myEvents("paddingTopUnit");
        myEvents("paddingBottom");
        myEvents("paddingBottomUnit");
        myEvents("paddingLeft");
        myEvents("paddingLeftUnit");
        myEvents("paddingRight");
        myEvents("paddingRightUnit");
        myEvents("marginTop");
        myEvents("marginTopUnit");
        myEvents("marginBottom");
        myEvents("marginBottomUnit");
        myEvents("marginLeft");
        myEvents("marginLeftUnit");
        myEvents("marginRight");
        myEvents("marginRightUnit");
        myEvents("overflow");
    }

}

export default Component;