/*
 * @Author: lanjian
 * @Date: 2018-06-05 15:07:46
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-05 15:31:56
 * @Content desc: 基础组件基类
 */


import ComponentBase from '../componentBase'

class BaseComBase extends ComponentBase{

    constructor(options){
        super(options);
    }
}

export default BaseComBase;