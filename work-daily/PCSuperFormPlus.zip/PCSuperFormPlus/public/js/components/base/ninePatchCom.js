/*
 * @Author: lanjian
 * @Date: 2018-06-05 16:08:54
 * @Last Modified by: lanjian
 * @Last Modified time: 2018-06-05 18:54:27
  * @Content desc:  九宫格组件
 */

 import BaseComBase from './baseComBase';

 class NinePatchCom extends BaseComBase{
    constructor(options){
        super(options);
        this.selfDomStrObj = null;
        this.init();
    }

    init(){
        this.selfDomStrObj = {
            id: "0",
            type: "nicePatch",
            name: "九宫格",
            icon: "fa-th",
            preview:
                ['<div class="weui-cells">',
                    '<div class="weui-cell">',
                    '<div class="weui-cell__bd">',
                        '<input class="weui-input component_placeholder" type="text" placeholder="请输入文本">',
                    '</div>',
                    '</div>',
                '</div>'].join(''),
            template:
            ['<div class="weui-grids">',
            this._circleStr('<a href="javascript:;" class="weui-grid"><div style="padding:10px;margin:0px;" class="weui-grid-inner"><div class="weui-grid__icon">'+
                '<img src="../../images/timg.jpg" alt="">'+
                '</div><p class="weui-grid__label divBox_next">Grid</p></div></a>', 9),
                '</div>'].join(''),
        };

        this.data.val = {
            type: this.selfDomStrObj.type,
            label: this.selfDomStrObj.name
        }
        this.renerDom();
    }

    renerDom(){
        this.$divContiran.append("<div class='viewBox'>"+this.selfDomStrObj.template+"</div>")
    }

    _circleStr(str, time){
        var result = '';
        for(var i=0; i<time; i++){
            result += str;
        }
        return result;
    }
 }

 export default NinePatchCom;