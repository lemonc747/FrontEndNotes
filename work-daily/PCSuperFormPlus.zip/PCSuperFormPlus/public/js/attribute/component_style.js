/**
 * Created by ASUS on 2018/4/19.
 */
/**
 * 组件样式获取
 * */
var formUtils = require('./temp');
var formSetting = require('./formSetting');

/** 获取水平对齐 */
function getStyleObj(selectObj){
    var selectStyleObj = selectObj.val.styleObj;//组件样式对象
    var viewStyleObj = selectObj.val.viewStyleObj;//预览时用的带单位样式
    var selectJqAll = $('#'+selectObj.jqObjID);
    var selectJq=selectJqAll.find(".viewBox");
    $('#component_style .textAlign').find('button').unbind("click").click(function(){
        var textAlign = $(this).data('value');
        $(this).removeClass('btn-default').addClass('btn-primary').siblings().removeClass('btn-primary');
        selectStyleObj["text-align"]=textAlign;
        addStyle(selectJq,selectStyleObj);
    });
    /** 获取垂直对齐 */
    $("#component_style .verticalAlign").find('button').unbind("click").click(function(){
        var verticalAlign = $(this).data('value');
        $(this).removeClass('btn-default').addClass('btn-primary').siblings().removeClass('btn-primary');
        selectStyleObj["vertical-align"]=verticalAlign;
        addStyle(selectJq,selectStyleObj);
    });
    /** 获取字体 */
    $("#component_style .fontFamily").unbind("change").change(function(){
        var fontFamily = $('.fontFamily option:selected').val();
        selectStyleObj["font-family"]=fontFamily;
        addStyle(selectJq,selectStyleObj);
    });
    /** 获取字体大小和单位 */
    getValueUnit(".fontSize",".fontSizeUnit","font-size");
    /** 获取字体风格 */
    $("#component_style .textStyle").find('button').unbind("click").click(function(){
        if($(this).hasClass('btn-default')){
            $(this).removeClass('btn-default').addClass('btn-primary');
            if($(this).index()==0){
                var fontWeight=$(this).data('value');
                selectStyleObj["font-weight"]=fontWeight;
                addStyle(selectJq,selectStyleObj);
            }else if($(this).index()==1){
                var fontStyle=$(this).data('value');
                selectStyleObj["font-style"]=fontStyle;
                addStyle(selectJq,selectStyleObj);
            }else if($(this).index()==2){
                var textDecoration=$(this).data('value');
                selectStyleObj["text-decoration"]=textDecoration;
                addStyle(selectJq,selectStyleObj);
            }
        }else{//取消选中状态,删除数据,移除样式
            $(this).removeClass('btn-primary').addClass('btn-default');
            if($(this).index()==0){
                delete selectStyleObj["font-weight"];
                selectJq.css("font-weight","")
            }else if($(this).index()==1){
                delete selectStyleObj["font-style"];
                selectJq.css("font-weight","")
            }else if($(this).index()==2){
                delete selectStyleObj["text-decoration"];
                selectJq.css("font-weight","")
            }
        }
        
    });
    /** 获取字体颜色*/
    getColorpickerValue("#style_font_color","color");
    /** 获取背景颜色*/
    getColorpickerValue("#style_bg_color","background-color");
    /** 背景图片 */
    $("#component_style .showImageName").unbind("change").change(function(){
        var bgUrl = $(this).val();
        selectStyleObj["background-image"]="url("+bgUrl+")";
        addStyle(selectJq,selectStyleObj);
    });
    /** 透明度和单位 */
    $("#component_style .opacity").unbind("change").change(function(){
        var opacity = $(this).val();
        selectStyleObj["opacity"]=opacity;
        addStyle(selectJq,selectStyleObj);
    });
    /** 获取边框样式 */
    $("#component_style .borderStyle").unbind("change").change(function(){
        var borderStyle = $('.borderStyle option:selected').val();
        selectStyleObj["border-style"]=borderStyle;
        addStyle(selectJq,selectStyleObj);
    });
    /** 边框宽度和单位 */
    getValueUnit(".borderWidth",".borderWidthUnit","border-width");
    /** 获取边框颜色*/
    getColorpickerValue("#style_border_color","border-color");
    /** 边框圆角和单位 */
    getValueUnit(".borderRadius",".borderRadiusUnit","border-radius");
    /** 字间距和单位 */
    getValueUnit(".letterSpacing",".letterSpacingUnit","letter-spacing");
    /** 字行高和单位 */
    getValueUnit(".lineHeight",".lineHeightUnit","line-height");
    /** 层级 */
    $("#component_style .zIndex").unbind("change").change(function(){
        var zIndex = $(this).val();
        selectStyleObj["z-index"]=zIndex;
        addStyle(selectJq,selectStyleObj);
    });
    /** 上内边距和单位 */
    getValueUnit(".paddingTop",".paddingTopUnit","padding-top");
    /** 下内边距和单位 */
    getValueUnit(".paddingBottom",".paddingBottomUnit","padding-bottom");
    /** 左内边距和单位 */
    getValueUnit(".paddingLeft",".paddingLeftUnit","padding-left");
    /** 右内边距和单位 */
    getValueUnit(".paddingRight",".paddingRightUnit","padding-right");
    /** 上外边距和单位 */
    getValueUnit(".marginTop",".marginTopUnit","margin-top");
    /** 下外边距和单位 */
    getValueUnit(".marginBottom",".marginBottomUnit","margin-bottom");
    /** 左外边距和单位 */
    getValueUnit(".marginLeft",".marginLeftUnit","margin-left");
    /** 右外边距和单位 */
    getValueUnit(".marginRight",".marginRightUnit","margin-right");
    /** 超过范围 */
    $("#component_style .overflow").unbind("change").change(function(){
        var overflow = $('.overflow option:selected').val();
        selectStyleObj["overflow"]=overflow;
        selectJqAll.css(selectStyleObj);
    });
    /** 用来获取颜色拾取器的值得方法 */
    function getColorpickerValue(obj,key){//input框父元素的id选择器;selectStyleObj的属性名;
        $(obj).find('input').unbind("change").change(function(){
            var styleColor = $(this).val();
            console.log(selectStyleObj);
            selectStyleObj[key]=styleColor;
            addStyle(selectJq,key,styleColor);
        });
    }
    /** 用来获取数值+单位的方法 */
    function getValueUnit(first,second,key){//第一个框的class选择器;第一个框的class选择器;selectStyleObj的属性名;
        $("#component_style "+first).unbind("change").change(function(){
            var style_unit =$('#component_style '+ second).val();//单位
            var style_value = $(this).val();
            selectStyleObj[key]=[style_value,style_unit];
            addStyle(selectJq,key,style_value+style_unit);
            viewStyleObj[key] =style_value+style_unit;
        });
        $("#component_style "+second).unbind("change").change(function(){
            var style_unit =$(this).val();//单位
            var style_value =$('#component_style '+first).val();
            selectStyleObj[key]=[style_value,style_unit];
            addStyle(selectJq,key,style_value+style_unit);
            viewStyleObj[key] =style_value+style_unit;
        });
    }
}
function addStyle(obj,styleObj,styleObjUnit){//选中的对象;选中对象的样式;单位(有就写没有就不写)
    if(!styleObjUnit){
        obj.css(styleObj);
    }
    if(!!styleObjUnit){
        obj.css(styleObj,styleObjUnit)
    }
}


module.exports = {
    getStyleObj:    getStyleObj,
    addStyle:       addStyle
}
