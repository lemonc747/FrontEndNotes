var global = require('../utils/global');
var common = require('../utils/common');
var template = require('../component/template');
var style = require('../attribute/component_style')

/**第一次创建(点击表单项创建的控件) */
function assembleSettingMeun(whichComponent){
    var formTepComArr = global.getData('formTepComArr'),
        currentComJqID = global.getData('currentComJqID'),
        currentComJq = $("#"+currentComJqID);
    console.log("formTepComArr",formTepComArr);
    var styleObj={};//用来存储样式
    //控件所有的属性
    var data = {};
    //每个控件生成唯一的uuid
    var key = common.guid();
    var currentSettingObj = {};
    currentSettingObj.key = key;
    currentSettingObj.val = data;
    currentSettingObj.val.typeNum = whichComponent;
    currentSettingObj.itemId = whichComponent;
    currentSettingObj.jqObjID = currentComJqID;
    currentSettingObj.val.styleObj=styleObj;
    currentSettingObj.val.viewStyleObj={};//预览时带单位的样式
    
    currentComJq.data("key",key);

    SettingMeun(currentSettingObj, whichComponent);
    //去除其他选中,添加自己选中
    cancelAllSelect();
    addSelect(currentComJq);
    //更新数据: 组件数组，当前选中组件
    formTepComArr.push(currentSettingObj);
    global.setSelectedIndex(formTepComArr.length-1);
    global.setData('formTepComArr', formTepComArr);
}

/**点击已经创建好了的控件 */
function clickHaveSelectCom(selected){
    SettingMeun(selected, selected.val.typeNum);
    //更新数据
    global.setSelected(selected);
}

/**组装表单设置项
 * 根据不同的控件显示相应的表单项控制
 */
function SettingMeun(data, whichComponent){
    $("#component_attr_box").html("");
    switch(whichComponent){
        case template.SIMPLEINPUT:
            data.val.type = "SIMPLEINPUT";
            componentNameSet(data);
            componentDescSet(data);
            componentInputTipSet(data);
            componentDisabledSet(data);
            componentNameSetRange(data);
            break;
        case template.TEXTAREA:
            data.val.type = "TEXTAREA";
            componentNameSet(data);
            componentDescSet(data);
            componentInputTipSet(data);
            componentDisabledSet(data);
            componentNameSetRange(data);
            break;
        case template.RADIO:
            data.val.type = "RADIO";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentOptionRadioSet(data);
            break;
        case template.CHECKBOX:
            data.val.type = "CHECKBOX";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentOptionChecKBoxSet(data);
            break;
        case template.SELECT:
            data.val.type = "SELECT";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentOptionRadioSet(data);
            break;
        case template.NUMBER:
            data.val.type = "NUMBER";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentNameSetRange(data);
            componentSplitNumberSetRange(data);
            break;
        case template.DATE:
            data.val.type = "DATE";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentCalendarStyle(data);
            componentNameDateSetRange(data);
            break;
        case template.SWITCH:
            data.val.type = "SWITCH";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentLinkText(data);
            componentLink(data);
            componentContentText(data);
            break;
        case template.CASCADER:
            data.val.type = "CASCADER";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            break;
        case template.TEXT:
            data.val.type = "TEXT";
            componentNameSet(data);
            componentDescSet(data);
            break;
        case template.SCORE:
            data.val.type = "SCORE";
            componentNameSet(data);
            componentDescSet(data);
            componentDisabledSet(data);
            componentScoreSetRange(data);
            break;
        case template.SPLITLINE:
            data.val.type = "SPLITLINE";
            componentSplitLineSetRange(data);
            break;
        case template.GRID:
            data.val.type = 'GRID';
            componentGridType(data);
            gridIconOff(data);
            gridStyleOff(data);
            styleContent(data);
            gridContent(data);
            break;
        case template.FLEX:
            data.val.type = 'FLEX';
            flexItem(data);
            break;
        case template.TABBAR:
            data.val.type = 'TABBAR';
            tabDirection(data);
            tabContent(data);
            break;
        case template.NAVBAR:
            data.val.type = 'NAVBAR';
            navStyle(data);
            navContent(data);
            break;
        case template.ICON:
            data.val.type = 'ICON';
            iconSetting(data);
            break;
        default:
            break;
    }
}

/**表单项名称设置 */
function componentNameSet(currentSettingObj){//每个控件的数据
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12" style="margin-top: 10px">'+
        '<label class="col-md-12 control-label">表单项名称</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control comName" placeholder="请输入表单项名称">'+
        '</div>'+
    '</div>');
    if(!data.label)
        defaultLabel(data);
    jqObj.find("input").val(data.label);
    jqObj.find("input").change(function(e){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            defaultLabel(currentSettingObj.val);
            result =currentSettingObj.val.label;//等于默认label
        }
        currentSettingObj.val.label = result;
        $("#"+currentSettingObj.jqObjID).find(".component_Name").text(result);
        global.setSelected(currentSettingObj);
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**表单项描述设置 */
function componentDescSet(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12">'+
            '<label class="col-md-12 control-label">表单项描述</label>'+
            '<div class="col-md-12">'+
                '<input type="text" class="form-control comDesc" placeholder="请输入对表单项的描述">'+
            '</div>'+
        '</div>');
    if(!data.decs)
        data.decs = "请设置对表单的描述";
    jqObj.find("input").val(data.decs);

    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            result ="请设置对表单的描述";//等于默认描述
        }
        currentSettingObj.val.decs = result;
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**表单项输入提示设置 */
function componentInputTipSet(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12">'+
                '<label class="col-md-12 control-label">表单项输入提示</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control comPlaceholder" placeholder="请输入提示语">'+
                '</div>'+
            '</div>');
    if(!data.placeholder)
        data.placeholder = '请输入提示语';
    jqObj.find("input").val(data.placeholder);
    jqObj.find("input").change(function(e){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            result = '请输入提示语';//等于默认placeholder
        }
        currentSettingObj.val.placeholder = result;
        $("#"+currentSettingObj.jqObjID).find(".component_inputTip").attr("placeholder",result);
        global.setSelected(currentSettingObj);
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**表单项控制 */
function componentDisabledSet(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj= $('<div class="form-group col-md-12">'+
                 '<label class="col-md-12 control-label">表单项控制</label>'+
                 '<div class="col-md-12">' +
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox" class="comDisabled"> 禁用'+
                         '</label>'+
                     '</div>'+
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox" class="comReadOnly"> 只读'+
                         '</label>'+
                     '</div>'+
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox" class="comRequired"> 必填'+
                         '</label>'+
                     '</div>'+
                 '</div>'+
             '</div>');
    if(!data.disable)
        data.disable = false;
    if(!data.readonly)
        data.readonly = false;
    if(!data.required)
        data.required = false;

    //根据currentSettingObj.val.disable的状态来设置checked属性或移除checked属性
    if(data.disable){
        $(jqObj.find("input")[0]).prop('checked','checked');
    }else{
        $(jqObj.find("input")[0]).removeProp('checked');
    }
    if(data.readonly){
        $(jqObj.find("input")[1]).prop('checked','checked');
    }else{
        $(jqObj.find("input")[1]).removeProp('checked');
    }
    if(currentSettingObj.val.required){
        $(jqObj.find("input")[2]).prop('checked','checked');
    }else{
        $(jqObj.find("input")[2]).removeProp('checked');
    }
    $(jqObj.find("input")[0]).change(function(){
        var currentSettingObj = global.getSelected();
        currentSettingObj.val.disable = $(this).prop('checked');
        global.setSelected(currentSettingObj);
    });
    $(jqObj.find("input")[1]).change(function(){
        var currentSettingObj = global.getSelected();
        currentSettingObj.val.readonly = $(this).prop('checked');
        global.setSelected(currentSettingObj);
    });
    $(jqObj.find("input")[2]).change(function(){
        var currentSettingObj = global.getSelected();
        currentSettingObj.val.required = $(this).prop('checked');
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**单行多行输入--表单项范围 */
function componentNameSetRange(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12">'+
                  '<label class="col-md-12 control-label">表单项范围</label>'+
                  '<div class="col-md-12">'+
                      '<p>最小字符数</p>'+
                      '<input type="number" class="form-control minNumber" placeholder="请输入数字">'+
                  '</div>'+
                  '<div class="col-md-12" style="margin-top: 10px">'+
                      '<p>最大字符数</p>'+
                      '<input type="number" class="form-control maxNumber" placeholder="请输入数字">'+
                  '</div>'+
              '</div>');
    if(!data.minnumber)
        data.minnumber=0;
    jqObj.find("input.minNumber").val(data.minnumber);
    if(!data.maxnumber)
        data.maxnumber=200;
    jqObj.find("input.maxnumber").val(data.maxnumber);

    jqObj.find("input.minNumber").change(function(e){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            result = 0;//等于默认minnumber
        }
        //最少字符数
        currentSettingObj.val.minnumber = result;
        global.setSelected(currentSettingObj);
    });
    jqObj.find("input.maxNumber").change(function(e){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            result = 200;//等于默认maxnumber
            console.log(result)
        }
        //最多字符数
        currentSettingObj.val.maxnumber = result;
        $("#"+currentSettingObj.jqObjID).find(".weui-textarea-counter span").eq(1).text(result);
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**添加option选项 单选*/
function createOptionRidaoItem(currentSettingObj, notCreateData,index){
    var data = currentSettingObj.val;
    var id = new Date().getTime();
    var optionItem = '<div class="weui-cell addradiobox col-md-12">' +
                        '<label for="iAgree1'+id+'">'+
                            '<input id= "iAgree1'+id+'" class="checkList" type="radio" name="radio1">'+
                        '</label>'+
                        '<div class="col-md-9" style="background-color:#fff">'+
                            '<input class="form-control valueList" type="text" placeholder="选项">'+
                        '</div>'+
                        '<label class="col-md-3">'+
                            '<span class="text-center optionsAddBox" style="display: inline-block;width:50%;background:#ccc">+ </span>'+
                            '<span class="text-center optionsRemoveBox" style="display: inline-block;width:50%;background:#ccc"> -</span>'+
                        '</label>'+
                    '</div>';
    var item = $("<div>").html(optionItem).children().data("id",id);
    if(!!notCreateData){
        $(item.find(".valueList")).val(currentSettingObj.val.options[index].value);
        $(item.find(".checkList")).prop("checked",currentSettingObj.val.options[index].selected);
    }else{
        //数据
        var obj = {};
        obj.id = id;
        obj.value = "选项";
        obj.selected = false;
        currentSettingObj.val.options.push(obj);
    }

    item.find(".optionsAddBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        console.log(item.parent().prop("class"));
        var currentSettingObj = global.getSelected();
        var newItem = createOptionRidaoItem(currentSettingObj);
        item.parent().append(newItem);

        //动态改变展示区单选项数量
        var iid = new Date().getTime();
        var radioHtml=$("#"+currentSettingObj.jqObjID).find(".weui-cells_radio").html();
        //console.log(startHtml);
        radioHtml += '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x11'+iid+'">'+
            '<div class="weui-cell__bd">'+
            '<p>选项</p>'+
            '</div>'+
            '<div class="weui-cell__ft">'+
            '<input type="radio" class="weui-check" name="radio1" id="x11'+iid+'" disabled>'+
            '<span class="weui-icon-checked"></span>'+
            '</div>'+
            '</label>';
        //console.log(radioHtml);
        $("#"+currentSettingObj.jqObjID).find(".weui-cells_radio").html(radioHtml);
    });
    item.find(".optionsRemoveBox").click(function(e){
        var index2=$(this).parent().parent(".addradiobox").index()-1;
        var currentSettingObj = global.getSelected();
        console.log(index2);
        var radiolength=$(".addradiobox").length;
        if(radiolength>1) {
            var item = $(this).parents(".addradiobox");
            var id = $(this).parents(".addradiobox").data("id");
            console.log("id", id);
            var tempArr = [];
            for (var i = 0; i < currentSettingObj.val.options.length; i++) {
                if (currentSettingObj.val.options[i].id != id) {
                    tempArr.push(currentSettingObj.val.options[i]);
                }
            }
            currentSettingObj.val.options = tempArr;
            item.remove();

            //动态改变展示区单选项数量
            var labelindex = $("#"+currentSettingObj.jqObjID).find(".weui-cells_radio label").eq(index2);
            console.log(labelindex);
            labelindex.remove();
        }
        global.setSelected(currentSettingObj);
    });
    $(item.find("input")[0]).change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var id = $(this).parents(".addradiobox").data("id");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].selected = $(this).is(":checked");
            }
        }
        global.setSelected(currentSettingObj);
    });
    $(item.find("input")[1]).change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var index = $(this).parent().parent(".addradiobox").index()-1;
        console.log(index);
        var isChecked = $(item.find("input")[0]).is(":checked");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].value = result;
            }
        }
        $("#"+currentSettingObj.jqObjID).find(".weui-cells_radio label p").eq(index).text(result);
        global.setSelected(currentSettingObj);
    });
    return item;
}
/**单选框--表单项范围 */
//表单项单选框option数组数据
function componentOptionRadioSet(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12">'+
                  '<h4 class="col-md-12 control-label">表单项范围</h4>'+
              '</div>');
    if(!!data.options){
        var tempArrT = [];
        console.log(data.options)
        for(var i= 0; i< data.options.length ; i++){
            tempArrT.push(data.options[i]);

        }
        for(var i= 0; i< tempArrT.length ; i++){
            var item = createOptionRidaoItem(currentSettingObj, true,i);
            item.appendTo(jqObj);
        }
    }else{
        data.options = [];
        var item = createOptionRidaoItem(currentSettingObj);
        item.appendTo(jqObj);
    }
    //默认
    jqObj.appendTo($("#component_attr_box"));
}
/**添加option选项 复选框*/
function createOptionCheckBoxItem(currentSettingObj, notCreateData,index){
    var id = new Date().getTime();
    var optionItem = '<div class="weui-cell addradiobox col-md-12">' +
                         '<label for="iAgree1'+id+'">'+
                             '<input id= "iAgree1'+id+'" class="checkList" type="checkbox">'+
                         '</label>'+
                         '<div class="col-md-9" style="background-color:#fff">'+
                             '<input class="form-control valueList" type="text" placeholder="选项">'+
                         '</div>'+
                         '<label class="col-md-3">'+
                             '<span class="text-center optionsAddBox" style="display: inline-block;width:50%;background:#ccc">+ </span>'+
                             '<span class="text-center optionsRemoveBox" style="display: inline-block;width:50%;background:#ccc"> -</span>'+
                         '</label>'+
                     '</div>';
    var item = $("<div>").html(optionItem).children().data("id",id);
    //数据
    if(!!notCreateData){
        $(item.find(".valueList")).val(currentSettingObj.val.options[index].value);
        $(item.find(".checkList")).prop("checked",currentSettingObj.val.options[index].selected);
    }else{
        var obj = {};
        obj.id = id;
        obj.value = "选项";
        obj.selected = false;
        currentSettingObj.val.options.push(obj);
    }
    item.find(".optionsAddBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        console.log(item.parent().prop("class"));
        var currentSettingObj = global.getSelected();
        var newItem = createOptionCheckBoxItem(currentSettingObj);
        item.parent().append(newItem);
        //动态改变展示区单选项数量
        var iid = new Date().getTime();
        var checkBoxHtml=$("#"+currentSettingObj.jqObjID).find(".weui-cells_checkbox").html();
        //console.log(startHtml);
        checkBoxHtml +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s11'+iid+'">'+
            '<div class="weui-cell__hd">'+
            '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+iid+'" disabled>'+
            '<i class="weui-icon-checked"></i>'+
            '</div>'+
            '<div class="weui-cell__bd">'+
            '<p>选项</p>'+
            '</div>'+
            '</label>';
        //console.log(radioHtml);
        $("#"+currentSettingObj.jqObjID).find(".weui-cells_checkbox").html(checkBoxHtml);
        global.setSelected(currentSettingObj);
    });
    item.find(".optionsRemoveBox").click(function(e){
        var currentSettingObj = global.getSelected();
        var index2=$(this).parent().parent(".addradiobox").index()-1;
        console.log(index2);
        var checkboxlength=$(".addradiobox").length;
        if(checkboxlength>1) {
            var item = $(this).parents(".addradiobox");
            var id = $(this).parents(".addradiobox").data("id");
            console.log("id", id);
            var tempArr = [];
            for (var i = 0; i < currentSettingObj.val.options.length; i++) {
                if (currentSettingObj.val.options[i].id != id) {
                    tempArr.push(currentSettingObj.val.options[i]);
                }
            }
            currentSettingObj.val.options = tempArr;
            item.remove();
        }
        item.remove();
        //动态改变展示区单选项数量
        var labelindex = $("#"+currentSettingObj.jqObjID).find(".weui-cells_checkbox label").eq(index2);
        console.log(labelindex);
        labelindex.remove();
        global.setSelected(currentSettingObj);
    });
    $(item.find("input")[0]).change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var id = $(this).parents(".addradiobox").data("id");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].selected = $(this).is(":checked");
            }
        }
        global.setSelected(currentSettingObj);
    });
    $(item.find("input")[1]).change(function(){
        var currentSettingObj = global.getSelected();
        var index=$(this).parent().parent(".addradiobox").index()-1;
        var result = $(this).val();
        var isChecked = $(item.find("input")[0]).is(":checked");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].value = result;
            }
        }
        $("#"+currentSettingObj.jqObjID).find(".weui-cells_checkbox label p").eq(index).text(result);
        global.setSelected(currentSettingObj);
    });
    return item;
}
/**复选框--表单项范围 */
//表单项复选框option数组数据
function componentOptionChecKBoxSet(currentSettingObj){
    var jqObj = $('<div class="form-group col-md-12">'+
                  '<h4 class="col-md-12 control-label">表单项范围</h4>'+
              '</div>');
    if(!!currentSettingObj.val.options){
        var tempArrT = [];
        console.log(currentSettingObj.val.options)
        for(var i= 0; i< currentSettingObj.val.options.length ; i++){
            tempArrT.push(currentSettingObj.val.options[i]);

        }
        for(var i= 0; i< tempArrT.length ; i++){
            var item = createOptionCheckBoxItem(currentSettingObj, true,i);
            item.appendTo(jqObj);
        }
    }else{
        currentSettingObj.val.options = [];
        var item = createOptionCheckBoxItem(currentSettingObj);
        item.appendTo(jqObj);
    }
    //默认
    jqObj.appendTo($("#component_attr_box"));
}
/**数字类型--表单项范围*/
function componentSplitNumberSetRange(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12">'+
                    '<label class="col-md-12 control-label">数字类型</label>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option value="电话号码">电话号码</option>'+
                            '<option value="邮政编码">邮政编码</option>'+
                            '<option value="身份证号码">身份证号码</option>'+
                            '<option value="条码">条码</option>'+
                        '</select>'+
                    '</div>'+
                '</div>');
    if(!data.numbertype)
        data.numbertype = "电话号码";
    jqObj.find("select").val(data.numbertype);

    jqObj.find("select").change(function(e){
        var result = $(this).val();
        //数字类型
        currentSettingObj.val.numbertype = result;
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**时间日期--表单项范围*/
function componentNameDateSetRange(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12">'+
                  '<label class="col-md-12 control-label">时间/日期格式</label>'+
                  '<div class="col-md-12">'+
                      '<select class="form-control">' +
                          '<option value="年-月-日-时" selected>年-月-日-时</option>'+
                          '<option value="年-月-日">年-月-日</option>'+
                          '<option value="年-月">年-月</option>'+
                          '<option value="月-日">月-日</option>'+
                      '</select>'+
                  '</div>'+
            '</div>');
    //默认
    if(!data.datatimeformat){
        currentSettingObj.val.datatimeformat = "yyyy-MM-dd hh:mm:ss";
    }
    if(data.datatimeformat == "yyyy-MM-dd hh:mm:ss"){
        jqObj.find("select").val("年-月-日-时");
    }
    if(data.datatimeformat == "yyyy-MM-dd"){
        jqObj.find("select").val("年-月-日");
    }
    if(data.datatimeformat == "yyyy-MM"){
        jqObj.find("select").val("年-月");
    }
    if(data.datatimeformat == "MM-dd"){
        jqObj.find("select").val("月-日");
    }

    jqObj.find("select").change(function(e){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        if(result == "年-月-日-时"){
            currentSettingObj.val.datatimeformat = "yyyy-MM-dd hh:mm:ss";
        }
        if(result == "年-月-日"){
            currentSettingObj.val.datatimeformat = "yyyy-MM-dd";
        }
        if(result == "年-月"){
            currentSettingObj.val.datatimeformat = "yyyy-MM";
        }
        if(result == "月-日"){
            currentSettingObj.val.datatimeformat = "MM-dd";
        }
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**日期选择样式  日历*/
function componentCalendarStyle(currentSettingObj){
    var jqObj = $('<div class="form-group col-md-12">' +
                  '<label class="col-md-12 control-label">是否日历样式</label>'+
                  '<div class="col-md-12">' +
                      '<input id="weuiAgree222" type="checkbox" checked>'+
                      '<span style="color: #999">'+
                      '   日历样式'+
                      '</span>'+
                  '</div>'+
              '</div>');
    //默认值
    currentSettingObj.val.isCalendar = true;
    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected();
        console.log($(this).prop('checked'));
        currentSettingObj.val.isCalendar = $(this).prop('checked');
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**评分--表单项范围 */
function componentScoreSetRange(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj =  $('<div class="form-group col-md-12">'+
            '<label class="col-md-12 control-label">表单项范围</label>'+
            '<div class="col-md-12">评分尺度：</div>'+
            '<div class="col-md-12">'+
                '<select class="form-control select_scare1">' +
                    '<option value="5星" selected>5星</option>'+
                    '<option value="10星">10星</option>'+
                '</select>'+
            '</div>'+
            '<div class="col-md-12">默认评分：</div>'+
            '<div class="col-md-12">'+
                '<select class="form-control select_scare2">' +
                    '<option value="0星">0星</option>'+
                    '<option value="1星">1星</option>'+
                    '<option value="2星">2星</option>'+
                    '<option value="3星" selected>3星</option>'+
                    '<option value="4星">4星</option>'+
                    '<option value="5星">5星</option>'+
                    '<option value="6星">6星</option>'+
                    '<option value="7星">7星</option>'+
                    '<option value="8星">8星</option>'+
                    '<option value="9星">9星</option>'+
                    '<option value="10星">10星</option>'+
                '</select>'+
            '</div>'+
        '</div>');
    //默认评分
    if(!data.defaultscore)
        currentSettingObj.val.defaultscore = 3;
    jqObj.find(".select_scare2").val(data.defaultscore + "星");
    if(!data.gradingscale)
        currentSettingObj.val.gradingscale = 5;
    jqObj.find(".select_scare1").val(data.gradingscale + "星");

    jqObj.find(".select_scare1").change(function(e){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        result=result.split("星")[0];
        //评分尺度
        currentSettingObj.val.gradingscale = result;
        //动态改变展示区星星个数
        var startHtml='<span class="fa fa-star-o starScore"></span>';
        $("#"+currentSettingObj.jqObjID).find(".star_num").html("");
        //console.log(startHtml);
        for(var i = 1 ; i < result; i++){
            startHtml += ' <span class="fa fa-star-o starScore"></span>';
        }
        $("#"+currentSettingObj.jqObjID).find(".star_num").html(startHtml);
        global.setSelected(currentSettingObj);
    });
    jqObj.find(".select_scare2").change(function(e){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        result=result.split("星")[0];
        //默认评分
        currentSettingObj.val.defaultscore = result;
        for(var i = 0 ; i < result; i++){
            $(".star_num .starScore").eq(i).removeClass("fa-star-o").addClass("fa-star")
        }
        global.setSelected(currentSettingObj);
    });
    $(jqObj.find("input")[2]).change(function(){
        var currentSettingObj = global.getSelected();
        console.log($(this).prop('checked'));
        currentSettingObj.val.support = $(this).prop('checked');
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**分割线--表单项范围*/
function componentSplitLineSetRange(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj =  $('<div class="form-group col-md-12" style="margin-top: 10px">'+
        '<label class="col-md-12 control-label">分割线样式</label>'+
        '<div class="col-md-12">'+
            '<select class="form-control">' +
                '<option value="实线">实线</option>'+
                '<option value="虚线">虚线</option>'+
                '<option value="点线">点线</option>'+
            '</select>'+
        '</div>'+
    '</div>');
    //默认值为实线
    if(!data.splitline){
        currentSettingObj.val.splitline = "solid";
    }
    if(data.splitline == "solid"){
        jqObj.find("select").val("实线")
    }
    if(data.splitline == "dashed"){
        jqObj.find("select").val("虚线")
    }
    if(data.splitline == "dotted"){
        jqObj.find("select").val("点线")
    }

    jqObj.find("select").change(function(e){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        if (result=="实线"){
            result = "solid";
        }else if(result=="虚线"){
            result = "dashed";
        }
        else if(result=="点线"){
            result = "dotted";
        }
        //分割线样式
        currentSettingObj.val.splitline = result;
        global.setSelected(currentSettingObj);
    });

    jqObj.appendTo($("#component_attr_box"));
}

/**链接文字 */
function componentLinkText(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12">'+
        '<label class="col-md-12 control-label">链接文本</label>'+
        '<div class="col-md-12">'+
            '<input type="text" class="form-control comDesc" placeholder="请输入链接文本">'+
        '</div>'+
    '</div>');
    if(!data.linkText)
        currentSettingObj.val.linkText = "请输入链接文本";
    jqObj.find(".comDesc").val(data.linkText);
    
    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        if(result == "" || !result){
            result ="请输入链接文本";//等于默认描述
        }
        currentSettingObj.val.linkText = result;
        $("#"+currentSettingObj.jqObjID).find(".linkText_linkContent").text(result);
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}

/**链接 */
function componentLink(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12">'+
    '<label class="col-md-12 control-label">链接</label>'+
    '<div class="col-md-12">'+
        '<input type="text" class="form-control comDesc" placeholder="请输入链接">'+
    '</div>'+
    '</div>');
    if(!data.decs)
        currentSettingObj.val.linkUrl = "请输入链接";
    jqObj.find("input").val(data.linkUrl);
    
    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        if(result == "" || !result){
            result ="请输入链接";//等于默认描述
        }
        currentSettingObj.val.linkUrl = result;
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}

/** 勾选框文本 */
function componentContentText(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj=$('<div class="form-group col-md-12">'+
    '<label class="col-md-12 control-label">勾选框文本</label>'+
    '<div class="col-md-12">'+
        '<input type="text" class="form-control comDesc" placeholder="请输入勾选框文本">'+
    '</div>'+
    '</div>');
    if(!!data.contentText)
        currentSettingObj.val.contentText = "请输入链接";
    jqObj.find("input").val(data.contentText);
    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        if(result == "" || !result){
            result ="请输入链接";//等于默认描述
        }
        currentSettingObj.val.contentText = result;
        $("#"+currentSettingObj.jqObjID).find(".contentText_Name").text(result);
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}


/** 设置默认label */
function defaultLabel(currentSettingObjVal){
    if(currentSettingObjVal.typeNum == 0){
        currentSettingObjVal.label = '文本框';
    }else if(currentSettingObjVal.typeNum == 1){
        currentSettingObjVal.label = '文本域';
    }else if(currentSettingObjVal.typeNum == 2){
        currentSettingObjVal.label = '单选框';
    }else if(currentSettingObjVal.typeNum == 3){
        currentSettingObjVal.label = '多选框';
    }else if(currentSettingObjVal.typeNum == 4){
        currentSettingObjVal.label = '下拉框';
    }else if(currentSettingObjVal.typeNum == 5){
        currentSettingObjVal.label = '数字框';
    }else if(currentSettingObjVal.typeNum == 6){
        currentSettingObjVal.label = '时间日期';
    }else if(currentSettingObjVal.typeNum == 7){
        currentSettingObjVal.label = '勾选框';
    }else if(currentSettingObjVal.typeNum == 8){
        currentSettingObjVal.label = '地区级联';
    }else if(currentSettingObjVal.typeNum == 9){
        currentSettingObjVal.label = '文本栏';
    }else if(currentSettingObjVal.typeNum == 10){
        currentSettingObjVal.label = '评分';
    }else if(currentSettingObjVal.typeNum == 11){
        //currentSettingObj.val.label = '分割线'; ??
    }
}


// /**取消选中框效果 */
// function cancelSelect(comJq){
//     comJq.css({"border":"0px dashed yellow","position":"relative"});
//     comJq.find(".selectTagRemove").hide();
//     comJq.find(".dragHandle").hide();
// }

/**取消所有的选中 */
function cancelAllSelect(){
    var formTepComArr = global.getData('formTepComArr');
    for(var i = 0; i < formTepComArr.length; i++){
        var comJq = $("#"+formTepComArr[i].jqObjID);
        comJq.css({"border":"0px dashed yellow","position":"relative"});
        comJq.find(".selectTagRemove").hide();
        comJq.find(".dragHandle").hide();
    }
    global.getData('formTepComArr', formTepComArr);
}

/**添加选中框效果 */
function addSelect(comJq){
    comJq.css({"border":"1px dashed black","position":"relative"});
    comJq.find(".selectTagRemove").show();
    comJq.find(".dragHandle").show();
    $("#sidebar-nav-tabs2").find('li').eq(0).addClass("active").siblings().removeClass("active");
    $("#component_attr").addClass("active").siblings().removeClass("active");
}


/** 九宫格 */
//宫格类型
function componentGridType(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12 gridType" style="margin-top: 10px">'+
        '<label class="col-md-12 control-label">宫格类型</label>'+
        '<div class="col-md-12">'+
        '<select class="form-control">' +
        '<option value="1" selected>九宫格</option>'+
        '<option value="2">四宫格</option>'+
        '<option value="3">二宫格</option>'+
        '<option value="4">一宫格</option>'+
        '</select>'+
        '</div>'+
        '</div>');
    if(!data.gridType)
        data.gridType = 1;
    jqObj.find("select").val(data.gridType);
    jqObj.find("select").change(function(){
        var currentSettingObj = global.getSelected();
        var gridType = $(this).val();
        if(gridType == 1){
            $('.weui-grids a').css("width","33.33333333%");
        }else if(gridType == 2){
            $('.weui-grids a').css("width","25%");
        }else if(gridType == 3){
            $('.weui-grids a').css("width","50%");
        }else if(gridType == 4){
            $('.weui-grids a').css("width","100%");
        }
        currentSettingObj.val.gridType = gridType;
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}

//宫格里面图标的显示/隐藏
function gridIconOff(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj =$('<div class="form-group col-md-12">' +
        '<label class="col-md-12 control-label">是否显示图片</label>'+
        '<div class="col-md-12">' +
        '<input id="iconOff" type="checkbox" checked>'+
        '<span style="color: #999">'+
        '   显示图片'+
        '</span>'+
        '</div>'+
        '</div>');
    if(!data.gridIconOff)
        data.gridIconOff = true;
    jqObj.find("input").val(data.gridIconOff);
    jqObj.find('input').change(function(){
        var iconOff = $(this).prop('checked');
        if(!!iconOff){
            $('.weui-grids .weui-grid__icon').css("display","block");
        }else{
            $('.weui-grids .weui-grid__icon').css("display","none");
        }
        currentSettingObj.val.gridIconOff = iconOff;
        global.setSelected(currentSettingObj);
    })
    jqObj.appendTo($("#component_attr_box"));
}

//宫格里面样式的显示/隐藏
function gridStyleOff(){
    var jqObj = $('<div class="form-group col-md-12">' +
        '<label class="col-md-12 control-label">是否显示样式</label>'+
        '<div class="col-md-12">' +
        '<input id="gridStyleOff" type="checkbox">'+
        '<span style="color: #999">'+
        '   显示样式'+
        '</span>'+
        '</div>'+
        '</div>');
    jqObj.appendTo($("#component_attr_box"));
    var styleOff=true;
    jqObj.find('input').click(function(){
        if(!!styleOff){
            $('.gridStyle').css('display','block');
            styleOff=!styleOff;
        }else{
            $('.gridStyle').css('display','none');
            styleOff=!styleOff;
        }
    });
    return styleOff;
}

//样式内容
function styleContent(currentSettingObj){
    var jqObj = $('<div class="form-group col-md-12 gridStyle" style="display:none">' +
                    '<form class="editor-form">'+
                    '<div class="form-group col-md-12">'+
                    '<label class="col-md-4 control-label">图片宽度</label>'+
                    '<div class="col-md-8">'+
                    '<div class="col-md-6">'+
                    '<input type="number" class="form-control gridWidth" value="0">'+
                    '</div>'+
                    '<div class="col-md-6">'+
                        '<select class="form-control gridWidthUnit">'+
                            '<option value="px" selected="">px</option>'+
                            '<option value="%">%</option>'+
                            '<option value="rem">rem</option>'+
                        '</select>'+
                    '</div>'+
                    '</div>'+
                    '</div>'+
                    '<div class="form-group col-md-12">'+
                    '<label class="col-md-4 control-label">图片高度</label>'+
                    '<div class="col-md-8">'+
                    '<div class="col-md-6">'+
                    '<input type="number" class="form-control gridHeight" value="0">'+
                    '</div>'+
                    '<div class="col-md-6">'+
                    '<select class="form-control gridHeightUnit">'+
                    '<option value="px" selected="">px</option>'+
                    '<option value="%">%</option>'+
                    '<option value="rem">rem</option>'+
                    '</select>'+
                    '</div>'+
                    '</div>'+
                    '</div>'+
                    '<div class="form-group col-md-12">'+
                    '<label class="col-md-4 control-label">内边距</label>'+
                    '<div class="col-md-8">'+
                    '<div class="col-md-6">'+
                    '<input type="number" class="form-control gridPadding" value="0">'+
                    '</div>'+
                    '<div class="col-md-6">'+
                    '<select class="form-control gridPaddingUnit">'+
                    '<option value="px" selected="">px</option>'+
                    '<option value="%">%</option>'+
                    '<option value="rem">rem</option>'+
                    '</select>'+
                    '</div>'+
                    '</div>'+
                    '</div>'+
                    '<div class="form-group col-md-12">'+
                    '<label class="col-md-4 control-label">外边距</label>'+
                    '<div class="col-md-8">'+
                    '<div class="col-md-6">'+
                    '<input type="number" class="form-control gridMargin" value="0">'+
                    '</div>'+
                    '<div class="col-md-6">'+
                    '<select class="form-control gridMarginUnit">'+
                    '<option value="px" selected="">px</option>'+
                    '<option value="%">%</option>'+
                    '<option value="rem">rem</option>'+
                    '</select>'+
                    '</div>'+
                    '</div>'+
                    '</div>'+
                    '<div class="form-group col-md-12">' +
                    '<label class="control-label col-md-4">背景颜色</label>' +
                    '<div class="col-md-8">' +
                    '<div class="input-group colorpicker-component colorpicker-element grid_style_bg_color" data-colorpicker-id="2">'+
                    '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
                    '<span class="input-group-addon">'+
                    '<i style="background-color: rgb(204, 204, 204);"></i>'+
                    '</span>'+
                    '</div>'+
                    '</div>' +
                    '</div>'+
                    '<div class="form-group col-md-12">' +
                    '<label class="control-label col-md-4">字体颜色</label>' +
                    '<div class="col-md-8">' +
                    '<div class="input-group colorpicker-component colorpicker-element grid_style_font_color" data-colorpicker-id="2">'+
                    '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
                    '<span class="input-group-addon">'+
                    '<i style="background-color: rgb(204, 204, 204);"></i>'+
                    '</span>'+
                    '</div>'+
                    '</div>' +
                    '</div>'+
                    '</form>'+
                '</div>');

    jqObj.find('.grid_style_bg_color').colorpicker({
        format: "rgba"
    });
    jqObj.find('.grid_style_font_color').colorpicker({
        format: "rgba"
    });
    var selectObj1 = $("#"+currentSettingObj.jqObjID).find(".weui-grid .weui-grid__icon");
    var selectObj2 = $("#"+currentSettingObj.jqObjID).find(".weui-grid .weui-grid-inner");
    var gridStyle = {};//存储宽高内外边距；
    var viewGridStyle = {};
    attrGetStyle(".gridWidth",".gridWidthUnit","width",gridStyle,viewGridStyle,selectObj1);
    attrGetStyle(".gridHeight",".gridHeightUnit","height",gridStyle,viewGridStyle,selectObj1);
    attrGetStyle(".gridPadding",".gridPaddingUnit","padding",gridStyle,viewGridStyle,selectObj2);
    attrGetStyle(".gridMargin",".gridMarginUnit","margin",gridStyle,viewGridStyle,selectObj2);
    jqObj.find('.grid_style_bg_color input').change(function(){
        var currentSettingObj = global.getSelected();
        var gridBgColor = $(this).val();
        $("#"+currentSettingObj.jqObjID).find(".weui-grid").css("background-color",gridBgColor)
        currentSettingObj.val.gridBgColor = gridBgColor;
        global.setSelected(currentSettingObj);
    })
    jqObj.find('.grid_style_font_color input').change(function(){
        var currentSettingObj = global.getSelected();
        var gridFontColor = $(this).val();
        $("#"+currentSettingObj.jqObjID).find(".weui-grid p").css("color",gridFontColor)
        currentSettingObj.val.gridFontColor = gridFontColor;
        global.setSelected(currentSettingObj);
        console.log(currentSettingObj)
    })
    jqObj.appendTo($("#component_attr_box"));
}

//宫格的格子的个数
function gridOption(currentSettingObj, notCreateData, index){
    var data = currentSettingObj.val;
    var id = new Date().getTime();
    var optionItem = $('<ul class="col-md-12 gridContent gridContentShow">' +
                        '<li class="form-group col-md-12">' +
                            '<div class="btn-group btn-group-sm btn-block field textAlign" data-multi="0" data-type="buttongroup" data-name="textAlign">'+
                                '<button type="button" class="btn btn-sm col-md-4 btn-success gridAdd">添加</button>'+
                                '<button type="button" class="btn btn-sm col-md-4 btn-info gridOff">展开</button>'+
                                '<button type="button" class="btn btn-sm col-md-4 btn-danger gridDelete">删除</button>'+
                            '</div>'+
                        '</li>'+
                        '<li class="form-group col-md-12">' +
                            '<label class="control-label col-md-4">菜单名称</label>' +
                            '<div class="col-md-8"><input type="text" class="form-control gridName"></div>' +
                        '</li>'+
                        '<li class="form-group col-md-12 hide">' +
                            '<label class="control-label col-md-4">背景图片</label>' +
                            '<div class="col-md-8">' +
                                '<div class="input-group">' +
                                    '<input type="text" class="form-control iconImageName" disabled placeholder="">'+
                                    '<span class="input-group-btn">'+
                                        '<button type="button" class="btn btn-primary">'+
                                            '<input class="backgroundImage" type="file" style="display: block;moz-opacity: 0; opacity: 0;width: 1px;height: 0;">'+
                                            '<i class="fa fa-floppy-o"></i>'+
                                        '</button>'+
                                    '</span>'+
                                '</div>'+
                            '</div>' +
                        '</li>'+
                        '<li class="form-group col-md-12 hide addressType">' +
                            '<label class="control-label col-md-4">菜单链接</label>' +
                            '<div class="col-md-8">'+
                                '<select class="form-control">' +
                                    '<option value="0" selected>无</option>'+
                                    '<option value="1">外部链接</option>'+
                                    '<option value="2">拨打电话</option>'+
                                '</select>'+
                            '</div>' +
                        '</li>'+
                        '<li class="form-group col-md-12  address" style="display:none">' +
                            '<label class="control-label col-md-4">链接地址</label>' +
                            '<div class="col-md-8">'+
                                '<input type="text" class="form-control">'+
                            '</div>' +
                        '</li>'+
                        '<li class="form-group col-md-12 hide">' +
                            '<label class="control-label col-md-4">背景颜色</label>' +
                            '<div class="col-md-8">' +
                                '<div class="input-group colorpicker-component colorpicker-element grid_bg_color" data-colorpicker-id="2">'+
                                    '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
                                    '<span class="input-group-addon">'+
                                        '<i style="background-color: rgb(204, 204, 204);"></i>'+
                                    '</span>'+
                                '</div>'+
                            '</div>' +
                        '</li>'+
                        '<li class="form-group col-md-12 hide">' +
                            '<label class="control-label col-md-4">字体颜色</label>' +
                            '<div class="col-md-8">' +
                                '<div class="input-group colorpicker-component colorpicker-element grid_font_color" data-colorpicker-id="2">'+
                                    '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
                                    '<span class="input-group-addon">'+
                                        '<i style="background-color: rgb(204, 204, 204);"></i>'+
                                    '</span>'+
                                '</div>'+
                            '</div>' +
                        '</li>'+
                    '</ul>');
    var item = $("<div>").html(optionItem).children();

    item.find('.grid_bg_color').colorpicker({
        format: "rgba"
    });
    item.find('.grid_font_color').colorpicker({
        format: "rgba"
    });
    item.find('.gridAdd').click(function(){
        var item =  $(this).parents(".gridContent");
        var currentSettingObj = global.getSelected();
        var newItem = gridOption(currentSettingObj);
        item.parent().append(newItem);
        //动态改变中间区域的数量
        var gridItem = $("#" + currentSettingObj.jqObjID).find(".weui-grids").html();
        gridItem += '<a href="javascript:;" class="weui-grid">' +
            '<div class="weui-grid__icon">' +
            '<img src="../../images/timg.jpg" alt="">' +
            '</div>' +
            '<p class="weui-grid__label divBox_next">Grid</p>' +
            '</a>';
        gridItem =$("<div>").html(gridItem).children();
        var gridType =$('.gridType select').val();
        if(gridType == 1){
            gridItem.last().css("width","33.33333333%");
        }else if(gridType == 2){
            gridItem.last().css("width","25%");
        }else if(gridType == 3){
            gridItem.last().css("width","50%");
        }else if(gridType == 4){
            gridItem.last().css("width","100%");
        }
        var iconOff =$('#iconOff').prop('checked');
        if(!!iconOff){
            gridItem.last().find('.weui-grid__icon').css("display","block");
        }else{
            gridItem.last().find('.weui-grid__icon').css("display","none");
        }

        $("#" + currentSettingObj.jqObjID).find(".weui-grids").html(gridItem);
    });
    item.find('.gridDelete').click(function(){
        var item =  $(this).parents(".gridContent");
        var index2 = $(this).parents(".gridContent").index();
        item.remove();
        //动态改变中间区域的数量
        var gridItem = $("#"+currentSettingObj.jqObjID).find('.weui-grid').eq(index2);
        gridItem.remove();
    });
    var slideOff=true;
    item.find('.gridOff').click(function(){
        var item =  $(this).parents(".gridContent").find("li");
        if(!!slideOff){
            for(var i =0;i<item.length;i++){
                item.eq(i).removeClass("hide");
            }
            $(this).text("隐藏");
            slideOff=false;
        }else{
            for(var i =0;i<item.length;i++){
                item.eq(i).addClass("hide");
            }
            item.eq(0).removeClass("hide");
            item.eq(1).removeClass("hide");
            $(this).text("展开");
            slideOff=true;
        }
    });
    //每个格子的样式设置
    item.find('.gridName').change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var index2 = $(this).parents(".gridContent").index();
        $("#"+currentSettingObj.jqObjID).find(".weui-grid p").eq(index2).text(result);
    });
    item.find('.addressType select').change(function(){
        var addressType = $(this).val();
        if(addressType == "0"){
            item.find('.address').css('display','none');
        }else if(addressType == "1"){
            item.find('.address').css('display','block');
            item.find('.address label').text("跳转链接");
        }else if(addressType == "2"){
            item.find('.address').css('display','block');
            item.find('.address label').text("电话号码");
        }
    })
    item.find('.grid_bg_color input').change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var index2 = $(this).parents(".gridContent").index();
        $("#"+currentSettingObj.jqObjID).find(".weui-grid").eq(index2).css('background-color',result);
    });
    item.find('.grid_font_color input').change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        var index2 = $(this).parents(".gridContent").index();
        $("#"+currentSettingObj.jqObjID).find(".weui-grid p").eq(index2).css('color',result);
    });

    return item;
}

//整个九宫格内容
function gridContent(currentSettingObj){
    var data = currentSettingObj.val;
    var str = '<div class="form-group col-md-12">' +
                '<label class="col-md-12 control-label">内容</label>'+
                '<form class="editor-form">'+
                '</form>'+
            '</div>';
    var jqObj = $("<div>").html(str).children();
    if(!!data.gridOption){
        var tempArrT = [];
        console.log(data.gridOption);
        for(var i= 0; i< data.gridOption.length ; i++){
            tempArrT.push(data.gridOption[i]);
        }
        for(var i= 0; i< tempArrT.length ; i++){
            var item = gridOption(currentSettingObj, true,i);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }else{
        data.gridOption = [];
        for(var i= 0; i< 6 ; i++){
            var item = gridOption(currentSettingObj);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }
    jqObj.appendTo($("#component_attr_box"));
}

/** flex布局 */
function flexItem(currentSettingObj){
    var data = currentSettingObj.val;
    var jqObj = $('<div class="form-group col-md-12">' +
                    '<form class="editor-form">' +
                        '<div class="form-group">' +
                            '<label class="control-label col-md-4">布局等分</label>'+
                            '<div class="col-md-8">' +
                                '<input type="text" class="form-control">'+
                            '</div>'+
                        '</div>'+
                    '</form>'+
                '</div>');
    if(!data.item)
        data.item = 3;
    jqObj.find('input').val(data.item);
    jqObj.find("input").change(function(){
        var currentSettingObj = global.getSelected(),
            result = $(this).val();
        if(result == "" || !result){
            result = data.item;//等于默认
        }
        currentSettingObj.val.item = result;
        $('#pagemain .weui-flex').html("");
        for(var i=0;i<result;i++){
            var str='<div class="weui-flex__item"><div class="divBox_child" style="min-height:50px;border: 1px solid #cfcfcf;"></div></div>';
            console.log(i)
            $('#pagemain .weui-flex').append(str);
        }
        global.setSelected(currentSettingObj);
    });
    jqObj.appendTo($("#component_attr_box"));
}

/** 选项卡（导航栏） */
//选项卡方向
function tabDirection(){
    var jqObj = $('<div class="form-group col-md-12">'+
                    '<label class="col-md-12 control-label">时间/日期格式</label>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option value="align" selected>水平</option>'+
                            '<option value="vertical">垂直</option>'+
                        '</select>'+
                    '</div>'+
                '</div>');
    jqObj.appendTo($("#component_attr_box"));
}

//选项卡的选项个数
function tabOption(currentSettingObj){
    var optionItem = $('<ul class="col-md-12 gridContent gridContentShow">' +
                            '<li class="form-group col-md-12">' +
                                '<div class="btn-group btn-group-sm btn-block field textAlign" data-multi="0" data-type="buttongroup" data-name="textAlign">'+
                                    '<button type="button" class="btn btn-sm col-md-4 btn-success gridAdd">添加</button>'+
                                    '<button type="button" class="btn btn-sm col-md-4 btn-info gridOff">展开</button>'+
                                    '<button type="button" class="btn btn-sm col-md-4 btn-danger gridDelete">删除</button>'+
                                '</div>'+
                            '</li>'+
                            '<li class="form-group col-md-12">' +
                                '<label class="control-label col-md-4">菜单名称</label>' +
                                '<div class="col-md-8"><input type="text" class="form-control tabName"></div>' +
                            '</li>'+
                            '<li class="form-group col-md-12 hide">' +
                                '<label class="control-label col-md-4">是否选中</label>' +
                                '<div class="col-md-8" style="padding-top: 5px;">' +
                                    '<input type="radio" name="show" placeholder="">'+
                                '</div>'+
                            '</li>'+
                            '<li class="form-group col-md-12 hide">' +
                                '<label class="control-label col-md-4">菜单链接</label>' +
                                '<div class="col-md-8">'+
                                '<select class="form-control">' +
                                    '<option value="0" selected>无</option>'+
                                    '<option value="1">外部链接</option>'+
                                    '<option value="2">拨打电话</option>'+
                                '</select>'+
                                '</div>' +
                            '</li>'+
                        '</ul>');
    var item = $("<div>").html(optionItem).children();
    item.find('.gridAdd').click(function(){
        var item =  $(this).parents(".gridContent");
        var currentSettingObj = global.getSelected();
        var newItem = tabOption(currentSettingObj);
        item.parent().append(newItem);
        //动态改变中间区域的数量
        var tabItem = $("#" + currentSettingObj.jqObjID).find(".weui-navbar").html();
        tabItem += '<div class="weui-navbar__item">新增菜单 </div>';
        $("#" + currentSettingObj.jqObjID).find(".weui-navbar").html(tabItem);
    });
    item.find('.gridDelete').click(function(){
        var item =  $(this).parents(".gridContent");
        var index2 = $(this).parents(".gridContent").index();
        item.remove();
        //动态改变中间区域的数量
        var tabItem = $("#"+currentSettingObj.jqObjID).find('.weui-navbar__item').eq(index2);
        tabItem.remove();
    });
    var slideOff=true;
    item.find('.gridOff').click(function(){
        var item =  $(this).parents(".gridContent").find("li");
        if(!!slideOff){
            for(var i =0;i<item.length;i++){
                item.eq(i).removeClass("hide");
            }
            $(this).text("隐藏");
            slideOff=false;
        }else{
            for(var i =0;i<item.length;i++){
                item.eq(i).addClass("hide");
            }
            item.eq(0).removeClass("hide");
            item.eq(1).removeClass("hide");
            $(this).text("展开");
            slideOff=true;
        }
    });
    //每个格子的样式设置
    item.find('.tabName').change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        console.log(result)
        var index2 = $(this).parents(".gridContent").index();
        $("#"+currentSettingObj.jqObjID).find(".weui-navbar__item").eq(index2).text(result);
    });
    return item;
}

//选项卡的内容
function tabContent(currentSettingObj){
    var data = currentSettingObj.val;
    var str = '<div class="form-group col-md-12">' +
        '<label class="col-md-12 control-label">内容</label>'+
        '<form class="editor-form">'+
        '</form>'+
        '</div>';
    var jqObj = $("<div>").html(str).children();
    if(!!data.tabOption){
        var tempArrT = [];
        console.log(data.tabOption);
        for(var i= 0; i< data.tabOption.length ; i++){
            tempArrT.push(data.tabOption[i]);
        }
        for(var i= 0; i< tempArrT.length ; i++){
            var item = gridOption(currentSettingObj, true,i);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }else{
        data.tabOption = [];
        for(var i= 0; i< 3 ; i++){
            var item = tabOption(currentSettingObj);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }
    jqObj.appendTo($("#component_attr_box"));
}

/** 标签页（底部导航） */
//样式
function navStyle(){
    var jqObj = $('<div class="form-group col-md-12">' +
        '<form class="editor-form">'+
        '<div class="form-group col-md-12">' +
        '<label class="control-label col-md-4">文字默认</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group colorpicker-component colorpicker-element nav_style_font_defaultcolor" data-colorpicker-id="2">'+
        '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
        '<span class="input-group-addon">'+
        '<i style="background-color: rgb(204, 204, 204);"></i>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</div>'+
        '<div class="form-group col-md-12">' +
        '<label class="control-label col-md-4">文字选中</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group colorpicker-component colorpicker-element nav_style_font_selectcolor" data-colorpicker-id="2">'+
        '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
        '<span class="input-group-addon">'+
        '<i style="background-color: rgb(204, 204, 204);"></i>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</div>'+
        '<div class="form-group col-md-12">' +
        '<label class="control-label col-md-4">背景颜色</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group colorpicker-component colorpicker-element nav_style_bg_color" data-colorpicker-id="2">'+
        '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
        '<span class="input-group-addon">'+
        '<i style="background-color: rgb(204, 204, 204);"></i>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</div>'+
        '<div class="form-group col-md-12">'+
        '<label class="col-md-4 control-label">图片宽度</label>'+
        '<div class="col-md-8">'+
        '<div class="col-md-6">'+
        '<input type="number" class="form-control paddingLeft" value="0">'+
        '</div>'+
        '<div class="col-md-6">'+
        '<select class="form-control paddingLeftUnit">'+
        '<option value="px" selected="">px</option>'+
        '<option value="%">%</option>'+
        '<option value="rem">rem</option>'+
        '</select>'+
        '</div>'+
        '</div>'+
        '</div>'+
        '<div class="form-group col-md-12">'+
        '<label class="col-md-4 control-label">图片高度</label>'+
        '<div class="col-md-8">'+
        '<div class="col-md-6">'+
        '<input type="number" class="form-control paddingRight" value="0">'+
        '</div>'+
        '<div class="col-md-6">'+
        '<select class="form-control paddingRightUnit">'+
        '<option value="px" selected="">px</option>'+
        '<option value="%">%</option>'+
        '<option value="rem">rem</option>'+
        '</select>'+
        '</div>'+
        '</div>'+
        '</div>'+
        '</form>'+
        '</div>');
    jqObj.find('.nav_style_font_defualtcolor').colorpicker({
        format: "rgba"
    });
    jqObj.find('.nav_style_font_selectcolor').colorpicker({
        format: "rgba"
    });
    jqObj.find('.nav_style_bg_color').colorpicker({
        format: "rgba"
    });
    jqObj.appendTo($("#component_attr_box"));
}

//导航的个数
function navOption(currentSettingObj){
    var optionItem = '<ul class="col-md-12 gridContent gridContentShow">' +
        '<li class="form-group col-md-12">' +
        '<div class="btn-group btn-group-sm btn-block field textAlign" data-multi="0" data-type="buttongroup" data-name="textAlign">'+
        '<button type="button" class="btn btn-sm col-md-4 btn-success gridAdd">添加</button>'+
        '<button type="button" class="btn btn-sm col-md-4 btn-info gridOff">展开</button>'+
        '<button type="button" class="btn btn-sm col-md-4 btn-danger gridDelete">删除</button>'+
        '</div>'+
        '</li>'+
        '<li class="form-group col-md-12">' +
        '<label class="control-label col-md-4">菜单名称</label>' +
        '<div class="col-md-8"><input type="text" class="form-control navName"></div>' +
        '</li>'+
        '<li class="form-group col-md-12 hide">' +
        '<label class="control-label col-md-4">是否选中</label>' +
        '<div class="col-md-8" name="show" style="padding-top: 5px;">' +
        '<input type="radio" placeholder="">'+
        '</div>'+
        '</li>'+
        '<li class="form-group col-md-12 hide">' +
        '<label class="control-label col-md-4">默认图标</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group">' +
        '<input type="text" class="form-control iconImageName" disabled placeholder="">'+
        '<span class="input-group-btn">'+
        '<button type="button" class="btn btn-primary">'+
        '<input class="backgroundImage" type="file" style="display: block;moz-opacity: 0; opacity: 0;width: 1px;height: 0;">'+
        '<i class="fa fa-floppy-o"></i>'+
        '</button>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</li>'+
        '<li class="form-group col-md-12 hide">' +
        '<label class="control-label col-md-4">选中图标</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group">' +
        '<input type="text" class="form-control iconImageName" disabled placeholder="">'+
        '<span class="input-group-btn">'+
        '<button type="button" class="btn btn-primary">'+
        '<input class="backgroundImage" type="file" style="display: block;moz-opacity: 0; opacity: 0;width: 1px;height: 0;">'+
        '<i class="fa fa-floppy-o"></i>'+
        '</button>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</li>'+
        '<li class="form-group col-md-12 hide addressType">' +
        '<label class="control-label col-md-4">菜单链接</label>' +
        '<div class="col-md-8">'+
        '<select class="form-control">' +
        '<option value="0" selected>无</option>'+
        '<option value="1">外部链接</option>'+
        '<option value="2">拨打电话</option>'+
        '</select>'+
        '</div>' +
        '</li>'+
        '<li class="form-group col-md-12  address" style="display:none">' +
        '<label class="control-label col-md-4">链接地址</label>' +
        '<div class="col-md-8">'+
        '<input type="text" class="form-control">'+
        '</div>' +
        '</li>'+
        '</ul>';
    var item = $("<div>").html(optionItem).children();
    item.find('.gridAdd').click(function(){
        var item =  $(this).parents(".gridContent");
        var currentSettingObj = global.getSelected();
        var newItem = navOption(currentSettingObj);
        item.parent().append(newItem);
        //动态改变中间区域的数量
        var navItem = $("#" + currentSettingObj.jqObjID).find(".weui-tabbar").html();
        navItem += '<a href="javascript:;" class="weui-tabbar__item">' +
                        '<span style="display: inline-block;position: relative;">' +
                            '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">' +
                            '<span class="weui-badge" style="position: absolute;top: -2px;right: -13px;">8</span>' +
                        '</span>' +
                        '<p class="weui-tabbar__label">微信</p>' +
                    '</a>';
        $("#" + currentSettingObj.jqObjID).find(".weui-tabbar").html(navItem);
    });
    item.find('.gridDelete').click(function(){
        var item =  $(this).parents(".gridContent");
        var index2 = $(this).parents(".gridContent").index();
        item.remove();
        //动态改变中间区域的数量
        var navItem = $("#"+currentSettingObj.jqObjID).find('.weui-tabbar__item').eq(index2);
        navItem.remove();
    });
    var slideOff=true;
    item.find('.gridOff').click(function(){
        var item =  $(this).parents(".gridContent").find("li");
        if(!!slideOff){
            for(var i =0;i<item.length;i++){
                item.eq(i).removeClass("hide");
            }
            $(this).text("隐藏");
            slideOff=false;
        }else{
            for(var i =0;i<item.length;i++){
                item.eq(i).addClass("hide");
            }
            item.eq(0).removeClass("hide");
            item.eq(1).removeClass("hide");
            $(this).text("展开");
            slideOff=true;
        }
    });
    //每个格子的样式设置
    item.find('.navName').change(function(){
        var currentSettingObj = global.getSelected();
        var result = $(this).val();
        console.log(result)
        var index2 = $(this).parents(".gridContent").index();
        $("#"+currentSettingObj.jqObjID).find(".weui-tabbar__item p").eq(index2).text(result);
    });
    item.find('.addressType select').change(function(){
        var addressType = $(this).val();
        if(addressType == "0"){
            item.find('.address').css('display','none');
        }else if(addressType == "1"){
            item.find('.address').css('display','block');
            item.find('.address label').text("跳转链接");
        }else if(addressType == "2"){
            item.find('.address').css('display','block');
            item.find('.address label').text("电话号码");
        }
    })
    return item;
}

//导航内容
function navContent(currentSettingObj){
    var data = currentSettingObj.val;
    var str = '<div class="form-group col-md-12">' +
        '<label class="col-md-12 control-label">菜单项</label>'+
        '<form class="editor-form">'+
        '</form>'+
        '</div>';
    var jqObj = $("<div>").html(str).children();
    if(!!data.navOption){
        var tempArrT = [];
        console.log(data.navOption);
        for(var i= 0; i< data.navOption.length ; i++){
            tempArrT.push(data.navOption[i]);
        }
        for(var i= 0; i< tempArrT.length ; i++){
            var item = navOption(currentSettingObj, true,i);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }else{
        data.navOption = [];
        for(var i= 0; i< 4 ; i++){
            var item = navOption(currentSettingObj);
            item.appendTo(jqObj.find(".editor-form"));
        }
    }
    jqObj.appendTo($("#component_attr_box"));
}

//图标
function iconSetting(currentSettingObj){
    var jqObj = $('<div class="form-group col-md-12">' +
        '<form class="editor-form">'+
        '<div class="form-group col-md-12">'+
        '<label class="col-md-4 control-label">图标大小</label>'+
        '<div class="col-md-8">'+
        '<div class="col-md-6">'+
        '<input type="number" class="form-control iconSize" value="0">'+
        '</div>'+
        '<div class="col-md-6">'+
        '<select class="form-control iconSizeUnit">'+
        '<option value="px" selected="">px</option>'+
        '<option value="rem">rem</option>'+
        '</select>'+
        '</div>'+
        '</div>'+
        '</div>'+
        '<div class="form-group col-md-12 iconType">' +
        '<label class="control-label col-md-4">图标类型</label>' +
        '<div class="col-md-8">'+
        '<select class="form-control">' +
        '<option value="success" selected>成功</option>'+
        '<option value="info">提示</option>'+
        '<option value="warn">警告</option>'+
        '<option value="waiting">等待</option>'+
        '</select>'+
        '</div>' +
        '</div>'+
        '<div class="form-group col-md-12">' +
        '<label class="control-label col-md-4">图标颜色</label>' +
        '<div class="col-md-8">' +
        '<div class="input-group colorpicker-component colorpicker-element grid_style_icon_color" data-colorpicker-id="2">'+
        '<input type="text" value="rgb(204, 204, 204)" class="form-control">'+
        '<span class="input-group-addon">'+
        '<i style="background-color: rgb(204, 204, 204);"></i>'+
        '</span>'+
        '</div>'+
        '</div>' +
        '</div>'+
        '</form>'+
        '</div>');
    jqObj.find('.grid_style_icon_color').colorpicker({
        format: "rgba"
    });
    //jqObj.find('.iconSize').change(function(){
    //
    //    $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i")
    //});
    jqObj.find('.iconType select').change(function(){
        var iconType = $(this).val();
        if(iconType == "success"){
            $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i").prop("class","weui-icon-success")
        }else if(iconType == "info") {
            $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i").prop("class","weui-icon-info")
        }else if(iconType == "warn") {
            $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i").prop("class","weui-icon-warn")
        }else if(iconType == "waiting") {
            $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i").prop("class","weui-icon-waiting")
        }
    });
    jqObj.find('.grid_style_icon_color input').change(function(){
        var iconColor = $(this).val();
        console.log(iconColor);
        $("#" + currentSettingObj.jqObjID).find(".icon_sp_area i").css('color',iconColor);
    });
    jqObj.appendTo($("#component_attr_box"));


}

//获取组件属性设置里面的值+单位的样式
function attrGetStyle(first,second,key,obj,viewObj,selectObj){//值,单位,属性名,存储的对象,存储(值+单位,用做视图预览部分),中间视图
    $("#component_attr_box").on("change",first,function(){
        var currentSettingObj = global.getSelected();
        var style_unit =$('#component_attr_box '+ second).val();//单位
        var style_value = $(this).val();
        obj[key]=[style_value,style_unit];
        viewObj[key] =style_value+style_unit;
        currentSettingObj.val.gridStyleObj = obj;
        currentSettingObj.val.gridViewStyleObj = viewObj;
        style.addStyle(selectObj,key,style_value+style_unit);
        global.setSelected(currentSettingObj);
        console.log(currentSettingObj)
    });
    $("#component_attr_box").on("change",second,function(){
        var currentSettingObj = global.getSelected();
        var style_unit =$(this).val();//单位
        var style_value = $('#component_attr_box '+ first).val();
        obj[key]=[style_value,style_unit];
        viewObj[key] =style_value+style_unit;
        currentSettingObj.val.gridStyleObj = obj;
        currentSettingObj.val.gridViewStyleObj = viewObj;
        style.addStyle(selectObj,key,style_value+style_unit);
        global.setSelected(currentSettingObj);
        console.log(currentSettingObj)
    });
}
module.exports = {
    assembleSettingMeun:    assembleSettingMeun,
    cancelAllSelect:        cancelAllSelect,
    addSelect:              addSelect,
    clickHaveSelectCom:     clickHaveSelectCom
};