var compStyle = require('./component_style');
var formSetting = require('./formSetting');
var styleInit = require('./styleInit');
var global = require('../utils/global');

    //URL地址
var servecesUrl = "http://20.97.6.62:8080/xinghuo-apaas-superform",
    //保存表单
    templateUiDate={};

function saveForm(){
    var formTepComArr = global.getData('formTepComArr');
    //$("#formCanvas").html("");//控件清空
    if(formTepComArr.length==0){
        alert("表单选不能为空！");
        return false
    }else {
        //$.router.load("./tempList.html");
        //formTepComArr=[];//保存完毕之后清除控件数据
        getFormSetting();
    }
}
/**获取表单设置详细 */
function getFormSetting(){
    var formset = global.getData('formset'),
        formTepComArr = global.getData('formTepComArr');
    if(!formSetting.formTitleShow()){
        return false
    }
    formSetting.formName();
    formSetting.formDesc();
    formSetting.formBgColor();
    formSetting.subCount();
    if(!formSetting.subNoticeEmail()){
        return false
    }
    if(!formSetting.subNoticePhone()){
        return false
    }
    formSetting.formToken();
    if(!formSetting.subUrl()){
        return false
    }
    formset.creator="creator-userid";
    formset.formJson=[];
    var newArr=[];
    var arrItem={};
    for(var i=0;i<formTepComArr.length;i++){
        arrItem.itemId=formTepComArr[i].itemId;
        arrItem.itemKey=formTepComArr[i].key;
        formset.formJson[i]={};
        formset.formJson[i]["val"]=formTepComArr[i].val;
        newArr.push(arrItem);
    }
    formset.formJson=(JSON.stringify(formset.formJson));
    var req={
        "formMsg":formset,
        "formItem":newArr
    };
    console.log(req);
    var url = servecesUrl+"/formMsg/save";
    ajaxFn(url,req,function(res){
        console.log(res);
        if(res.code == 0 || res.code == 200){
            layer.msg('保存成功!');
            $("#xh-sidebar-header div").eq(2).addClass("active").siblings().removeClass("active");
            $("#sidebar-templates").addClass("active").siblings().removeClass("active");
            getTemplate(1);
            pageInit();
        }
    },function(msg){
        alert("Error:"+msg);
    });


}
/** 查询模板 */
function getTemplate(type){//0代表公共模板 1代表私有模板
    $("#sidebar-templates .sidebar-myself-components").html('<div id="load" style="width: 100%;text-align: center;display: block">正在加载中...</div>');
    var url = servecesUrl+"/formMsg/selectTemplateByEntity";
    var formMsg = null;
    if(type == 0){
        formMsg = {
            "isPrivate": "0"
        }
    }else if(type == 1){
        formMsg = {
            "isPrivate": 1,
            "creator": "creator-userid"
        }
    }
    var req = {
        "formMsg":formMsg
    };
    ajaxFn(url,req,function(res){
        $("#load").css("display","none");
        console.log(res);
        tempListDataUI(res.data.records);
    },function(msg){
        alert("Error:"+msg);
    })

}
/** ajax */
function ajaxFn(url,arg,success,error){//请求地址,参数,成功回调,失败回调
    $.ajax({
        url:url,
        type:"POST",
        async:false,
        data:JSON.stringify(arg),
        contentType:"application/json;charset=utf-8",
        success:success,
        error:error
    });
}
//表单列表
function tempListDataUI(data){
    for(var i= 0; i< data.length; i ++){
        data[i].formMsg.formJson=eval('(' + data[i].formMsg.formJson + ')');
        var formId=data[i].formMsg.formId;
        templateUiDate[formId]=data[i].formMsg.formJson;
        var item = tempListItemUI(data[i].formMsg);
        item.appendTo($("#sidebar-templates .sidebar-myself-components"));
    }
    console.log(templateUiDate);
}
//表单item
function tempListItemUI(data){
    var htmlStr =  '<div class="col-md-12 media tempalteList" style="text-align: left;border: 1px solid #666; padding-top: 10px;overflow: inherit">';
    //判断有没有图片
 if(data.formHeadShow == 1){
        if(!!data.formHeadImage){
            var img='<img style="width: 100%" class="thumbnail" src="'+data.formHeadImage+'">';
        }else{
            var img='<img style="width: 100%" class="thumbnail" src="../images/example/icon.png">';
        }
        htmlStr += '<div class="btn-group open pull-right" style="margin: 5px 0">'+
                        '<a class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">'+
                            '<span class="fa fa-caret-down" title="打开下拉菜单"></span>'+
                        '</a>'+
                        '<ul class="dropdown-menu" aria-labelledby="dLabel"  style="cursor: pointer;min-width: 70px" data-key="'+data.formId+'">'+
                            '<li><i class="fa fa-eye fa-fw"></i> 预览</li>'+
                            '<li><i class="fa fa-pencil fa-fw"></i> 编辑</li>'+
                            '<li><i class="fa fa-trash-o fa-fw"></i> 删除</li>'+
                            '<li><i class="fa fa-paper-plane-o fa-fw"></i> 发布</li>'+
                        '</ul>'+
                    '</div>'+
                    '<div class="media-left media-middle" style="width: 30%">' + img +'</div>'+
                    '<div class="media-body">'+
                        '<h4 style="font-weight: bold;color: #000">'+data.formName+'</h4>'+
                        '<p style="max-height: 40px;;display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;overflow: hidden;">'+data.formDesc+'</p>'+
                    '</div>' +
                '</div>';
    }else if(data.formHeadShow == 2){
        htmlStr += '<div class="btn-group open pull-right" style="margin: 5px 0">'+
                        '<a class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">'+
                            '<span class="fa fa-caret-down" title="打开下拉菜单"></span>'+
                        '</a>'+
                        '<ul class="dropdown-menu" aria-labelledby="dLabel"  style="cursor: pointer;min-width: 70px" data-key="'+data.formId+'">'+
                            '<li><i class="fa fa-eye fa-fw"></i> 预览</li>'+
                            '<li><i class="fa fa-pencil fa-fw"></i> 编辑</li>'+
                            '<li><i class="fa fa-trash-o fa-fw"></i> 删除</li>'+
                            '<li><i class="fa fa-paper-plane-o fa-fw"></i> 发布</li>'+
                        '</ul>'+
                    '</div>'+
                    '<div class="media-left media-middle" style="width: 30%">' +
                        '<img style="width: 100%" class="thumbnail" src="'+data.formHeadImage+'">'+
                    '</div>'+
                    '<div class="media-body">'+
                        '<h4 style="font-weight: bold;color: #000">'+data.formName+'</h4>'+
                        '<p style="max-height: 42px;line-height: 20px;display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3;overflow: hidden;">'+data.formDesc+'</p>'+
                    '</div>'+
                '</div>';
    }
    var item = $("<div class='row'>").html(htmlStr);
    //模板预览操作
    item.find(".fa-eye").parent().click(function(){
      var id = $(this).parent().data("key");
      layerOpenPreview(id);
    });
    //模板修改操作
    item.find(".fa-pencil").parent().click(function(){
        var id = $(this).parent().data("key");
        layer.open({
            title: "表单"+id+"修改"
            ,content: '请确认是否有操作未保存,或不保存直接覆盖？'
            ,btn: ['取消', '确认'] //只是为了演示
            ,yes: function(){
                layer.closeAll();
            }
            ,btn2: function(){
                editTemplate(id);
            }
        });
    });
    /** 修改 */
    function editTemplate(formKey){//对应的表单id
        // init formTepComArr, 放在前面
        pageInit();
        var formTepComArr = global.getData('formTepComArr');
        for(var i in templateUiDate){
            if(i == formKey){
                var templateItem =templateUiDate[i];
                for(var j=0;j<templateItem.length;j++){
                    addCompentBox(templateItem[j].val.typeNum);
                    formTepComArr[j].val=templateItem[j].val;
                    console.log(formTepComArr[j].jqObj.find(".viewBox"));
                    console.log(templateItem[j].val);
                    compStyle.addStyle(formTepComArr[j].jqObj.find(".viewBox"),templateItem[j].val.styleObj);
                    compStyle.addStyle(formTepComArr[j].jqObj.find(".viewBox"),templateItem[j].val.viewStyleObj);//带单位的样式
                }
            }
        }
        formReturn(data);
    }
    //模板删除操作
    item.find(".fa-trash-o").parent().click(function(){
        var id = $(this).parent().data("key");
        layer.open({
            title: "表单"+id+"删除"
            ,content: '您确定删除此表单吗？'
            ,btn: ['取消', '确认'] //只是为了演示
            ,yes: function(){
                layer.closeAll();
            }
            ,btn2: function(){
                var url=servecesUrl+"/formMsg/delete";
                var rep={
                    "formMsg":{"formId":id}
                };
                ajaxFn(url,rep,function(res){
                    if(res.data==true){
                        layer.msg('删除成功');
                        getTemplate(1)
                    }
                },function(msg){
                    alert("Error:"+msg);
                })
            }
        });
    });




    return item.children();
}
//页面初始化
function pageInit(){
    debugger;
    $("#pagemain").html("");
    $("#component_attr_box").html("");
    // formTepComArr=[];
    global.setData('formTepComArr', []);
    styleInit.styleInit();
    formInit();
}
//表单设置初始化
function formInit(){
    $('#form_setting .formHeadShow').val("1");
    $('#form_setting .pic_file').hide();
    $('#form_setting .formHeadImage').val("");
    $('#form_setting .fileVal').val("");
    $('#form_setting .formTitle').val("");
    $('#form_setting .formDesc').val("");
    $('#form_setting .color').val("rgb(255, 255, 255)").trigger("change");
    $('#form_setting .subCount').val("");
    $('#form_setting .subNoticeEmail').val("");
    $('#form_setting .subNoticePhone').val("");
    $('#form_setting .formToken').val("");
    $('#form_setting .subUrl').val("");
}
//表单设置回填
function formReturn(data){
    console.log(data);
    for(var i in data){
        if(i == "formHeadShow"){
            if(data[i]=="1"){
                $('#form_setting .formHeadShow').val("1");
                $('#form_setting .formHeadShow').trigger("change");
            }else if(data[i]=="2"){
                $('#form_setting .formHeadShow').val("2");
                $('#form_setting .formHeadShow').trigger("change");
                console.log(data["formHeadImage"]);
                var str='<div id="title" style="width: 100%;height: 90px;">' +
                    '<img id="title_pic" src="" style="width:100%;height:100%;" />'+
                    '</div>';
                $("#pagemain").prepend(str);
                $("#pagemain").find("img").prop("src",data["formHeadImage"]);
                //$("#formHeadImage").val(data["formHeadShow"]);;
            }
        }
        if(i == "formDesc"){
            $('#form_setting .formDesc').val(data[i]);
        }
        if(i == "formName"){
            $('#form_setting .formTitle').val(data[i]);
        }
        if(i == "formBgcolor"){
            $('#form_setting .color').val(data[i]);
            $('#form_setting .color').trigger("change");
        }
        if(i == "subCount"){
            $('#form_setting .subCount').val(data[i]);
        }
        if(i == "subNoticeEmail"){
            $('#form_setting .subNoticeEmail').val(data[i]);
        }
        if(i == "subNoticePhone"){
            $('#form_setting .subNoticePhone').val(data[i]);
        }
        if(i == "formToken"){
            $('#form_setting .formToken').val(data[i]);
        }
        if(i == "subUrl"){
            $('#form_setting .subUrl').val(data[i]);
        }
    }
}

module.exports = {
    saveForm:   saveForm,
    getTemplate: getTemplate
}
