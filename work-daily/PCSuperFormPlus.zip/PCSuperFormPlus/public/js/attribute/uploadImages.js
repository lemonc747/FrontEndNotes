

//将auto配置为false以手动上传
//uploader.start();

document.getElementById("start-upload").onclick = function () {
    uploader.start();
};
var uploadUrl = "";

//打开上传图片的file
function openUploadFile(){
    layer.open({
        type: 1,
        shade: [0.8, '#393D49'],
        shadeClose: true,
        offset: '30px',
        area: ['55%', '55%'], //宽高
        title: false, //不显示标题
        content: $('#uploadImages'), //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响
        cancel: function(){
          // layer.msg('取消！');
        }
    });
    var Uploader = Q.Uploader,
        formatSize = Q.formatSize,
        boxView = document.getElementById("upload-image-view");

    var uploader = new Uploader({
        url: "www.baidu.com",
        target: document.getElementById("upload-target"),
        view: boxView,

        //将auto配置为false以手动上传
        auto: false,

        allows: ".jpg,.png,.gif,.bmp",

        //图片缩放
        scale: {
            //要缩放的图片格式
            types: ".jpg",
            //最大图片大小(width|height)
            maxWidth: 1024
        },
        workerThread: 2,
        on: {
            //添加之前触发
            add: function (task) {
                if (task.disabled) return alert("允许上传的文件格式为：" + this.ops.allows);
            },
            //图片预览后触发
            preview: function (data) {
              console.log("preview:",data);
            },
            //图片压缩后触发,如果图片或浏览器不支持压缩,则不触发
            scale: function (data) {
              console.log("scale:",data);
            },
            upload: function (task) {
              console.log("task:",task);
            },
            remove: function (task) {
              console.log("task:",task);
            },
            complete: function (task) {
                var json = task.json;
                if (!json) return alert("上传已完成，但无法获取服务器返回数据！");
                if (json.ret != 1) return alert(json.msg || "上传失败！");
                layer.msg("上传成功！");
            }

        }
    });
    document.getElementById("start-upload").onclick = function () {
        uploader.start();
    };
}

//获取我的图片
function getMyIamges(){

}
