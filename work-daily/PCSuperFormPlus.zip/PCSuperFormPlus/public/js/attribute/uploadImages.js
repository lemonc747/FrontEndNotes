var servecesUrl = "http://20.97.6.62:8080/xinghuo-apaas-superform";//接口地址
var picAddressObj = null; //用来存储图片地址的input

//调用模态框的对象：组件样式处
$("#component_style .showImageName").siblings().find('button').click(function(){
    modalShowCallBack("#component_style .showImageName");
    $('#fileModal').modal();
});

//调用模态框的对象：表单设置处
$("#formFileBtn").click(function(){
    modalShowCallBack("#formHeadImage");
    $('#fileModal').modal();
});

//模态框打开之后的回调
function modalShowCallBack(jqObj){
    $('#fileModal').on('show.bs.modal', function (e) {
        picAddressObj  = jqObj;
        $("#myFilePic").trigger("click");
    });
}


//选择已经上传的图片
$("#fileModal .myPic").on("click",".pictureBox a",function(){
    if($(this).prop("class") == "active"){
        $(this).removeClass('active')
    }else{
        $(this).addClass('active').parent().siblings().find('a').removeClass('active');
    }
});

//点击保存使用图片
$("#fileSave").click(function(){
    var address = $("#fileModal .myPic .pictureBox").find(".active img").prop("src");
    $(picAddressObj).val(address);
    $(picAddressObj).trigger('change');
});

$("#fileModal .btnList button").click(function(){
    var $this=$(this).index();
    $(this).removeClass("btn-default").addClass("btn-info").siblings().removeClass("btn-info").addClass("btn-default");
    $("#fileModal .file_content").children().eq($this).show().siblings().hide();
});

$("#clickFile").click(function() {
    $("#fileImage").trigger("click");
    $("#fileImage").unbind("change").change(function() {
        for (var i = 0; i < this.files.length; i++) {
            var fileEl = $(this)[i];
            if(picFileType(fileEl) && picFileSize(fileEl)){
                var str = '<div class="col-xs-6 col-md-3 pictureBox">' +
                    '<a href="javascript:;">' +
                    '<img src="' + getObjectURL(this.files[i]) + '">' +
                    '<span class="file_success"></span>'+
                    '<p class="file_error">上传失败，请重试</p>'+
                    '</a>' +
                    '</div>';
                $(".filePic").append(str);
            }
        }
        $("#upFile").prop("disabled",false);
    });
});

$("#myFilePic").click(myFilePic);

//图片上传
function uploadFile() {
    var str='<div class="row" style="margin-top: 45px;">'+
        '<div class="col-xs-12">'+
        '<div class="progress">'+
        '<div id="process" class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="min-width: 5%">'+
        '上传中'+
        '</div>'+
        '</div>'+
        '</div>'+
        '</div>';
    $(".file_content").append(str);
    var file = $('#fileImage')[0].files[0];
    var formData = new FormData();
    formData.append("fileList",file);
    formData.append("userId","baihongyao");
    formData.append("terminalType",1);
    formData.append("organization", "深圳市星火电子公司平台部");
    formData.append("organizationId", "4311120123");
    formData.append("userName", "bb");
    $("#process").css("width","99%");
    $.ajax({
        url: "http://172.28.0.56:9121/s3fileservice/s3/file/uploadByIStream",
        type: "POST",
        contentType: false,
        processData: false,
        mimeType:"multipart/form-data",
        data: formData,
        success: function(result) {
            var result=JSON.parse(result).data;
            console.log(result);
            fileDataSave(result);
        },
        error: function(msg) {
            console.log("Error:", msg);
            $("#process").removeClass("progress-bar-primary").addClass("progress-bar-danger");
            $("#process").css({"transition":".5s all","width":"100%"}).text("上传失败");
            setTimeout(function(){
                $(".filePic").find('.file_error').css("display","block");
                $(".progress").remove();
            },300)
        }
    });
}

//上传之后保存到服务器
function fileDataSave(arg){
    var data2= {
        "userId":"mq",
        "pics":arg
    };
    console.log(data2);
    $.ajax({
        url: servecesUrl + "/formPic/save",
        type: "POST",
        async:false,
        data:JSON.stringify(data2),
        contentType:"application/json;charset=utf-8",
        success: function(result) {
            $("#process").removeClass("progress-bar-primary").addClass("progress-bar-success");
            $("#process").css({"transition":".5s all","width":"100%"}).text("上传成功");
            setTimeout(function(){
                $(".filePic").find('.file_success').css("display","block");
                $(".progress").remove();
            },300);

        },
        error: function(msg) {
            $("#process").removeClass("progress-bar-primary").addClass("progress-bar-danger");
            $("#process").css({"transition":".5s all","width":"100%"}).text("上传失败");
            setTimeout(function(){
                $(".filePic").find('.file_error').css("display","block");
                $(".progress").remove();
            },300)
        }
    })
}

//我的图片显示
function myFilePic(){
    var arg = {
        "userId":"mq"
    };
    $.ajax({
        url:servecesUrl + "/formPic/query",
        type:"POST",
        async:false,
        data:JSON.stringify(arg),
        contentType:"application/json;charset=utf-8",
        success:function(result){
            if(result.data.records.length > 0){
                $(".myPic").html("");
                var showUrl = "http://172.29.3.76:9218";
                for(var i = 0;i < result.data.records.length; i++){
                    var str = '<div class="col-xs-6 col-md-3 pictureBox">' +
                        '<a href="#">' +
                        '<img src="'+ showUrl +  result.data.records[i].relativeFileUrl +'">' +
                        '</a>' +
                        '</div>';
                    $(".myPic").append(str);
                }
            }else{
                $(".myPic").html("");
                $(".myPic").append('<p">暂无图片</p>')
            }
        },
        error:function(msg){
            console.log(msg)
        }

    })
}

//图片类型验证
function picFileType(file) {//dom对象
    var fileTypes = [".jpg", ".png","jpeg"];
    var filePath = file.value;
    //当括号里面的值为0、空字符、false 、null 、undefined的时候就相当于false
    if(filePath){
        var isNext = false;
        var fileEnd = filePath.substring(filePath.indexOf("."));
        for (var i = 0; i < fileTypes.length; i++) {
            if (fileTypes[i] == fileEnd) {
                isNext = true;
                break;
            }
        }
        if (!isNext){
            alert("不接受此文件类型,只接受jpg,.png,jpeg类型的图片");
            return false;
        }else{
            return true
        }
    }else {
        return false;
    }
}

//图片大小验证
function picFileSize(file) {//dom对象
    var fileSize = 0;
    var fileMaxSize = 1024;//1M
    var filePath = file.value;
    if(filePath){
        fileSize =file.files[0].size;
        var size = fileSize / 1024;
        if (size > fileMaxSize) {
            alert("文件大小不能大于1M！");
            return false;
        }else if (size <= 0) {
            alert("文件大小不能为0M！");
            return false;
        }else{
            return true
        }
    }else{
        return false;
    }
}

//获取本地预览地址
function getObjectURL(file){
    var url = null ;
    if (window.createObjectURL!=undefined) { // basic
        url = window.createObjectURL(file) ;
    }
    else if (window.URL!=undefined) {
        // mozilla(firefox)
        url = window.URL.createObjectURL(file) ;
    }
    else if (window.webkitURL!=undefined) {
        // webkit or chrome
        url = window.webkitURL.createObjectURL(file) ;
    }
    return url ;
}
