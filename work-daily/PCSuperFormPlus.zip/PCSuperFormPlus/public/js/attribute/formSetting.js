/**
 * Created by ASUS on 2018/4/13.
 */
var formUtils = require('./temp');
var global = require('../utils/global');

// var down=true;//用来进行下一步表单验证的条件
/** 表单头部显示*/
function formTitleShow(formset){
    var formHeadShow=$('#form_setting .formHeadShow option:selected').val();
    formset.formHeadShow=formHeadShow;
    if(formHeadShow == 2){
        if($("#formHeadImage").val() == "" || $("#formHeadImage").val() == undefined){
            alert("图片不能为空");
            return false
        }
        var formHeadImage=$("#formHeadImage").val();
        formset.formHeadImage=formHeadImage;
    }
    return true;
}
$('#form_setting .formHeadShow').change(function(){
    if($('#form_setting .formHeadShow option:selected').val() == 2){
        $('#form_setting .pic_file').show();
        if($("#title").length>0){
            $("#title").show()
        }
    }else{
        $('#form_setting .pic_file').hide();
        $("#title").hide();
    }
});

/** 获取表单图片 */
$("#formHeadImage").change(function() {
    var address = $(this).val();
    $("#title").remove();
    var str = '<div id="title" style="width: 100%;height: 90px;">' +
        '<img id="title_pic" src="'+ address +'" style="width:100%;height:100%;"/>' +
        '</div>';
    $("#pagemain").prepend(str);

})
/** 表单名称*/
function formName(formset){
    var formName=$('#form_setting .formTitle').val();
    if(formName == undefined || formName == ""){
        formName="名称未定义"
    }
    formset.formName=formName;
}
/** 表单描述*/
function formDesc(formset){
    var formDesc=$('#form_setting .formDesc').val();
    if(formDesc == undefined || formDesc == ""){
        formDesc="描述未定义"
    }
    formset.formDesc=formDesc;
}
/** 表单背景色*/
function formBgColor(formset){
    var formBgColor=$('#form_setting .color').val();
    formset.formBgcolor=formBgColor;
}
/** 每个用户提交数据限制次数*/
function subCount(formset){
    var subCount=$('#form_setting .subCount').val();
    if(subCount != "" && subCount != undefined){
        formset.subCount=subCount;
    }else{
        return false
    }
}
/** 数据提交通知邮箱地址*/
function subNoticeEmail(formset){
    var subNoticeEmail=$('#form_setting .subNoticeEmail').val();
    var re = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$"); //正则表达式

    if(subNoticeEmail !="" && subNoticeEmail != undefined){
        if(!re.test(subNoticeEmail)){
            alert("邮箱地址格式有误!");
            return false;
        }else{
            formset.subNoticeEmail=subNoticeEmail; 
        }
    }
    return true;
}
/** 数据提交通知手机号*/
function subNoticePhone(formset){
    var subNoticePhone=$('#form_setting .subNoticePhone').val();
    if(subNoticePhone != "" && subNoticePhone != undefined) {
        var re = /^1[34578]\d{9}$/g;
        if (!re.test(subNoticePhone)) {
            alert("号码格式有误");
            return false;
        } else {
            formset.subNoticePhone=subNoticePhone;
            return true;
        }
    }else {
        return true;
    }
}
/** 表单访问口令*/
function formToken(formset){
    var formToken=$('#form_setting .formToken').val();
    if(formToken != "" && formToken != undefined){
        formset.formToken=formToken;
        return true;
    }
    return false
    
}
/** 表单提交跳转链接*/
function subUrl(formset){
    var subUrl=$('#form_setting .subUrl').val();
    if(subUrl != "" && subUrl != undefined) {
        var re=/^([hH][tT]{2}[pP]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)(([A-Za-z0-9-~]+)\.)+([A-Za-z0-9-~\/])+$/;
        if (!re.test(subUrl)) {
            alert("这网址不是以http://或https://开头，或者不是网址！");
            return false;
        } else {
            formset.subUrl=subUrl;
            return true;
        }
    }else {
        return true;
    }
}
/** number表单禁止输入E(处理number表单能输入e的问题)*/
$('#form_setting').find('input[type=number]').keypress(function(e) {
    if (!String.fromCharCode(e.keyCode).match(/[0-9.]/)) {
        return false;
    }
});
/** number表单设置为只能输入正整数)*/
$('#form_setting').find('input[type=number]').keyup(function(e) {
    this.value=this.value.replace(/\D/g,'')
});
//图片类型验证
function picFileType(file) {//dom对象
    var fileTypes = [".jpg", ".png","jpeg"];
    var filePath = file.value;
    //当括号里面的值为0、空字符、false 、null 、undefined的时候就相当于false
    if(filePath){
        var isNext = false;
        var fileEnd = filePath.substring(filePath.indexOf("."));
        for (var i = 0; i < fileTypes.length; i++) {
            if (fileTypes[i] == fileEnd) {
                isNext = true;
                break;
            }
        }
        if (!isNext){
            alert("不接受此文件类型,只接受jpg,.png,jpeg类型的图片");
            return false;
        }else{
            return true
        }
    }else {
        return true;
    }
}
//图片大小验证
function picFileSize(file) {//dom对象
    var fileSize = 0;
    var fileMaxSize = 1024;//1M
    var filePath = file.value;
    if(filePath){
        fileSize =file.files[0].size;
        var size = fileSize / 1024;
        if (size > fileMaxSize) {
            alert("文件大小不能大于1M！");
            return false;
        }else if (size <= 0) {
            alert("文件大小不能为0M！");
            return false;
        }else{
            return true
        }
    }else{
        return true;
    }
}
//获取表单数据对象
function getFormPreviewMsg(){
    var formset = global.getData('formset');
    if(!formTitleShow(formset)){
        return false
    }
    formName(formset);
    formDesc(formset);
    formBgColor(formset);
    subCount(formset);
    if(!subNoticeEmail(formset)){
        return false
    }
    if(!subNoticePhone(formset)){
        return false
    }
    formToken(formset);
    if(!subUrl(formset)){
        return false
    }
}


module.exports = {
    formTitleShow:      formTitleShow,
    getFormPreviewMsg:  getFormPreviewMsg,
    picFileSize:        picFileSize,
    picFileType:        picFileType,
    subUrl:             subUrl,
    formToken:          formToken,
    subNoticePhone:     subNoticePhone,
    subNoticeEmail:     subNoticeEmail,
    subCount:           subCount,
    formBgColor:        formBgColor,
    formDesc:           formDesc,
    formName:           formName,
    //fileShow:           fileShow,


}
