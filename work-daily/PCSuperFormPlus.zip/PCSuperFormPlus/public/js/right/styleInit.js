/**
 * Created by ASUS on 2018/4/20.
 */
/** 初始化组件样式 */
//var initStyleObj={
//    "textAlign":"center",
//    "verticalAlign":"middle",
//    "fontFamily":"宋体",
//    "fontSize":[100,"px"],
//    "fontWeight":"bold",
//    "fontStyle":"italic",
//    "textDecoration":"",
//    "fontColor":"#c2c2c2",
//    "backgroundColor":"#9c1c1c",
//    "backgroundImage":"",
//    "opacity":[100,"%"],
//    "borderStyle":"double",
//    "borderWidth":[],
//    "borderColor":"",
//    "borderRadius":[],
//    "letterSpacing":[],
//    "lineHeight":[],
//    "zIndex":"",
//    "paddingTop":[],
//    "paddingBottom":[],
//    "paddingLeft":[],
//    "paddingRight":[],
//    "marginTop":[],
//    "marginBottom":[],
//    "marginLeft":[],
//    "marginRight":[],
//    "overflow":"scroll"
//};
function styleInit(){
    $('#component_style .textAlign').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#component_style .verticalAlign').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#component_style .fontFamily option').eq(0).prop("selected",true);
    valueUnitInit(".fontSize","",".fontSizeUnit","px");
    $('#component_style .textStyle').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#style_font_color input').prop('value','rgb(204, 204, 204)');
    $('#style_font_color i').css('backgroundColor','rgb(204, 204, 204)');
    $('#style_bg_color input').prop('value','rgb(255, 255, 255)');
    $('#style_bg_color i').css('backgroundColor','rgb(255, 255, 255)');
    valueUnitInit(".opacity","",".opacityUnit","%");
    $('#component_style .borderStyle option').eq(0).prop('selected',true);
    valueUnitInit(".borderWidth","",".borderWidthUnit","px");
    $('#style_border_color input').prop('value','rgb(255, 255, 255)');
    $('#style_border_color i').css('backgroundColor','rgb(255, 255, 255)');
    valueUnitInit(".borderRadius","",".borderRadiusUnit","%");//圆角
    valueUnitInit(".letterSpacing","",".letterSpacingUnit","%");//字间距
    $('#component_style .lineHeight').prop('value',"");//字行高
    $('#component_style .zIndex').prop('value',"");//层级
    valueUnitInit(".paddingTop","",".paddingTopUnit","px");
    valueUnitInit(".paddingBottom","",".paddingBottomUnit","px");
    valueUnitInit(".paddingLeft","",".paddingLeftUnit","px");
    valueUnitInit(".paddingRight","",".paddingRightUnit","px");
    valueUnitInit(".marginTop","",".marginTopUnit","px");
    valueUnitInit(".marginBottom","",".marginBottomUnit","px");
    valueUnitInit(".marginLeft","",".marginLeftUnit","px");
    valueUnitInit(".marginRight","",".marginRightUnit","px");
    $('#component_style .overflow option').eq(0).prop('selected',true);
};
/** 组件样式回流 */
function styleRuturn(styleObj){
    for(var i in styleObj){
        if(i == "text-align"){
            var textAlign= styleObj[i];
            $('#component_style .textAlign').find("button[data-value =" +textAlign+"]").removeClass("btn-default").addClass("btn-primary");
        }
        if(i == "vertical-align"){
            var verticalAlign= styleObj[i];
            $('#component_style .verticalAlign').find("button[data-value =" +verticalAlign+"]").removeClass("btn-default").addClass("btn-primary");
        }
        if(i == "font-family"){
            var fontFamily=styleObj[i];
            $('#component_style .fontFamily').val(styleObj[i]);
        }
        if(i == "font-size"){
            $('#component_style .fontSize').val(styleObj[i][0]);
            $('#component_style .fontSizeUnit').val(styleObj[i][1]);
        }
        if(i == "font-weight"){
            $('#component_style .textStyle .fontWeight').removeClass('btn-default').addClass('btn-primary');
        }
        if(i == "font-style"){
            $('#component_style .textStyle .fontStyle').removeClass('btn-default').addClass('btn-primary');
        }if(i == "text-decoration"){
            $('#component_style .textStyle .textDecoration').removeClass('btn-default').addClass('btn-primary');
        }
        if(i == "color"){
            $('#style_font_color input').val(styleObj[i]);
            $('#style_font_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "background-color"){
            $('#style_bg_color input').val(styleObj[i]);
            $('#style_bg_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "opacity"){
            $('#component_style .opacity').val(styleObj[i][0]);
            $('#component_style .opacityUnit').val(styleObj[i][1]);
        }
        if(i == "border-style"){
            $('#component_style .borderStyle').val(styleObj[i]);
        }
        if(i == "border-width"){
            $('#component_style .borderWidth').val(styleObj[i][0]);
            $('#component_style .borderWidthUnit').val(styleObj[i][1]);
        }
        if(i == "border-color"){
            $('#style_border_color input').val(styleObj[i]);
            $('#style_border_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "border-radius"){
            $('#component_style .borderRadius').val(styleObj[i][0]);
            $('#component_style .borderRadiusUnit').val(styleObj[i][1]);
        }
        if(i == "border-width"){
            $('#component_style .letterSpacing').val(styleObj[i][0]);
            $('#component_style .letterSpacingUnit').val(styleObj[i][1]);
        }
        if(i == "line-height"){
            $('#component_style .lineHeight').val(styleObj[i][0]);
            $('#component_style .lineHeightUnit').val(styleObj[i][1]);
        }
        if(i == "z-index"){
            $('#component_style .zIndex').val(styleObj[i]);
        }
        if(i == "padding-top"){
            $('#component_style .paddingTop').val(styleObj[i][0]);
            $('#component_style .paddingTopUnit').val(styleObj[i][1]);
        }
        if(i == "padding-bottom"){
            $('#component_style .paddingBottom').val(styleObj[i][0]);
            $('#component_style .paddingBottomUnit').val(styleObj[i][1]);
        }
        if(i == "padding-left"){
            $('#component_style .paddingLeft').val(styleObj[i][0]);
            $('#component_style .paddingLeftUnit').val(styleObj[i][1]);
        }
        if(i == "padding-right"){
            $('#component_style .paddingRight').val(styleObj[i][0]);
            $('#component_style .paddingRightUnit').val(styleObj[i][1]);
        }
        if(i == "margin-top"){
            $('#component_style .marginTop').val(styleObj[i][0]);
            $('#component_style .marginTopUnit').val(styleObj[i][1]);
        }
        if(i == "margin-bottom"){
            $('#component_style .marginBottom').val(styleObj[i][0]);
            $('#component_style .marginBottomUnit').val(styleObj[i][1]);
        }
        if(i == "margin-left"){
            $('#component_style .marginLeft').val(styleObj[i][0]);
            $('#component_style .marginLeftUnit').val(styleObj[i][1]);
        }
        if(i == "margin-right"){
            $('#component_style .marginRight').val(styleObj[i][0]);
            $('#component_style .marginRightUnit').val(styleObj[i][1]);
        }
        if(i == 'overflow'){
            $('#component_style .overflow').val(styleObj[i]);
        }
    }
}
/** 初始化值+单位的输入框组 */
function valueUnitInit(first,val,second,unit){
    $('#component_style '+first).prop('value',val);
    $('#component_style '+second).prop('value',unit);
}

