var obj = {
    counter: 3
}
function incCounter() {
    obj.counter++;
}
module.exports = {
  counter: obj.counter,
  obj: obj,
  incCounter: incCounter,
};