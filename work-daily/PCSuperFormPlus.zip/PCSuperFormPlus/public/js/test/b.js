 // A.js
 module.exports = {
    a: 'xxxx',
    b: 'zzzzz'
  }
