console.log("require1");
var counter = require('./a').counter;
var obj = require('./a').obj;
var incCounter = require('./a').incCounter;

console.log(counter);  // 3
incCounter();
console.log(counter); // 3
console.log(obj.counter); // 3

console.log("require2");
var obj = require('./a');
console.log(obj.counter);  // 3
obj.counter = 10;
console.log(obj.obj.counter); // 3


console.log("require3");

//require('./a').counter = 6;
var obj2 = require('./a');
console.log(obj2.counter);  // 3
obj2.incCounter();
console.log(obj2.obj.counter); // 3

//B.js
var global = require('./b');
global.a = 'mmmm';
console.log("global.a:"+ require("./b").a);