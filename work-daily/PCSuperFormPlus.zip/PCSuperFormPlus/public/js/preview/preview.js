/**预览界面功能
 *
 * 1 可见设计好的表单
 * 2 并对表单可以进行上下排序
 *
*/
var global = require('../utils/global'),
    template = require('../component/template');

$(document).on("click","#pagepreview",function () {
    //预览之前更新components的结构数据
    global.updateCompsTree();
    //多窗口模式，层叠置顶
    layerOpenPreview();
});

//打开预览弹窗
function layerOpenPreview(id){
  //id为表单id  针对模板预览
  var iframeURL = '../../preview.html';
  if(!!id){
    iframeURL += "?id="+id;
  }
  layer.open({
      type: 2 //此处以iframe举例
      ,title: '预览'
      ,area: ['80%', '80%']
      ,shade: 0.3
      ,maxmin: true
      ,content: iframeURL
      ,btn: ['继续弹出', '全部关闭']
      ,yes: function(){
      $(that).click();
      }
      ,btn2: function(){
      layer.closeAll();
      }

      ,zIndex: layer.zIndex //重点1
      // ,success: function(layero){
      // layer.setTop(layero); //重点2
      // var preview = layer.getChildFrame('#preview');
      // previewPageLoad(preview)
      // }
  });
}

/**预览界面 */
function previewPageLoad(selector){
    selector.html("");
    handlerDataCUI(selector);
}

/**根据数据UI生成相应的组件 */
function handlerDataCUI(selector){
    var formTepComArr = global.getData('formTepComArr');
    for(var i = 0; i < formTepComArr.length; i++){
        var jqObj = createFormUI(formTepComArr[i]);
        if(!!jqObj){
            selector.append(jqObj);
            console.log(jqObj);
        }
    }
    global.setData('formTepComArr', formTepComArr);
}

/**生成UI */
function createFormUI(data){
    var componentType =  data.val.typeNum;
    var componentJq;
    switch (componentType) {
        case template.SIMPLEINPUT:
            componentJq = getSimpleInput(data);
            break;
        case template.TEXTAREA:
            componentJq = getTextArea(data);
            break;
        case template.RADIO:
            componentJq = getRadio(data);
            break;
        case template.CHECKBOX:
            componentJq = getCheckBox(data);
            break;
        case template.SELECT:
            componentJq = getSelectBox(data);
            break;
        case template.NUMBER:
            componentJq = getNumberInput(data);
            break;
        case template.DATE:
            componentJq = getDate(data);
            break;
        case template.SWITCH:
            componentJq = getSwitch(data);
            break;
        case template.CASCADER:
            componentJq = getCascaderInput(data);
            break;
        case template.TEXT:
            componentJq = getTextBar(data);
            break;
        case template.SCORE:
            componentJq = getScore(data);
            break;
        case template.SPLITLINE:
            componentJq = getSpiltLine(data);
            break;
        default:
            break;
    }
    return componentJq;
}

/**生成单行输入框 */
function getSimpleInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var disable = data.val.disable;
    var readOnly = data.val.readonly;
    var required = data.val.required;
    var styleObj = data.val.styleObj;
    var unitStyle = data.val.viewStyleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cells">'+
            '<div class="weui-cell">'+
            '<div class="weui-cell__bd">'+
                '<input class="weui-input component_inputTip"  maxlength="'+maxNumber+'" type="'+type+'" placeholder="'+placeholder+'">'+
            '</div>'+
            '</div>'+
        '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj).css(unitStyle);
    divv.data("key",key);
    if(disable){
        divv.find("input").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("input").attr("readonly","readonly");
    }
    if(required){
        divv.find("input").attr("required","required");
    }
    return divv;
}

/**生成多行输入框 */
function getTextArea(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var readOnly = data.val.readonly;
    var disable = data.val.disable;
    var required = data.val.required;
    var rows = data.val.rows;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
                        '<div class="weui-cell" style="background-color:#fff">'+
                        '<div class="weui-cell__bd">'+
                        '<textarea class="weui-textarea component_inputTip" maxlength="'+maxNumber+'"  placeholder="'+placeholder+'" rows="3"></textarea>'+
                        '<div class="weui-textarea-counter"><span class="textArarCount">0</span>/'+maxNumber+'</div>'+
                        '</div>'+
                    '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    if(disable){
        divv.find("textarea").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("textarea").attr("readonly","readonly");
    }
    if(required){
        divv.find("textarea").attr("required","required");
    }
    if(!!rows){
        divv.find("textarea").attr("rows",rows);
    }
    //改变字符
    divv.find("textarea").bind('input',function(e){
        $(e.target).parent().find(".textArarCount").text($(e.target).val().length);
    });

    divv.data("key",key);
    return divv;
}

/**生成日期输入框 */
function getDate(data){
    // console.log(data);
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var readOnly = data.val.readonly;
    var disable = data.val.disable;
    var required = data.val.required;
    var dateFormat = data.val.datatimeformat;
    var isCalendar = data.val.isCalendar;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
                            '<div class="weui-cell" style="background-color:#fff">'+
                            '<div class="weui-cell__bd">'+
                            '<input class="weui-input component_inputTip date_check" data-toggle="date" type="text" value="">'+
                            '</div>'+
                            '<div id="#"></div>'
                            '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);

    //if(isCalendar){
    //    divv.find("input").calendar({
    //        inputReadOnly: true,
    //        dateFormat:dateFormat
    //    });
    //}else{
    //    divv.find("input").datetimePicker({
    //        formatValue:function(picker,value,displayVale){
    //        }
    //    });
    //}

    divv.data("key",key);
    return  divv;
}


//生成勾选框
function getSwitch(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var styleObj = data.val.styleObj;
    var linkText = data.val.linkText;
    var linkUrl = data.val.linkUrl;
    var contentText = data.val.contentText;
    var componentStr ='<div class="weui-cells__title component_Name">'+name+'</div>'+
    '<label for="weuiAgree" class="weui-agree" style="background-color:#fff">'+
        '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">'+
        '<span class="weui-agree__text"><span class="contentText_Name">'+contentText+'</span>'+
        ' <a href="javascript:void(0);"> <span class="linkText_linkContent">'+linkText+'</span></a>'+
        '</span>'+
    '</label>';

    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}


/**生成单选框 */
function getRadio(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_radio" style="margin-top:0px;">';
    var componentStr = ""+containerStr;
    //创建选项
    for(var i = 0; i< option.length;i++){
        componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x11'+i+'">'+
            '<div class="weui-cell__bd">'+
            '<p>'+option[i].value+'</p>'+
            '</div>'+
            '<div class="weui-cell__ft">';
            if(option[i].selected){
                componentStr +='<input type="radio" class="weui-check" name="radio1" checked="checked" id="x11'+i+'">';
            }else{
                componentStr +='<input type="radio" class="weui-check" name="radio1" id="x11'+i+'">';
            }

            componentStr +='<span class="weui-icon-checked"></span>'+
            '</div>'+
        '</label>';
    }
    componentStr += "</div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}

/**生成多选框 */
function getCheckBox(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_checkbox">';
    var componentStr = "" + containerStr;
    if(!!option){
        for(var i= 0; i< option.length; i++){
            componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s11'+i+'">'+
                '<div class="weui-cell__hd">';
                if(option[i].selected){
                    componentStr += '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+i+'" checked="checked">';
                }else{
                    componentStr += '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+i+'">';
                }
                componentStr +='<i class="weui-icon-checked"></i>'+
                '</div>'+
                '<div class="weui-cell__bd">'+
                '<p>'+option[i].value+'</p>'+
                '</div>'+
                '</label>';
        }
    }
    componentStr += "</div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}
/**生成数字 */
function getNumberInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var disable = data.val.disable;
    var readOnly = data.val.readonly;
    var required = data.val.required;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cell"  style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<input class="weui-input"  pattern="[0-9]*" oninput="if(value.length>'+maxNumber+')value=value.slice(0,'+maxNumber+')" type="'+type+'">'+
        '</div>'+
        '</div>';

    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    if(disable){
        divv.find("input").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("input").attr("readonly","readonly");
    }
    if(required){
        divv.find("input").attr("required","required");
    }
    return divv;
}

/**生成地区联级input CASCADER*/
function getCascaderInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cells">'+
            '<div class="weui-cell">'+
            '<div class="weui-cell__bd">'+
                '<input class="weui-input component_inputTip"  maxlength="'+maxNumber+'" type="'+type+'" placeholder="'+placeholder+'">'+
            '</div>'+
            '</div>'+
        '</div>';

    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    divv.find("input").cityPicker();
    return divv;
}

/**生成分割线 */
function getSpiltLine(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var splitline = data.val.splitline;
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-cell" style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<hr style="border: 1px '+splitline+' #9F9F9F;"/>'+
        '</div>'+
        '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return divv;
}

/**生成下拉框 */
function getSelectBox(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_checkbox">';
    var componentStr = "" + containerStr;
    componentStr += '<select class="weui-select selectClass" name="select">';
    for(var i= 0; i< option.length; i++){
        if (option[i].selected) {
            componentStr += ' <option value="' + option[i].value + '" selected>' + option[i].value + '</option>';
        } else {
            componentStr += ' <option value="' + option[i].value + '">' + option[i].value + '</option>';
        }
    }
    componentStr += "</select></div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}

/**生成地区级联输入框 */
function getArea(data) {
    // console.log(data);
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-cell" style="background-color:#fff">' +
        '<div class="weui-cell__bd">' +
        '<input type="text" class="weui-input component_inputTip" id="city-picker" value="广东省 广州市 市辖区" />' +
        '</div>' +
        '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.find("#city-picker").cityPicker({
        title: "请选择地址"

    });
    divv.data("key", key);
    return divv;
}
/**文本栏目 */
function getTextBar(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return divv;
}

/**生成评分 */
function getScore(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var defaultscore = data.val.defaultscore;
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-cell" style="background-color:#fff"><div class="weui-cell__bd">';
    for(var i = 0 ; i < defaultscore; i++){
        componentStr += ' <span class="fa fa-star starScore"></span>';
    }
    componentStr += '</div></div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key)
    return divv;
}

//根据数据生成UI控件了
