var global = require('../utils/global');
var temp = require('./temp');
var formSetting = require('../attribute/formSetting');

// function selects(){
//     var options = $('.phone_type  option:selected').val();
//     console.log(options);
//     if(options==1){
//         $("#design").css({"width":"360px","height":"640px"});
//     }else if(options==2){
//         $("#design").css({"width":"480px","height":"854px"});
//     }
//     else if(options==3){
//         $("#design").css({"width":"412px","height":"732px"});
//     }
//     else if(options==4){
//         $("#design").css({"width":"360px","height":"640px"});
//     }
//     else if(options==5){
//         $("#design").css({"width":"411px","height":"823px"});
//     }
// }


var formTepComArr = global.getData('formTepComArr');
var formset = global.getData('formset');

// 副本
var showJsonArr = [];
for(var i= 0; i < formTepComArr.length; i++){
    var showJson = {};
    showJson.key = formTepComArr[i].key;
    showJson.val = formTepComArr[i].val;
    showJsonArr.push(showJson);
}
//获取formset表单设置信息
formSetting.getFormPreviewMsg();
var id = temp.GetQueryString("id");
console.log("-i-",id);
//判断是重模板预览过来的还是点击预览
if(!!id){
    $("#previewphone").attr("src","../previewIframe/previewphone.html?formsg="+encodeURI(encodeURI(id)));
}else{
    //处理好的数据拼接到手机预览
    $("#previewphone").attr("src","../previewIframe/previewphone.html?formsg="+encodeURI(encodeURI(JSON.stringify(showJsonArr)))+"&formset="+encodeURI(encodeURI(JSON.stringify(formset))));
    temp.refreshShowJSON(showJsonArr);
}




