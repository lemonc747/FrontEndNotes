
require("expose-loader?$!jquery");

require('../utils/global');
require('../utils/prototype');


function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}

//重新定义个全局变量
var formTepComArr = GetQueryString("formsg");
formTepComArr= decodeURI(formTepComArr);
console.log(formTepComArr);
var str=window.location.search;
var formset =  str.substring(str.indexOf("&"));
formset=formset.substring(formset.indexOf("=")+1);
formset= decodeURI(decodeURI(formset));
console.log(formset);
if(!!formTepComArr){
  try {
      formTepComArr = JSON.parse(formTepComArr);
      formset =JSON.parse(formset);
  } catch (e) {
      //获取ajax请求 拿到fromJSON
      formTepComArr = getFormMSg(formTepComArr);
  } finally {
      console.log("dfsdsdfs");
      //加到画布中去
      previewPageLoad($("#preview"));
  }
}

//更新Previewlayer的数据
parent.refreshShowJSON(formTepComArr);
