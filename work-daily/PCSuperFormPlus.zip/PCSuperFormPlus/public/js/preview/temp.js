var global = require('../utils/global'),
    formMsgUrl = global.getData('formMsgUrl');

function getFormMSg(id){
  console.log("getFormMSg");
  var ajaxParam = {};
  ajaxParam.ids = [];
  ajaxParam.ids.push(id);
  var data;
  $.ajax({
        url:formMsgUrl+"/formMsg/selectByFormIds",
        type: "POST",
        async:false,
        contentType: "application/json;charset=utf-8",
        data: JSON.stringify(ajaxParam),
        dataType: "json",
        success: function(res) {
            if(res.code== 200){
                data = JSON.parse(res.data[0].formMsg.formJson);
                var widgets = res.data[0].widgets;
                for(var i = 0; i < data.length; i++){
                  data[i].Key = widgets[i].itemKey;
                }
            }
        },
        error: function(msg) {
            console.log("Error:" + msg);
        }
    });
    return data;
}

function refreshShowJSON(data){
    //格式化json     var y = JSON.stringify(msg, null, 4);   这个
    $("#dataJSONContent").append("<textarea id='data' style='width:100%;height:100%' class='info'>" + JSON.stringify(data,null, 4) + "</textarea>"); ;
}

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}
module.exports = {
    getFormMSg: getFormMSg,
    refreshShowJSON: refreshShowJSON,
    GetQueryString: GetQueryString
};
