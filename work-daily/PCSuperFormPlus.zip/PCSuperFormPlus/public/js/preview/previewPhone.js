var global = require('../utils/global'),
    template = require('../component/template');

/**预览界面 */
function previewPageLoad(selector){
    var formset = global.getData('formset');
    selector.html("");
    for(var i in formset){
        if(i == "formHeadShow"){
            if(formset["formHeadShow"]=="2") {
                var str = '<div id="title2" style="width: 100%;height: 90px;">' +
                    '<img id="title_pic2" src="" style="width:100%;height:100%;" />' +
                    '</div>';
                selector.prepend(str);
                selector.find("img").prop("src", formset["formHeadImage"]);
            }
        }
    }
    handlerDataCUI(selector);
}

/**
 * 根据数据UI生成相应的组件
 * @param {*} selector 
 */
function handlerDataCUI(selector){
    var formTepComArr = global.getData('formTepComArr'),
        compsTree = global.getData("compsTree");
    for(var i=0,len=compsTree.length; i<len; i++){
        var comp = compsTree[i],
            formData = searchArray(formTepComArr, "key", comp.key);
        // 父级组件
        var jqObj = createFormUI(formData);
        if(!!jqObj){
            selector.append(jqObj);
            console.log(jqObj);
        }
        if(comp.children){
            var ccomps = comp.children;
            for(var j=0, clen=ccomps.length ; j<clen; j++){
                var ccomp  = ccomps[j],
                    cformData = searchArray(formTepComArr, "key", ccomp.key),
                    cjqObj = createFormUI(cformData);

                // //test
                // var test = jqObj.find(".divBox_child")[j];
                // test.append(cjqObj.clone());
                // selector.append(cjqObj);
                $(jqObj.find(".divBox_child")[j]).append(cjqObj);
            }
        }
    }

    // for(var i = 0; i < formTepComArr.length; i++){
    //     var jqObj = createFormUI(formTepComArr[i]);
    //     if(!!jqObj){
    //         selector.append(jqObj);
    //         console.log(jqObj);
    //     }
    // }
    global.setData('formTepComArr', formTepComArr);
}

/**
 * 查找data数组成员，其key属性为val值，返回符合条件的第一个成员
 * @param {Array} data 数组数据
 * @param {string} key 数组item的属性名
 */
function searchArray(data, key, val){
    for(var i=0, len=data.length; i<len; i++){
        if(data && data[i][key] === val){
            return data[i];
        }
    }
}

/**生成UI */
function createFormUI(data){    
    var componentType =  data.val.typeNum+'';
    var componentJq;
    switch (componentType) {
        case template.SIMPLEINPUT:
            componentJq = getSimpleInput(data);
            break;
        case template.TEXTAREA:
            componentJq = getTextArea(data);
            break;
        case template.RADIO:
            componentJq = getRadio(data);
            break;
        case template.CHECKBOX:
            componentJq = getCheckBox(data);
            break;
        case template.SELECT:
            componentJq = getSelectBox(data);
            break;
        case template.NUMBER:
            componentJq = getNumberInput(data);
            break;
        case template.DATE:
            componentJq = getDate(data);
            break;
        case template.SWITCH:
            componentJq = getSwitch(data);
            break;
        case template.CASCADER:
            componentJq = getCascaderInput(data);
            break;
        case template.TEXT:
            componentJq = getTextBar(data);
            break;
        case template.SCORE:
            componentJq = getScore(data);
            break;
        case template.SPLITLINE:
            componentJq = getSpiltLine(data);
            break;
        case template.GRID:
            componentJq = getGrid(data);
            break;
        case template.FLEX:
            componentJq = getFlex(data);
            break;
        case template.NAVBAR:
            componentJq = getNav(data);
            break;
        case template.SEARCH:
            componentJq = getSearch(data);
            break;
        case template.PICTURE:
            componentJq = getPicture(data);
            break;
        default:
            break;
    }
    return componentJq;
}

/**生成单行输入框 */
function getSimpleInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var disable = data.val.disable;
    var readOnly = data.val.readonly;
    var required = data.val.required;
    var styleObj = data.val.styleObj;
    var unitStyle = data.val.viewStyleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cells">'+
            '<div class="weui-cell">'+
            '<div class="weui-cell__bd">'+
                '<input class="weui-input component_inputTip"  maxlength="'+maxNumber+'" type="text" placeholder="'+placeholder+'">'+
            '</div>'+
            '</div>'+
        '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj).css(unitStyle);
    divv.data("key",key);
    if(disable){
        divv.find("input").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("input").attr("readonly","readonly");
    }
    if(required){
        divv.find("input").attr("required","required");
    }
    return divv;
}

/**生成多行输入框 */
function getTextArea(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var readOnly = data.val.readonly;
    var disable = data.val.disable;
    var required = data.val.required;
    var rows = data.val.rows;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
                        '<div class="weui-cells" >'+
                        '<div class="weui-cell">'+
                        '<div class="weui-cell__bd">'+
                        '<textarea class="weui-textarea component_inputTip" maxlength="'+maxNumber+'"  placeholder="'+placeholder+'" rows="3"></textarea>'+
                        '<div class="weui-textarea-counter"><span class="textArarCount">0</span>/'+maxNumber+'</div>'+
                        '</div>'+
                        '</div>'+
                    '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    if(disable){
        divv.find("textarea").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("textarea").attr("readonly","readonly");
    }
    if(required){
        divv.find("textarea").attr("required","required");
    }
    if(!!rows){
        divv.find("textarea").attr("rows",rows);
    }
    //改变字符
    divv.find("textarea").bind('input',function(e){
        $(e.target).parent().find(".textArarCount").text($(e.target).val().length);
    });

    divv.data("key",key);
    return divv;
}

/**生成日期输入框 */
function getDate(data){
    // console.log(data);
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var readOnly = data.val.readonly;
    var disable = data.val.disable;
    var required = data.val.required;
    var dateFormat = data.val.datatimeformat;
    var isCalendar = data.val.isCalendar;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
                            '<div class="weui-cells" >'+
                            '<div class="weui-cell">'+
                            '<div class="weui-cell__bd">'+
                            '<input class="weui-input component_inputTip date_check" data-toggle="date" type="text" value="">'+
                            '</div>'+
                            '</div>'+
                            '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);

    if(isCalendar){
        divv.find("input").calendar({
            inputReadOnly: true,
            dateFormat:dateFormat
        });
    }else{
        divv.find("input").datetimePicker({
            formatValue:function(picker,value,displayVale){
            }
        });
    }

    divv.data("key",key);
    return  divv;
}


/** 生成勾选框 */
function getSwitch(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var styleObj = data.val.styleObj;
    var linkText = data.val.linkText;
    var linkUrl = data.val.linkUrl;
    var contentText = data.val.contentText;
    var componentStr ='<div class="weui-cells__title component_Name">'+name+'</div>'+
    '<div class="weui-cells" >'+
    '<label for="weuiAgree" class="weui-agree">'+
        '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">'+
        '<span class="weui-agree__text"><span class="contentText_Name">'+contentText+'</span>'+
        ' <a href="javascript:void(0);"> <span class="linkText_linkContent">'+linkText+'</span></a>'+
        '</span>'+
    '</label>'+
    '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}


/**生成单选框 */
function getRadio(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_radio">';
    var componentStr = ""+containerStr;
    //创建选项
    for(var i = 0; i< option.length;i++){
        componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x11'+i+'">'+
            '<div class="weui-cell__bd">'+
            '<p>'+option[i].value+'</p>'+
            '</div>'+
            '<div class="weui-cell__ft">';
            if(option[i].selected){
                componentStr +='<input type="radio" class="weui-check" name="radio1" checked="checked" id="x11'+i+'">';
            }else{
                componentStr +='<input type="radio" class="weui-check" name="radio1" id="x11'+i+'">';
            }

            componentStr +='<span class="weui-icon-checked"></span>'+
            '</div>'+
        '</label>';
    }
    componentStr += "</div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}

/**生成多选框 */
function getCheckBox(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_checkbox">';
    var componentStr = "" + containerStr;
    if(!!option){
        for(var i= 0; i< option.length; i++){
            componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s11'+i+'">'+
                '<div class="weui-cell__hd">';
                if(option[i].selected){
                    componentStr += '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+i+'" checked="checked">';
                }else{
                    componentStr += '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+i+'">';
                }
                componentStr +='<i class="weui-icon-checked"></i>'+
                '</div>'+
                '<div class="weui-cell__bd">'+
                '<p>'+option[i].value+'</p>'+
                '</div>'+
                '</label>';
        }
    }
    componentStr += "</div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}
/**生成数字 */
function getNumberInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var disable = data.val.disable;
    var readOnly = data.val.readonly;
    var required = data.val.required;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cells" >'+
        '<div class="weui-cell" >'+
        '<div class="weui-cell__bd">'+
        '<input class="weui-input"  pattern="[0-9]*" oninput="if(value.length>'+maxNumber+')value=value.slice(0,'+maxNumber+')" type="'+type+'">'+
        '</div>'+
        '</div>'+
        '</div>';

    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    if(disable){
        divv.find("input").attr("disabled","disabled");
    }
    if(readOnly){
        divv.find("input").attr("readonly","readonly");
    }
    if(required){
        divv.find("input").attr("required","required");
    }
    return divv;
}

/**生成地区联级input CASCADER*/
function getCascaderInput(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var placeholder = data.val.placeholder;
    var maxNumber = data.val.maxnumber;
    var minNumber = data.val.minnumber;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
        '<div class="weui-cells">'+
            '<div class="weui-cell">'+
            '<div class="weui-cell__bd">'+
                '<input class="weui-input component_inputTip"  maxlength="'+maxNumber+'" type="'+type+'" placeholder="'+placeholder+'" value="广东省 广州市 市辖区">'+
            '</div>'+
            '</div>'+
        '</div>';

    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    divv.find("input").cityPicker();
    return divv;
}

/**生成分割线 */
function getSpiltLine(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var splitline = data.val.splitline;
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-cell" style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<hr style="border: 1px '+splitline+' #9F9F9F;"/>'+
        '</div>'+
        '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return divv;
}

/**
 * test: flex容器
 */
function getFlex(data){
    var key = data.key;
    var type = data.val.type;
    var itemNum = data.val.item;
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-flex">';
    var items = "";
    for(var i = 0; i < itemNum; i ++){
        items += '<div class="weui-flex__item">' +
                    '<div class="divBox_child" style="min-height:50px;border: 1px solid #cfcfcf;background-color: #FFFFFF;border-radius: 4px;margin: 0;padding: 0;position: relative;"></div>' +
                '</div>'
    }
    componentStr += items;
    componentStr += '</div>';
    var div = $("<div>").html(componentStr).css(styleObj);
    div.data("key",key);
    return div;
}

/**生成下拉框 */
function getSelectBox(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var option = data.val.options;
    var styleObj = data.val.styleObj;
    var containerStr = '<div class="weui-cells__title component_Name">'+name+'</div>';
    containerStr += '<div class="weui-cells weui-cells_checkbox">';
    var componentStr = "" + containerStr;
    componentStr += '<select class="weui-select selectClass" name="select">';
    for(var i= 0; i< option.length; i++){
        if (option[i].selected) {
            componentStr += ' <option value="' + option[i].value + '" selected>' + option[i].value + '</option>';
        } else {
            componentStr += ' <option value="' + option[i].value + '">' + option[i].value + '</option>';
        }
    }
    componentStr += "</select></div>";
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return  divv;
}

/**文本栏目 */
function getTextBar(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var styleObj = data.val.styleObj;
    var componentStr =  '<div class="weui-cells__title component_Name">'+name+'</div>'+
    '<div class="weui-cells">'+
    '<div class="weui-cell">'+
    '<div class="weui-cell__bd">'+
    '<input class="weui-input component_inputTip" type="'+type+'">'+
    '</div>'+
    '</div>'+
    '</div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    divv.data("key",key);
    return divv;
}

/**生成评分 */
function getScore(data){
    var key = data.key;
    var name = data.val.label;
    var type = data.val.type;
    var defaultscore = data.val.defaultscore;//默认评分
    var gradingscale = data.val.gradingscale;//评分最大值(评分尺度)
    var styleObj = data.val.styleObj;
    var componentStr = '<div class="weui-cells__title component_Name">评分</div><div class="weui-cells" ><div class="weui-cell"><div class="weui-cell__bd">';
    for(var i = 0 ; i < gradingscale; i++){
        componentStr += ' <span class="fa fa-star-o starScore"></span>';
    }
    componentStr += '</div></div></div>';
    var divv = $("<div>").html(componentStr).css(styleObj);
    for(var i = 0 ; i < defaultscore; i++){
        divv.find(".starScore").eq(i).removeClass("fa-star-o").addClass("fa-star")
    }
    divv.data("key",key);
    divv.find(".starScore").click(function(){
        divv.find(".starScore").removeClass("fa-star").addClass("fa-star-o");
        var num = $(this).index();
        for(var i=0;i<=num;i++){
            divv.find(".starScore").eq(i).removeClass("fa-star-o").addClass("fa-star")
        }
    });
    return divv;
}

/** 九宫格 */
function getGrid(data){
    var key = data.key;
    var gridType = data.val.gridType;
    var gridIconOff = data.val.gridIconOff;
    var styleObj = data.val.styleObj;
    var option = data.val.gridOptions;
    var gridStyleOff = data.val.gridStyleOff;
    var gridBgColor = data.val.gridBgColor;
    var gridFontColor = data.val.gridFontColor;
    var componentStr = '<div class="weui-grids">';
    var items = "";
    for(var i = 0; i < option.length; i ++){
        items += '<a href="javascript:;" class="weui-grid" style="background: '+ option[i].gridBg +'">' +
                    '<div style="padding:10px;margin:0px;" class="weui-grid-inner">' +
                        '<div class="weui-grid__icon"><img src="'+ option[i].gridImage +'"></div>' +
                        '<p class="weui-grid__label divBox_next" style="color: '+ option[i].gridColor +'">'+ option[i].value +'</p>' +
                    '</div>' +
                '</a>'
    }
    componentStr += items;
    componentStr += '</div>';
    var div = $("<div>").html(componentStr).css(styleObj);
    if(!!gridBgColor){
        div.find(".weui-grid-inner").css("background-color",gridBgColor)
    }
    if(!!gridFontColor){
        div.find(".weui-grid-inner p").css("color",gridFontColor)
    }
    if(gridType == 1){
        div.find('.weui-grids a').css("width","33.33333333%");
    }else if(gridType == 2){
        div.find('.weui-grids a').css("width","25%");
    }else if(gridType == 3){
        div.find('.weui-grids a').css("width","50%");
    }else if(gridType == 4){
        div.find('.weui-grids a').css("width","100%");
    }
    if(!!gridIconOff){
        div.find(".weui-grid__icon").css("display","block")
    }else{
        div.find(".weui-grid__icon").css("display","none");
    }
    if(!!gridStyleOff){
        var gridViewStyleObj = data.val.gridViewStyleObj;
        div.find(".weui-grid__icon").css({"width":gridViewStyleObj.width,"height":gridViewStyleObj.height});
        div.find(".weui-grid-inner").css({"padding":gridViewStyleObj.padding,"margin":gridViewStyleObj.margin});
    }
    div.data("key",key);
    return div;

}

/** 底部导航 */
function getNav(data){
    var key = data.key;
    var styleObj = data.val.styleObj;
    var option = data.val.navOption;
    var navDefaultFontColor = data.val.defaultFontColor;
    var navBgColor = data.val.navBgColor;
    var componentStr = '<div class="weui-tabbar">';
    var items = "";
    for(var i = 0; i < option.length; i ++){
        items += '<a href="javascript:;" class="weui-tabbar__item">' +
                    '<span style="display: inline-block;position: relative;">' +
                        '<img src="'+ option[i].defaultImageName +'" alt="" class="weui-tabbar__icon">' +
                        '<span class="weui-badge" style="position: absolute;top: -2px;right: -13px;">8</span>' +
                    '</span>' +
                    '<p class="weui-tabbar__label">'+ option[i].value +'</p>' +
                '</a>'
    }
    componentStr += items;
    componentStr += '</div>';
    var div = $("<div>").html(componentStr).css(styleObj);
    div.find(".weui-tabbar__item p").css("color",navDefaultFontColor);
    div.find(".weui-tabbar").css("background-color",navBgColor);
    div.data("key",key);
    return div;

}

/** 搜索框 */
function getSearch(data){
    var key = data.key;
    var styleObj = data.val.styleObj;
    var tipMsg = data.val.tipMsg;
    var componentStr = '<div class="weui-search-bar">' +
        '<form class="weui-search-bar__form">' +
        '<div class="weui-search-bar__box">' +
        '<i class="weui-icon-search"></i>' +
        '<input type="search" class="weui-search-bar__input" placeholder="搜索" required="" disabled="disabled">' +
        '<a href="javascript:" class="weui-icon-clear" id="searchClear"></a>' +
        '</div>' +
        '<label class="weui-search-bar__label" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">' +
        '<i class="weui-icon-search"></i><span>'+ tipMsg +'</span>' +
        '</label>' +
        '</form>' +
        '<a href="javascript:" class="weui-search-bar__cancel-btn" id="searchCancel">取消</a>' +
        '</div>';

    var div = $("<div>").html(componentStr).css(styleObj);
    div.data("key",key);
    return div;
}

/** 图片 */
function getPicture(data){
    var key = data.key;
    var styleObj = data.val.styleObj;
    var picAddress = data.val.picAddress;
    var viewPicStyle = data.val.gridViewStyleObj;
    var componentStr = '<div class="">' +
                            '<img src="'+ picAddress +'">' +
                        '</div>'
    var div = $("<div>").html(componentStr).css(styleObj);
    if(!!viewPicStyle){
        div.find('img').css(viewPicStyle);
    }
    div.data("key",key);
    return div;
}

module.exports = previewPageLoad;