
require("expose-loader?$!jquery");

require('../utils/global');
require('../utils/prototype');

var temp = require('./temp');
var previewPageLoad = require('./previewPhone');


//重新定义个全局变量
var formTepComArr = temp.GetQueryString("formsg");
formTepComArr= decodeURI(formTepComArr);
console.log(formTepComArr);
var str=window.location.search;
var formset =  str.substring(str.indexOf("&"));
formset=formset.substring(formset.indexOf("=")+1);
formset= decodeURI(decodeURI(formset));
console.log(formset);
if(!!formTepComArr){
  try {
      formTepComArr = JSON.parse(formTepComArr);
      formset =JSON.parse(formset);
  } catch (e) {
      //获取ajax请求 拿到fromJSON
      formTepComArr = temp.getFormMSg(formTepComArr);
  } finally {
      console.log("dfsdsdfs");
      //加到画布中去
      previewPageLoad($("#preview"));
  }
}

//更新Previewlayer的数据
temp.refreshShowJSON(formTepComArr);
