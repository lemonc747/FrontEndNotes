require("expose-loader?$!jquery");
// how dare you?
// require('script-loader!layui-src/dist/layui.all.js');
// require("layui-src/dist/lay/modules/layer");
// require("layui-src/dist/lay/modules/laydate");

// require('@shopify/draggable');
require('./utils/prototype');
// require('./utils/global');