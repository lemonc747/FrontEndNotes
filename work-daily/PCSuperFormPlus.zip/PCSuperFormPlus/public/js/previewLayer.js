function selects(){
    var options = $('.phone_type  option:selected').val();
    console.log(options);
    if(options==1){
        $("#design").css({"width":"360px","height":"640px"});
    }else if(options==2){
        $("#design").css({"width":"480px","height":"854px"});
    }
    else if(options==3){
        $("#design").css({"width":"412px","height":"732px"});
    }
    else if(options==4){
        $("#design").css({"width":"360px","height":"640px"});
    }
    else if(options==5){
        $("#design").css({"width":"411px","height":"823px"});
    }
}

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}

//重新定义个全局变量
var showJsonArr = [];
for(var i= 0; i < parent.formTepComArr.length; i++){
    var showJson = {};
    showJson.key = parent.formTepComArr[i].key;
    showJson.val = parent.formTepComArr[i].val;
    showJsonArr.push(showJson);
}
//获取formset表单设置信息
parent.getFormPreviewMsg();
var formset=parent.formset;
var id = GetQueryString("id");
console.log("-i-",id);
//判断是重模板预览过来的还是点击预览
if(!!GetQueryString("id")){
    var id = GetQueryString("id");
    $("#previewphone").attr("src","../previewIframe/previewphone.html?formsg="+encodeURI(encodeURI(id)));
}else{
    //处理好的数据拼接到手机预览
    $("#previewphone").attr("src","../previewIframe/previewphone.html?formsg="+encodeURI(encodeURI(JSON.stringify(showJsonArr)))+"&formset="+encodeURI(encodeURI(JSON.stringify(formset))));
    refreshShowJSON(showJsonArr);
}


//datepicker设置
for(var i= 0; i < parent.formTepComArr.length; i++){
    if(parent.formTepComArr[i].itemId == 6){
        //console.log(parent.formTepComArr[i].jqObj[0].getElementsByClassName("date_check")[0])
        layui.use('laydate', function(){
            var laydate = layui.laydate;
            //执行一个laydate实例
            laydate.render({
                elem:'.date_check' , //指定元素
                format:parent.formTepComArr[i].val.datatimeformat
            });
        });
    }
}


function refreshShowJSON(data){
  //格式化json     var y = JSON.stringify(msg, null, 4);   这个
  $("#dataJSONContent").append("<textarea id='data' style='width:100%;height:100%' class='info'>" + JSON.stringify(data,null, 4) + "</textarea>"); ;
}
