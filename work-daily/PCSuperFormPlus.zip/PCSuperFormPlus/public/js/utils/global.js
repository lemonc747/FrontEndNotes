/**
 * 全局变量
 */

    // // todo 在各处模板统一后，将统一采用相同的id处理，删除全局ID
    // /**单行输入 */
    // window.SIMPLEINPUT = 0,
    // /**多行输入 */
    // window.TEXTAREA = 1,
    // /**单选框 */
    // window.RADIO = 2,
    // /**多选框 */
    // window.CHECKBOX = 3,
    // /**下拉框 */
    // window.SELECT = 4,
    // /**数字 */
    // window.NUMBER = 5,
    // /**时间日期 */
    // window.DATE = 6,
    // /**勾选框（开关） */
    // window.SWITCH = 7,
    // /**级联(地区级联) */
    // window.CASCADER = 8,
    // /**文本栏 */
    // window.TEXT = 9,
    // /**评分 */
    // window.SCORE = 10,
    // /**分割线 */
    // window.SPLITLINE = 11;

    // function globalFields(){
    //     // 由于require加载的机制，最终还是避不开window，暂行方案
    //     // 也可以采用其他存储方式：storage，cookie，data函数
    //     if(!window._xh_global && typeof window._xh_global !== 'object'){
    //         window._xh_global = {
    
    //             //
    //             formMsgUrl: "http://20.97.6.62:8080/xinghuo-apaas-superform/",
    //             //1任何全局变量都应该在index.js中声明，并写清楚注释
    //             //2任何通用的工具方法都放在utils/common.js中
    //             /**保存全局的组件列表数组
    //              * 1，任何增进组件数据都会相对应变化
    //              * 2，预览和保存表单时对这个字段取值
    //              */
    //             formTepComArr: [],
            
    //             /***当前选中组件的对象
    //              **当前选中的组件对象*
    //             包含jq对象和key值等
    //             */
    //             currentSettingObj: {
    //                 key:    '',
    //                 val:    ''
    //             },
            
    //             /**表单对象 */
    //             formset: {},
            
    //             //当前组件JQ对象
    //             currentComJq: {},
    //         };
    //     }
        
    
    //     return {
    //         getGlobal: function(){
    //             return global;
    //         },
    
    //         getData: function(key){
    //             return global[key];
    //         },
    
    //         setData: function(key, val){
    //             global[key] = val;
    //         },
    //     }
    // }



// 也可以采用其他存储方式：storage，cookie，data函数
var global = {

    // url
    formMsgUrl: "http://20.97.6.62:8080/xinghuo-apaas-superform/",
    //1任何全局变量都应该在index.js中声明，并写清楚注释
    //2任何通用的工具方法都放在utils/common.js中
    /**保存全局的组件列表数组
     * 1，任何增进组件数据都会相对应变化
     * 2，预览和保存表单时对这个字段取值
     */
    formTepComArr: [],

    /***当前选中组件的对象
     **当前选中的组件对象*
    包含jq对象和key值等
    */
    currentSettingObj: {
        key:    '',
        val:    ''
    },

    /**表单对象 */
    formset: {},

    //当前组件JQ对象
    currentComJq: undefined,
};

module.exports = {
    getGlobal: function(){
        return global;
    },

    getData: function(key){
        return global[key];
    },

    setData: function(key, val){
        global[key] = val;
    }
};