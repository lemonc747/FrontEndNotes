/**
 * 全局变量
 * 
 * global模块比较特殊：
 *  1. 主页和iframes的global数据是通用的
 *  2. 加载主页时，刷新数据
 *  3. 加载iframe时，也会重新加载global模块，但是数据不能重新加载
 *  4. sessionStorage不能保证重置数据，因为重新加载或恢复页面仍会保持原来的页面会话
 *  
 * Tips
 *  1. getData和setData需要在对称的位置成对出现，确保数据及时更新
 */

var KEY_GLOBAL = "_xh_global",
    KEY_SELECTED_COMP_INDEX = "selectedCompIndex",
    KEY_COMP_ARRAY = "formTepComArr",
    global = sessionStorage.getItem(KEY_GLOBAL),
    isFrame = window !== window.parent;
global = global && JSON.parse(global);
console.log("global reloading!");
if( !global || typeof global !== 'object' || !isFrame ){
    global = {

        /**保存全局的组件列表数组
         * 1，任何增进组件数据都会相对应变化
         * 2，预览和保存表单时对这个字段取值
         */
        formTepComArr: [],

        // url
        formMsgUrl: "http://20.97.6.62:8080/xinghuo-apaas-superform/",

        //当前选中组件的对象
        currentSettingObj: {
            key:    '',
            val:    ''
        },

        //表单对象
        formset: {},

        //当前组件JQ对象
        currentComJq: undefined,

        // 选中组件index
        selectedCompIndex: 0,

        //组件dom结构
        compsTree: []
    };

    sessionStorage.setItem(KEY_GLOBAL, JSON.stringify(global));
}

module.exports = {
    getGlobal: function(){
        return JSON.parse(sessionStorage.getItem(KEY_GLOBAL));
    },

    getData: function(key){
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL));
        return g[key];
    },

    setData: function(key, val){
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL));
        g[key] = val;
        sessionStorage.setItem(KEY_GLOBAL, JSON.stringify(g));
    },

    getSelected: function(){
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL)),
            index = g[KEY_SELECTED_COMP_INDEX] || 0,
            selected = g[KEY_COMP_ARRAY][index];
        return selected;
    },

    setSelected: function(data){
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL)),
            index = g[KEY_SELECTED_COMP_INDEX] || 0;
        g[KEY_COMP_ARRAY][index] = data;
        sessionStorage.setItem(KEY_GLOBAL, JSON.stringify(g));
    },

    setSelectedIndex: function(index){
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL));
        g[KEY_SELECTED_COMP_INDEX] = index;
        sessionStorage.setItem(KEY_GLOBAL, JSON.stringify(g));
    },

    reset: function(){
        sessionStorage.clear(KEY_GLOBAL);
    },

    /**
     * update组件Dom结构数据
     * note: iframe中$("#pagemain")是取不到的
     */
    updateCompsTree: function(){
        var comps = $("#pagemain>.divBox");
        var arr = [];
        $("#pagemain>.divBox").each(function(index, item){
            var comp = $(this),
                key = comp.data("key"),
                data = {key: key};
            var children = comp.find(".divBox");
            if(children.length>0){
                var cDatas = [];
                children.each(function(){
                    var comp = $(this),
                        key = comp.data("key"),
                        data = {key: key};
                    cDatas.push(data);
                });
                data.children = cDatas;
            }
            arr.push(data);
        });
        // 存储
        var g = JSON.parse(sessionStorage.getItem(KEY_GLOBAL));
        g.compsTree = arr;
        sessionStorage.setItem(KEY_GLOBAL, JSON.stringify(g));
    }
};