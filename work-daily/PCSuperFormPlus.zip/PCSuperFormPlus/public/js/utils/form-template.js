
/**单行输入 */
var SIMPLEINPUT = 0;
/**多行输入 */
var TEXTAREA = 1;
/**单选框 */
var RADIO = 2;
/**多选框 */
var CHECKBOX = 3;
/**下拉框 */
var SELECT = 4;
/**数字 */
var NUMBER = 5;
/**时间日期 */
var DATE = 6;
/**勾选框（开关） */
var SWITCH = 7;
/**级联(地区级联) */
var CASCADER = 8;
/**文本栏 */
var TEXT = 9;
/**评分 */
var SCORE = 10;
/**分割线 */
var SPLITLINE = 11;
/**九宫格 */
var grid = 100;
/**flex布局 */
var flex = 101;
//URL地址
var servecesUrl = "http://20.97.6.62:8080/xinghuo-apaas-superform";
/**
 * 单行输入
 * 多行输入
 * 单选框
 * 多选框
 * 下拉框
 * 数字
 * 时间日期
 * 勾选框
 * 级联(地区级联)
 * 文本栏
 * 评分
 * 分割线
 */
//表单的数据处理
/**表单对象 */
var formset = {};

var TEMPLATE_COMPS = {
    // 组件图标
    grid: ['<div class="xh-components-unit" data-xh-comps-id="{{id}}" data-xh-comps-type="{{type}}">',
        '<i class="fa {{icon}}"></i>',
        '<span>{{name}}</span>',
    '</div>'].join(''),
    type: ["base", "service", "form"]
};

 /**
  * 模板：表单组件
  */
TEMPLATE_COMPS.form_backup = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    // 通过ID取index: TEMPLATE_COMPS.form.id.indexOf(id);
    // id统一为string，因为在设置为data属性时会转为string
    id: ['0','1','2','3','4','5','6','7','8','9','10','11'],
    name: ['SIMPLEINPUT','TEXTAREA','RADIO','CHECKBOX','SELECT','NUMBER','DATE',
        'SWITCH','CASCADER','TEXT','SCORE','SPLITLINE'],
    nameZh: ['单行输入','多行输入','单选框','多选框','下拉框','数字','时间日期',
        '勾选框','地区级联','文本栏','评分','分割线'],
    icon:["fa-minus","fa-bars","fa-dot-circle-o","fa-check-square-o","fa-chevron-down","fa-sort-numeric-asc","fa-calendar",
        "fa-toggle-on","fa-globe","fa-sticky-note-o","fa-star-o","fa-minus-square-o"],
    template: [
        //单行输入
        ['<div class="weui-cells">',
            '<div class="weui-cell">',
            '<div class="weui-cell__bd">',
                '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">',
            '</div>',
            '</div>',
        '</div>'].join(''),
        //多行输入
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<textarea class="weui-textarea component_inputTip"  placeholder="请输入文本" rows="3"></textarea>',
            '<div class="weui-textarea-counter"><span>0</span>/200</div>',
            '</div>',
        '</div>'].join(''),
        //单选
        ['<div class="weui-cells weui-cells_radio" style="margin-top:0px;">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x110">',
            '<div class="weui-cell__bd">',
            '<p>cell standard</p>',
            '</div>',
            '<div class="weui-cell__ft">',
            '<input type="radio" class="weui-check" name="radio1" id="x101">',
            '<span class="weui-icon-checked"></span>',
            '</div>',
            '</label>',
        '</div>'].join(''),
        //多选
        ['<div class="weui-cells weui-cells_checkbox">',
            '<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s110">',
            '<div class="weui-cell__hd">',
            '<input type="checkbox" class="weui-check" name="checkbox1" id="s110" checked="checked">',
            '<i class="weui-icon-checked"></i>',
            '</div>',
            '<div class="weui-cell__bd">',
            '<p>standard is dealt for u.</p>',
            '</div>',
        '</label>'].join(''),
        //下拉框
        ['<div class="weui-cell" style="background-color:#fff">',
            '<input class="weui-input component_inputTip" type="text" value="选项">',
        '</div>'].join(''),
        //数字
        ['<div class="weui-cell"  style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<label for="" class="weui-label component_Name">数字</label>',
            '<input class="weui-input" type="number" pattern="[0-9]*" placeholder="请输入数字">',
            '</div>',
        '</div>'].join(''),
        //日期
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="date" value="">',
            '</div>',
        '</div>'].join(''),
        //勾选框
        ['<label for="weuiAgree" class="weui-agree" style="background-color:#fff">',
            '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">',
            '<span class="weui-agree__text"><span class="component_Name">同意</span>',
            ' <a href="javascript:void(0);"> <span class="component_linkContent">《相关条款》</span></a>',
            '</span>',
        '</label>'].join(''),
        //级联
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<label for="" class="weui-label component_Name">选择地区</label>',
            '<input type="text" class="weui-input component_inputTip" id="city-picker" value="省 市 区/县" />',
            '</div>',
        '</div>'].join(''),
        //文本
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<input class="weui-input component_inputTip" type="text" value="请输入文本">',
            '</div>',
        '</div>'].join(''),
        //评分
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
                // '<span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span>',
                '<span class="fa fa-star"></span><span class="fa fa-star-half-o"></span><span class="fa fa-star-o"></span>',
            '</div>',
        '</div>'].join(''),
        //分割线
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<hr style=""/>',
            '</div>',
        '</div>'].join('')
    ]
}

TEMPLATE_COMPS.form = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    // 通过ID取index: TEMPLATE_COMPS.form.id.indexOf(id);
    // id统一为string，因为在设置为data属性时会转为string
    // id: ['0','1','2','3','4','5','6','7','8','9','10','11'],
    id: ['0','1','2'],
    name: ['SIMPLEINPUT','TEXTAREA','RADIO','CHECKBOX','SELECT','NUMBER','DATE',
        'SWITCH','CASCADER','TEXT','SCORE','SPLITLINE'],
    nameZh: ['单行输入','多行输入','单选框','多选框','下拉框','数字','时间日期',
        '勾选框','地区级联','文本栏','评分','分割线'],
    icon:["fa-minus","fa-bars","fa-dot-circle-o","fa-check-square-o","fa-chevron-down","fa-sort-numeric-asc","fa-calendar",
        "fa-toggle-on","fa-globe","fa-sticky-note-o","fa-star-o","fa-minus-square-o"],
    template: [
        //input
        ['<div class="list-block"><ul><li>',
            '<div class="item-content">',
            '<div class="item-media"><i class="icon icon-form-name"></i></div>',
            '<div class="item-inner">',
                '<div class="item-input">',
                '<input type="text" placeholder="Your name">',
                '</div>',
            '</div>',
            '</div>',
        '</li></ul></div>'].join(''),

        ['<div class="list-block"><ul><li>',
            '<div class="item-content">',
            '<div class="item-media"><i class="icon icon-form-toggle"></i></div>',
            '<div class="item-inner">',
                '<div class="item-title label">开关</div>',
                '<div class="item-input">',
                '<label class="label-switch">',
                    '<input type="checkbox">',
                    '<div class="checkbox"></div>',
                '</label>',
                '</div>',
            '</div>',
            '</div>',
        '</li></ul></div>'].join(''),

        ['<div class="bar bar-header-secondary">',
            '<div class="searchbar">',
            '<a class="searchbar-cancel">取消</a>',
            '<div class="search-input">',
                '<label class="icon icon-search" for="search"></label>',
                '<input type="search" id="search" placeholder="输入关键字..."/>',
            '</div>',
            '</div>',
        '</div>'].join(''),
       
        //分割线
        ['<div class="weui-cell" style="background-color:#fff">',
            '<div class="weui-cell__bd">',
            '<hr style=""/>',
            '</div>',
        '</div>'].join('')
    ]
}

/**
 * 模板：基础组件
 * 
 * 容器组件：子容器标识 `divBox_next`
 */
TEMPLATE_COMPS.base = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    id: ['100','101','102','103','104','105','106','107','108','109'],
    name: ['grid','flex','navbar','tabbar','footer','search','loading','icon','upload','badge',],
    nameZh: ['九宫格','flex布局','导航栏','标签页','页脚','搜索框','加载中','图标','上传','徽章',],
    icon:["fa-th","fa-arrows-alt","fa-navicon","fa-bars","fa-window-minimize","fa-search","fa-spinner","fa-font-awesome","fa-upload","fa-certificate"],
    template: [
        // grid
        ['<div class="weui-grids">',
            common.circleStr('<a href="javascript:;" class="weui-grid"><p class="weui-grid__label divBox_next">Grid</p></a>', 6),
        '</div>'].join(''),
        // flex
        ['<div class="weui-flex">',
            common.circleStr('<div class="weui-flex__item"><div style="margin: 5px;padding: 0 10px;background-color: #ebebeb;height: 2.3em;'+
            'line-height: 2.3em;text-align: center;color: #cfcfcf;">flex</div></div>', 3),
        '</div>'].join(''),
        // navbar
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-navbar">',
                '<div class="weui-navbar__item weui-bar__item_on">选项一</div>',
                '<div class="weui-navbar__item">选项二</div>',
                '<div class="weui-navbar__item">选项三</div>',
            '</div>',
            '<div class="weui-tab__panel">content</div>',
        '</div>'].join(''),
        // tabbar
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-tab__panel">content</div>',
            '<div class="weui-tabbar">',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<span style="display: inline-block;position: relative;">',
                        '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                        '<span class="weui-badge" style="position: absolute;top: -2px;right: -13px;">8</span>',
                    '</span>',
                    '<p class="weui-tabbar__label">微信</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                    '<p class="weui-tabbar__label">通讯录</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item weui-bar__item_on">',
                    '<span style="display: inline-block;position: relative;">',
                        '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                        '<span class="weui-badge weui-badge_dot" style="position: absolute;top: 0;right: -6px;"></span>',
                    '</span>',
                    '<p class="weui-tabbar__label">发现</p>',
                '</a>',
                '<a href="javascript:;" class="weui-tabbar__item">',
                    '<img src="./images/example/icon.png" alt="" class="weui-tabbar__icon">',
                    '<p class="weui-tabbar__label">我</p>',
                '</a>',
            '</div>',
        '</div>'].join(''),
        // footer
        ['<div class="weui-footer">',
            '<p class="weui-footer__links">',
                '<a href="javascript:void(0);" class="weui-footer__link">底部链接</a>',
                '<a href="javascript:void(0);" class="weui-footer__link">底部链接</a>',
            '</p>',
            '<p class="weui-footer__text">Copyright © 2008-2018 xinghuo.io</p>',
        '</div>'].join(''),
        // search
        ['<div class="weui-search-bar" id="searchBar">',
            '<form class="weui-search-bar__form">',
                '<div class="weui-search-bar__box">',
                    '<i class="weui-icon-search"></i>',
                    '<input type="search" class="weui-search-bar__input" id="searchInput" placeholder="搜索" required="">',
                    '<a href="javascript:" class="weui-icon-clear" id="searchClear"></a>',
                '</div>',
                '<label class="weui-search-bar__label" id="searchText" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">',
                   '<i class="weui-icon-search"></i>',
                    '<span>搜索</span>',
                '</label>',
            '</form>',
            '<a href="javascript:" class="weui-search-bar__cancel-btn" id="searchCancel">取消</a>',
        '</div>'].join(''),
        // loading
        ['<div class="weui-loadmore">',
            '<i class="weui-loading"></i>',
            '<span class="weui-loadmore__tips">正在加载</span>',
        '</div>'].join(''),
        // icon
        ['<div class="icon_sp_area">',
            '<i class="weui-icon-success"></i>',
            '<i class="weui-icon-success-no-circle"></i>',
            '<i class="weui-icon-circle"></i>',
            '<i class="weui-icon-warn"></i>',
            '<i class="weui-icon-download"></i>',
            '<i class="weui-icon-info-circle"></i>',
            '<i class="weui-icon-cancel"></i>',
            '<i class="weui-icon-search"></i>',
        '</div>'].join(''),
        // upload
        ['<div class="page__bd page__bd_spacing">',
            '<div class="weui-progress">',
                '<div class="weui-progress__bar">',
                   '<div class="weui-progress__inner-bar js_progress" style="width: 60%;"></div>',
                '</div>',
                '<a href="javascript:;" class="weui-progress__opr">',
                    '<i class="weui-icon-cancel"></i>',
                '</a>',
            '</div>',
            '<div class="weui-btn-area">',
                '<a href="javascript:;" class="weui-btn weui-btn_primary" id="btnUpload">上传</a>',
            '</div>',
        '</div>'].join(''),
        // badge
        ['<div class="weui-cell weui-cell_access">',
            '<div class="weui-cell__bd">',
                '<span style="vertical-align: middle">单行列表</span>',
                '<span class="weui-badge" style="margin-left: 5px;">New</span>',
            '</div>',
            '<div class="weui-cell__ft"></div>',
        '</div>'].join(''),
    ]
}


/**
 * 模板：服务组件
 */
TEMPLATE_COMPS.service = {
    container: '<div class="xh-components-title">{{name}}</div>{{content}}',
    id: ['1000','1001','1002'],
    name: ['upLoadFile','thumbService','commentService'],
    nameZh: ['上传文件','点赞服务','评论服务'],
    icon:["fa-th","fa-arrows-alt","fa-navicon"],
    template: [
        // upLoadFile
        ['<div class="weui-grids">',
            common.circleStr('<a href="javascript:;" class="weui-grid"><p class="weui-grid__label">Grid</p></a>', 6),
        '</div>'].join(''),
        // thumbService
        ['<div class="weui-flex">',
            common.circleStr('<div class="weui-flex__item"><div style="margin: 5px;padding: 0 10px;background-color: #ebebeb;height: 2.3em;'+
            'line-height: 2.3em;text-align: center;color: #cfcfcf;">flex</div></div>', 3),
        '</div>'].join(''),
        // commentService
        ['<div class="weui-tab" style="height:100px;">',
            '<div class="weui-navbar">',
                '<div class="weui-navbar__item weui-bar__item_on">选项一</div>',
                '<div class="weui-navbar__item">选项二</div>',
                '<div class="weui-navbar__item">选项三</div>',
            '</div>',
            '<div class="weui-tab__panel">content</div>',
        '</div>'].join('')
    ]
}


