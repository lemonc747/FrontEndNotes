/**
 * 通用工具类
 * 
 * 要求适用面广，更普遍常见的场景
 * @20180423
 */
var common = {

    // /**
    //  * 遍历：object, array or array-like, $.each的原生实现
    //  * @param {object} array object, array or array-like
    //  * @param {function} callback 对items操作回调函数，参数为index,item
    //  */
    // each: function(array, callback){
    //     // todo 
    //     $.each(array, callback);
    // },

    /**
     * selector及其兄弟节点切换class
     * 1. selector无class，删除所有兄弟节点class，为自己添加class
     * 2. selector有class，删除class，为下一个兄弟节点添加class
     * 3. selector有class，但为最后一个兄弟节点，do nothing
     * 
     * 适用于：tab页切换，手风琴
     * @param {string_or_element} selector 目标节点或它的CSS选择器
     * @param {string} cls 切换的class类名
     * @param {string} condition default:undefined 兄弟节点的筛选条件
     * @param {boolean} self default:false 是否只切换自身class
     */
    toggleClass: function(param){
        var selector    = param.selector,
            cls       = param.cls,
            condition   = param.condition,
            self        = param.self!==undefined? param.selef: false;
        var target = typeof selector === "string" ? 
                document.querySelector(selector) : selector,
            parent = target.parentNode,
            children = condition? parent.querySelectorAll(condition): parent.children;
        var hasClass = target.classList.contains(cls),
            lastIsTarget = false;
        if(self){
            if(target.classList.contains(cls)){
                target.classList.remove(cls);
            }else{
                target.classList.add(cls);
            }
            return;
        }
        this.each(children, function(index, item){
            var isTarget = target === item;
            if((!hasClass && isTarget) || (hasClass && lastIsTarget) ){
                item.classList.add(cls);
            }else if(hasClass && isTarget && children.length-1===index){
                // do nothing
            }else{
                item.classList.remove(cls);
            }
            lastIsTarget = isTarget? true: false;
        });
    },

    /**
     * 生成UUid
     * Fixed bug : document.querySelector can't start with numbers 
     */
    guid: function(){
        return 'xh'+'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
            return v.toString(16);
        });
    },

    /**
     * 解析(非标准)JSON
     */
    parseJSON: function(data){
        var that = this;
        if(data && typeof data === "string"){
            if( (data.startsWith("{") && data.endsWith("}")) 
                || (data.startsWith("[") && data.endsWith("]"))){
                try{
                    data = JSON.parse(data);
                }catch(e){
                    data = eval("("+data+")");
                }
            }
        }
    
        that.each(data, function(index, item){
            data[index] = that.parseJSON(item);
        });
    
        return data;
    },

    /**
     * 遍历对象
     * @param {object} obj target
     * @param {function} callback 对每个遍历元素的回调操作
     * @param {boolean} deep 是否深层递归
     */
    each: function(obj, callback, deep){
        if( !obj || typeof obj !== "object" )
            return;
        var length = obj.length, i=0;
        if( this.isArrayLike(obj)){
            for(; i<length; i++){
                if( callback.call(obj[i], i, obj[i]) === false ){
                    break;
                } 
                if(deep){
                    this.each(obj[i], callback, deep);
                }
            }
        }else{
            for( i in obj){
                if( callback.call(obj[i], i, obj[i]) === false ){
                    break;
                }
                if(deep){
                    this.each(obj[i], callback, deep);
                } 
            }
        }
        return obj;
    },

    /**
     * 数组 or 类数组
     */
    isArrayLike: function(obj){
        var length = !!obj && obj.length;
        //isWindow || isFunction
        if( (obj != null && obj.window === obj) || typeof obj === "function"){
            return false
        }
        return Array.isArray(obj) || length===0 || length>0 && (length-1) in obj;
    },

    /**
     * data
     * @param {boolean} layer 是否弹出加载层
     */
    ajax: function(data){
        var index;
        if(!($ && data && data.url)){
            console.log("JQuery & data & data.url is required!");
            return;
        }
        if( data.layer ){
            index = layer.load(2)
        }
        $.ajax({
            url: data.url,
            data: JSON.stringify(data.data),
            type: data.type || "GET",
            dataType: data.dataType || "json",
            contentType: "application/json;charset=utf-8",
            success: function(result){
                data.success && data.success instanceof Function && data.success(result);
                index && layer.close(index);
            },
            error: function(e){
                data.error && data.error instanceof Function && data.error();
                console.log( console.log("common ajax error || ", e));
                index && layer.close(index);
            }
        });
    }

}


module.exports = common;