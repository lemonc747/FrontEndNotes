/**
 * 通用工具类
 * 
 * 要求适用面广，更普遍常见的场景
 * @20180423
 */
var common = {

    /**
     * 遍历：object, array or array-like, $.each的原生实现
     * @param {object} array object, array or array-like
     * @param {function} callback 对items操作回调函数，参数为index,item
     */
    each: function(array, callback){
        // todo 
        $.each(array, callback);
    },



    /**
     * Class开关： selector元素添加class，其他兄弟节点移除class
     * 
     * 适用于：tab页切换，手风琴
     * @param {string_or_element} selector 目标节点或它的CSS选择器
     * @param {string} cls 切换的class类名
     * @param {boolean} collapse 默认false，是否允许在展开的状态下再次点击，收起并展开下一个兄弟节点，未实现
     */
    toggleClass: function(selector, cls, collapse){
        var target = typeof selector === "string" ? 
                document.querySelector(selector) : selector,
            parent = target.parentNode,
            children = parent.children;
        if(!target.classList.contains(cls)){
            this.each(children, function(index, item){
                item.classList.remove(cls);
            });
            target.classList.add(cls);
        }
    },

    /**生成UUid */
    guid: function(){
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
            return v.toString(16);
        });
    }

}





module.exports = common;