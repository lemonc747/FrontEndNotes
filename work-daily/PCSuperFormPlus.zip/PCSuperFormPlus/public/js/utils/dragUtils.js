/**
 * 拖拽工具类
 * based on Draggable.js
 * @date 20180420
 */
var DragUtils = {

    /**
     * 获取元素的位置：left和top值
     * @param {HTMLDocument} elem 测量的元素
     */
    getPosition: function(elem){
        var left = elem.offsetLeft,
            top = elem.offsetTop,
            parent = elem.offsetParent;
        if(parent){
            var p = this.getPosition(parent);
            left += p.left;
            top += p.top;
        }
        return {left:left, top:top};
    },

    /**
     * 判断鼠标是否在container内
     * 
     * isOverContainer可能是间接触发的，我们无法预测event本身，所以也提供直接传入XY值
     * @param {*} container selector or element
     * @param {*} clientX 
     * @param {*} clientY 
     */
    isOverContainer: function(container, clientX, clientY){
        var con     = typeof container === 'object'? container: document.querySelector(container),
            position = this.getPosition(con),
            left    = position.left,
            right   = left + con.offsetWidth,
            top     = position.top,
            bottom  = top + con.offsetHeight,
            x       = event && event.clientX || clientX,
            y       = event && event.clientY || clientY;

        if( x < right && x > left && y < bottom && y > top){ 
            return true;
        } 
        return false;
    },

    /**
     * 查找
     */
    getTargetBelowCursor: function(selector, clientX, clientY){
        var targets = typeof selector === 'object'? selector: document.querySelectorAll(selector),
            len = targets.length,
            isOverContainer = false;
        for( var i = 0; i<len; i++){
            isOverContainer = this.isOverContainer(targets[i], clientX, clientY);
            if(isOverContainer){
                return targets[i];
            }
        }
    }

};

module.exports = DragUtils;