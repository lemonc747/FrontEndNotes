//手机容器内拖拽
var container = document.getElementById("pagemain");

var option = {
    draggable:".divBox",
    
    handle:".dragHandle",
    delay:100,
};

var dragableSort = new Draggable.Sortable(container,option)
dragableSort.on('sortable:stop', function(event){ 
    console.log('sortable:stop',event);
    var newIndex = event.newIndex;
    var oldIndex = event.oldIndex;
    // console.log(newIndex,oldIndex);
    if(newIndex >= 0 && oldIndex>= 0){
        sortDargUp(newIndex,oldIndex);
    }
});


/**移动排序 
 * 交换数组的两个值
*/
function sortDargUp(index1,index2){
    // console.log(index1,index2);
    var temp;
    temp = formTepComArr[index1];
    formTepComArr[index1] = formTepComArr[index2];
    formTepComArr[index2] = temp;
}