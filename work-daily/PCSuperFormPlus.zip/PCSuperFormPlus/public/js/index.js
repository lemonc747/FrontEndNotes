
require('./component/entry2');
require('./preview/preview');

require('./test/test');

$.when( $.ready ).then(function() {

    //color picker init
    $('#form_bg_color').colorpicker({
        format: "rgba"
    });
    $('#style_font_color').colorpicker({
        format: "rgba"
    });
    $('#style_bg_color').colorpicker({
        format: "rgba"
    });
    $('#style_border_color').colorpicker({
        format: "rgba"
    });
    //属性栏初始化
    $("#sidebar-nav-tabs2").on("click", "li", function(index){
        event.preventDefault();
        var index=$(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $("#tab-content2 .tab-pane").eq(index).addClass("active").siblings().removeClass("active")
    })
});

/**设置全局皮肤 */
layer.config({
    skin: 'custom-class'
});


/***扫描二维码打开微信*/
$(document).on("click","#openApp",function () {
    layer.open({
        type: 1
        ,title: '二维码'
        ,area: ['30%', '50%']
        ,shade: 0.3
        ,maxmin: true
        ,content: '<div class="erweima">'+
                    '<h4 style="margin-top: 60px">请扫描二维码打开app</h4>'+
                    '<div id="qrcode"></div>'+
                    '</div>'
        ,btn: '关闭全部'
        ,btnAlign: 'c' //按钮居中
        ,yes: function(){
            layer.closeAll();
        }
        ,success: function(layero){
            layer.setTop(layero); //重点2
            var qrcode = layer.getChildFrame('#qrcode');
            console.log(qrcode);
            jQuery('#qrcode').qrcode({
                render: "canvas", //也可以替换为table
                width: 100,
                height: 100,
                text: "http://www.baidu.com"
            });
        }
    });
});

$("#exportApp").click(function(event) {
    /* Act on the event */
    var  ajaxParam = {};
    ajaxParam.formId = "87359783181a4c9aa8dcaa38c688eb22";
    $.ajax({
          url:"/pack",
          type: "POST",
          async:false,
          contentType: "application/json;charset=utf-8",
          data: JSON.stringify(ajaxParam),
          dataType: "json",
          success: function(res) {
            console.log(res);
              window.open("http://localhost:13344/"+ res.result.zipName+".zip");
          },
          error: function(msg) {
              console.log("Error:" + msg);
          }
      });
  });