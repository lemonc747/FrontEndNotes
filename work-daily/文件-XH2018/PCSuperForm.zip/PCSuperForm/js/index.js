var formTepComArr=[];





$.when( $.ready ).then(function() {

    


    //color picker init
    $('#form_bg_color').colorpicker();
    $('#style_font_color').colorpicker();
    $('#style_bg_color').colorpicker();
    $('#style_border_color').colorpicker();

    //属性栏初始化
    $("#sidebar-nav-tabs2").on("click", "li", function(index){
        event.preventDefault();
        var index=$(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $("#tab-content2 .tab-pane").eq(index).addClass("active").siblings().removeClass("active")

    })

});












