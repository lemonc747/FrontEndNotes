/**
 * 初始化组件部分
 */
$(function(){

    var $container = $("#xh-container"),
        $sidebar_header = $("#xh-sidebar-header"),
        $sidebar_content = $("#xh-sidebar-content"),
        $sidebar_components = $("#sidebar-components"),
        baseCompsDom = [];

    // event:切换sidebar标签页
    $sidebar_header.on("click", "div[data-xh-content-id]", function(){
        event.preventDefault();
        var content_id = this.getAttribute("data-xh-content-id");//$(this).attr("data-xh-content-id");
        common.toggleClass(this, "active");
        common.toggleClass("#"+content_id, "active");
    });

    // event: 切换components内容块
    $sidebar_components.on("click", ".xh-sidebar-content-header", function(){
        common.toggleClass(this, "active", 1);
    })

    // 初始化components九宫格
    $sidebar_components.find(".sidebar-form-components").append(initCompsDom("form"));
    $sidebar_components.find(".sidebar-base-components").append(initCompsDom("base"));
    //test
//     var test =  ['<div class="weui-flex" style="height:100px;">',
//     common.circleStr('<div class="weui-flex__item"><div style="margin: 5px;padding: 0 10px;background-color: #ebebeb;height: 2.3em;'+
//     'line-height: 2.3em;text-align: center;color: #cfcfcf;">flex</div></div>', 3),
// '</div>'].join('');
//     $sidebar_components.find(".sidebar-base-components").append(test);


    //实现拖拽
    var draggable = new Draggable.Draggable(document.querySelectorAll('#sidebar-components'), {
        draggable: '.xh-components-unit',
    });
    draggable.on('mirror:created', function(evt){
        var target  = evt.originalSource,
            compsId = target.getAttribute("data-xh-comps-id"),
            type    = target.getAttribute("data-xh-comps-type"),
            comps   = TEMPLATE_COMPS[type],
            index   = comps.id.indexOf(compsId),
            dom     = comps.container.replace('{{name}}', comps.nameZh[index]).replace('{{content}}', comps.template[index]);
        $(evt.mirror).empty().addClass("xh-components-unit-mirror").append(dom);
    });
    draggable.on('drag:stop', function(evt){
        var target  = evt.originalSource,
            compsId = target.getAttribute("data-xh-comps-id"),
            type    = target.getAttribute("data-xh-comps-type"),
            tc      = document.querySelector("#pagemain");
        if(DragUtils.isOverContainer("#pagemain", event.detail.data.clientX, event.detail.data.clientY)){
            try{
                if(type==="form"){
                    addCompentBox(parseInt(compsId));
                    conmponentSetting();
                }else{
                    addContainerComponents(compsId, type);
                }
                
            }catch(e){
                console.log("Dragger stop event | error:"+e.message);
            }
            tc.scrollTop = tc.scrollHeight;
        }
    });



    /**
     * 初始化components九宫格
     * @param {string} type 内置类型
     */
    function initCompsDom(type){
        var compsHtml = [],
            temp    = TEMPLATE_COMPS.grid,
            components   = TEMPLATE_COMPS[type],
            id      = components.id,
            name    = components.nameZh,
            icon    = components.icon;
        for(var i=0, length=id.length; i<length; i++){
            compsHtml.push(temp.replace("{{id}}", id[i]).replace("{{name}}",name[i])
                .replace('{{icon}}', icon[i]).replace('{{type}}', type));
        }
        return compsHtml.join('');
    }

    /**
     * 添加组件到预览
     * @param {Number} compsId 
     */
    function addContainerComponents(compsId, type){
        var compStr = TEMPLATE_COMPS[type].template[TEMPLATE_COMPS[type].id.indexOf(compsId)];
        var compEl = createSelectCompentJQ(compStr);
        if(!!compEl){
            compEl.appendTo($("#pagemain"));
            // currentComJq = compEl;
            //组装表单设置项
            assembleSettingMeun(parseInt(compsId));
        }
    }
});