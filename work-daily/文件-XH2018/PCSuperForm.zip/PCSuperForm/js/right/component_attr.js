/**
 * Created by ASUS on 2018/4/19.
 */
/**
 * 组件属性模块
 * */
var currentSettingObj = {};//存放当前选中组件的属性信息
currentSettingObj.key = "";
currentSettingObj.val = '';
/**第一次创建(点击表单项创建的控件) */
function assembleSettingMeun(whichConponet){
    var styleObj={};//用来存储样式
    //currentSettingObj = {};
    //控件所有的属性
    var data = {};
    //每个控件生成唯一的uuid
    var key = guid();
    currentSettingObj = {};
    currentSettingObj.key = key;
    currentSettingObj.val = data;
    currentSettingObj.itemId = whichConponet;
    currentSettingObj.jqObj = currentComJq;
    currentSettingObj.styleObj=styleObj;
    //将key存入jqdiv中
    currentComJq.data("key",key);
    // console.log(currentComJq);
    formTepComArr.push(currentSettingObj);
    SettingMeun(whichConponet);
    //去除其他选中,添加自己选中
    cancelAllSelect();
    addSelect(currentComJq);
}

/**点击已经创建好了的控件 */
function clickHaveSelectCom(data){
    //找到选中的控件的数据
    var whichConponet = data.val.typeNum;
    //设置当前点击对象
    currentSettingObj = data;
    SettingMeun(whichConponet);
}

/**组装表单设置项
 * 根据不同的控件显示相应的表单项控制
 */
function SettingMeun(whichConponet){
    // 选取了一个表单项后自动跳转到表单项设置
    //changeOprateTab(event,2);
    //$("#meunItemSetting").click();
    var data = currentSettingObj.val;
    data.typeNum = whichConponet;
    $("#component_attr_box").html("");
    switch(whichConponet){
        case SIMPLEINPUT:
            data.type = "SIMPLEINPUT";
            componentNameSet();
            componentDescSet();
            componentInputTipSet();
            componentDisabledSet();
            componentNameSetRange();
            break;
        case TEXTAREA:
            data.type = "TEXTAREA";
            componentNameSet();
            componentDescSet();
            componentInputTipSet();
            componentDisabledSet();
            componentNameSetRange();
            break;
        case RADIO:
            data.type = "RADIO";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentOptionRadioSet();
            break;
        case CHECKBOX:
            data.type = "CHECKBOX";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentOptionChecKBoxSet();
            break;
        case SELECT:
            data.type = "SELECT";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentOptionRadioSet();
            break;
        case NUMBER:
            data.type = "NUMBER";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentNameSetRange();
            componentSplitNumberSetRange();
            break;
        case DATE:
            data.type = "DATE";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentCalendarStyle();
            componentNameDateSetRange();
            break;
        case SWITCH:
            data.type = "SWITCH";
            componentNameSet();
            componentDescSet();
            break;
        case CASCADER:
            data.type = "CASCADER";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            break;
        case TEXT:
            data.type = "TEXT";
            componentNameSet();
            componentDescSet();
            break;
        case SCORE:
            data.type = "SCORE";
            componentNameSet();
            componentDescSet();
            componentDisabledSet();
            componentScoreSetRange();
            break;
        case SPLITLINE:
            data.type = "SPLITLINE";
            componentSplitLineSetRange();
            break;
        default:
            break;
    }
}

/**表单项名称设置 */
function componentNameSet(){
    var str='<div class="form-group col-md-12" style="margin-top: 10px">'+
                '<label class="col-md-12 control-label">表单项名称</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control" placeholder="请输入表单名称">'+
                '</div>'+
            '</div>';
    var jqObj = createCompentJQ(str);
    //默认值
    currentSettingObj.val.label = '名称';
    jqObj.find("input").change(function(e){
        var result = $(this).val();
        if(!!result){
            currentSettingObj.val.label = result;
            currentSettingObj.jqObj.find(".component_Name").text(result);
        }
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**表单项描述设置 */
function componentDescSet(){
    var str='<div class="form-group col-md-12">'+
                '<label class="col-md-12 control-label">表单项描述</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control" placeholder="">'+
                '</div>'+
            '</div>';
    var jqObj = createCompentJQ(str);
    jqObj.find("input").change(function(){
        var result = $(this).val();
        currentSettingObj.val.decs = result;
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**表单项输入提示设置 */
function componentInputTipSet(){
    var str='<div class="form-group col-md-12">'+
                '<label class="col-md-12 control-label">表单项输入提示</label>'+
                '<div class="col-md-12">'+
                    '<input type="text" class="form-control" placeholder="请输入提示语">'+
                '</div>'+
            '</div>';
    var jqObj = createCompentJQ(str);
    //默认值
    currentSettingObj.val.placeholder = '请输入';
    jqObj.find("input").change(function(e){
        var result = $(this).val();
        if(!!result){
            currentSettingObj.val.placeholder = result;
            currentSettingObj.jqObj.find(".component_inputTip").attr("placeholder",result);
        }
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**表单项控制 */
function componentDisabledSet(){
    var str= '<div class="form-group col-md-12">'+
                 '<label class="col-md-12 control-label">表单项控制</label>'+
                 '<div class="col-md-12">' +
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox"> 禁用'+
                         '</label>'+
                     '</div>'+
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox"> 只读'+
                         '</label>'+
                     '</div>'+
                     '<div class="checkbox">'+
                         '<label>'+
                             '<input type="checkbox" checked> 必填'+
                         '</label>'+
                     '</div>'+
                 '</div>'+
             '</div>';
    var jqObj = createCompentJQ(str);
    //默认值
    currentSettingObj.val.disable = false;
    currentSettingObj.val.readonly = false;
    currentSettingObj.val.required = true;
    $(jqObj.find("input")[0]).change(function(){
        console.log($(this).prop('checked'));
        currentSettingObj.val.disable = $(this).prop('checked');
    });
    $(jqObj.find("input")[1]).change(function(){
        console.log($(this).prop('checked'));
        currentSettingObj.val.readonly = $(this).prop('checked');
    });
    $(jqObj.find("input")[2]).change(function(){
        console.log($(this).prop('checked'));
        currentSettingObj.val.required = $(this).prop('checked');
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**单行多行输入--表单项范围 */
function componentNameSetRange(){
    var str = '<div class="form-group col-md-12">'+
                  '<label class="col-md-12 control-label">表单项范围</label>'+
                  '<div class="col-md-12">'+
                      '<p>最小字符数</p>'+
                      '<input type="text" class="form-control minNumber">'+
                  '</div>'+
                  '<div class="col-md-12">'+
                      '<p>最大字符数</p>'+
                      '<input type="text" class="form-control maxNumber">'+
                  '</div>'+
              '</div>';
    var jqObj = createCompentJQ(str);
    //默认
    currentSettingObj.val.minnumber = 20;
    currentSettingObj.val.maxnumber = 200;
    jqObj.find("input.minNumber").change(function(e){
        var result = $(this).val();
        //最少字符数
        currentSettingObj.val.minnumber = result;
    });
    jqObj.find("input.maxNumber").change(function(e){
        var result = $(this).val();
        //最多字符数
        currentSettingObj.val.maxnumber = result;
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**添加option选项 单选*/
function createOptionRidaoItem(isRadio){
    var id = new Date().getTime();
    var optionItem = '<div class="weui-cell addradiobox col-md-12">' +
                        '<label for="iAgree1'+id+'">'+
                            '<input id= "iAgree1'+id+'" type="radio" name="radio1">'+
                        '</label>'+
                        '<div class="col-md-9" style="background-color:#fff">'+
                            '<input class="form-control value" type="text" placeholder="选项">'+
                        '</div>'+
                        '<label class="col-md-3">'+
                            '<span class="text-center optionsAddBox" style="display: inline-block;width:50%;background:#ccc">+ </span>'+
                            '<span class="text-center optionsRemoveBox" style="display: inline-block;width:50%;background:#ccc"> -</span>'+
                        '</label>'+
                    '</div>';
    var item = $("<div>").html(optionItem).children().data("id",id);
    //数据
    var obj = {};
    obj.id = id;
    obj.value = "选项";
    obj.selected = false;
    currentSettingObj.val.options.push(obj);
    item.find(".optionsAddBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        var newItem = createOptionRidaoItem();
        newItem.insertAfter(item);
    });
    item.find(".optionsRemoveBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        var id = $(this).parents(".addradiobox").data("id");
        console.log("id",id);
        var tempArr = [];
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id != id){
                tempArr.push(currentSettingObj.val.options[i]);
            }
        }
        currentSettingObj.val.options = tempArr;
        item.remove();
    });
    $(item.find("input")[0]).change(function(){
        var result = $(this).val();
        var id = $(this).parents(".addradiobox").data("id");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].selected = $(this).is(":checked");
            }
        }
        // currentSettingObj.val.decs = result;
    });
    $(item.find("input")[1]).change(function(){
        var result = $(this).val();
        var isChecked = $(item.find("input")[0]).is(":checked");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].value = result;
            }
        }
    });
    return item;
}
/**单选框--表单项范围 */
//表单项单选框option数组数据
function componentOptionRadioSet(){
    var str = '<div class="form-group col-md-12">'+
                  '<h4 class="col-md-12 control-label">表单项范围</h4>'+
              '</div>';

    var jqObj = $("<div>").html(str).children();
    currentSettingObj.val.options = [];
    var item = createOptionRidaoItem();
    item.appendTo(jqObj);
    //默认
    jqObj.appendTo($("#component_attr_box"));
}
/**添加option选项 复选框*/
function createOptionCheckBoxItem(){
    var id = new Date().getTime();
    var optionItem = '<div class="weui-cell addradiobox col-md-12">' +
                         '<label for="iAgree1'+id+'">'+
                             '<input id= "iAgree1'+id+'" type="checkbox">'+
                         '</label>'+
                         '<div class="col-md-9" style="background-color:#fff">'+
                             '<input class="form-control value" type="text" placeholder="选项">'+
                         '</div>'+
                         '<label class="col-md-3">'+
                             '<span class="text-center optionsAddBox" style="display: inline-block;width:50%;background:#ccc">+ </span>'+
                             '<span class="text-center optionsRemoveBox" style="display: inline-block;width:50%;background:#ccc"> -</span>'+
                         '</label>'+
                     '</div>';
    var item = $("<div>").html(optionItem).children().data("id",id);
    //数据
    var obj = {};
    obj.id = id;
    obj.value = "选项";
    obj.selected = false;
    currentSettingObj.val.options.push(obj);
    item.find(".optionsAddBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        var newItem = createOptionCheckBoxItem();
        newItem.insertAfter(item);
    });
    item.find(".optionsRemoveBox").click(function(e){
        var item =  $(this).parents(".addradiobox");
        var id = $(this).parents(".addradiobox").data("id");
        console.log("id",id);
        var tempArr = [];
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id != id){
                tempArr.push(currentSettingObj.val.options[i]);
            }
        }
        currentSettingObj.val.options = tempArr;
        item.remove();
    });
    $(item.find("input")[0]).change(function(){
        var result = $(this).val();
        var id = $(this).parents(".addradiobox").data("id");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].selected = $(this).is(":checked");
            }
        }
        // currentSettingObj.val.decs = result;
    });
    $(item.find("input")[1]).change(function(){
        var result = $(this).val();
        var isChecked = $(item.find("input")[0]).is(":checked");
        for(var i = 0;i < currentSettingObj.val.options.length;i++){
            if(currentSettingObj.val.options[i].id == id){
                currentSettingObj.val.options[i].value = result;
            }
        }
    });
    return item;
}
/**复选框--表单项范围 */
//表单项单选框option数组数据
function componentOptionChecKBoxSet(){
    var str = '<div class="form-group col-md-12">'+
                  '<h4 class="col-md-12 control-label">表单项范围</h4>'+
              '</div>';
    var jqObj = $("<div>").html(str).children();
    currentSettingObj.val.options = [];
    var item = createOptionCheckBoxItem();
    item.appendTo(jqObj);
    //默认
    jqObj.appendTo($("#component_attr_box"));
}
/**数字类型--表单项范围*/
function componentSplitNumberSetRange(){
    var str = '<div class="form-group col-md-12">'+
                    '<label class="col-md-12 control-label">数字类型</label>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option selected>请选择数字类型</option>'+
                            '<option value="电话号码">电话号码</option>'+
                            '<option value="邮政编码">邮政编码</option>'+
                            '<option value="身份证号码">身份证号码</option>'+
                            '<option value="条码">条码</option>'+
                        '</select>'+
                    '</div>'+
                '</div>';
    var jqObj = createCompentJQ(str);
    jqObj.find("select").change(function(e){
        var result = $(this).val();
        //数字类型
        currentSettingObj.val.numbertype = result;
    });

    jqObj.appendTo($("#component_attr_box"));
}
/**时间日期--表单项范围*/
function componentNameDateSetRange(){
    var str = '<div class="form-group col-md-12">'+
                  '<label class="col-md-12 control-label">时间/日期格式</label>'+
                  '<div class="col-md-12">'+
                      '<select class="form-control">' +
                          '<option selected>请选择格式</option>'+
                          '<option value="年-月-日">年-月-日</option>'+
                          '<option value="年-月">年-月</option>'+
                          '<option value="月-日">月-日</option>'+
                      '</select>'+
                  '</div>'+
            '</div>';
    var jqObj = createCompentJQ(str);
    //默认
    currentSettingObj.val.datatimeformat = "yyyy-MM-dd hh:mm:ss";
    jqObj.find("select").change(function(e){
        var result = $(this).val();
        if(result == "年-月-日"){
            currentSettingObj.val.datatimeformat = "yyyy-MM-dd";
        }
        if(result == "年-月"){
            currentSettingObj.val.datatimeformat = "yyyy-MM";
        }
        if(result == "月-日"){
            currentSettingObj.val.datatimeformat = "MM-dd";
        }
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**日期选择样式  日历*/
function componentCalendarStyle(){
    var str = '<div class="form-group col-md-12">' +
                  '<label class="col-md-12 control-label">是否日历样式</label>'+
                  '<div class="col-md-12">' +
                      '<input id="weuiAgree222" type="checkbox" checked>'+
                      '<span style="color: #999">'+
                      '   日历样式'+
                      '</span>'+
                  '</div>'+
              '</div>';
    var jqObj = createCompentJQ(str);
    //默认值
    currentSettingObj.val.isCalendar = true;
    jqObj.find("input").change(function(){
        console.log($(this).prop('checked'));
        currentSettingObj.val.isCalendar = $(this).prop('checked');
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**评分--表单项范围 */
function componentScoreSetRange(){
    var str =   '<div class="form-group col-md-12">'+
                    '<label class="col-md-12 control-label">表单项范围</label>'+
                    '<div class="col-md-12">评分尺度：</div>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option value="5星" selected>5星</option>'+
                            '<option value="10星">10星</option>'+
                        '</select>'+
                    '</div>'+
                    '<div class="col-md-12">默认评分：</div>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option value="0星">0星</option>'+
                            '<option value="1星">1星</option>'+
                            '<option value="2星">2星</option>'+
                            '<option value="3星" selected>3星</option>'+
                            '<option value="4星">4星</option>'+
                            '<option value="5星">5星</option>'+
                            '<option value="6星">6星</option>'+
                            '<option value="7星">7星</option>'+
                            '<option value="8星">8星</option>'+
                            '<option value="9星">9星</option>'+
                            '<option value="10星">10星</option>'+
                        '</select>'+
                    '</div>'+
                '</div>';

    var jqObj = createCompentJQ(str);
    //默认值 3 星
    currentSettingObj.val.defaultscore = 3;
    jqObj.find("select")[0].change(function(e){
        var result = $(this).val();
        //评分尺度
        currentSettingObj.val.gradingscale = result;
    });
    jqObj.find("select")[1].change(function(e){
        var result = $(this).val();
        result=result.split("星")[0];
        //默认评分
        currentSettingObj.val.defaultscore = result;
    });
    $(jqObj.find("input")[2]).change(function(){
        console.log($(this).prop('checked'));
        currentSettingObj.val.support = $(this).prop('checked');
    });
    jqObj.appendTo($("#component_attr_box"));
}
/**分割线--表单项范围*/
function componentSplitLineSetRange(){
    var str =   '<div class="form-group col-md-12" style="margin-top: 10px">'+
                    '<label class="col-md-12 control-label">分割线样式</label>'+
                    '<div class="col-md-12">'+
                        '<select class="form-control">' +
                            '<option selected>请选择分割线</option>'+
                            '<option value="实线">实线</option>'+
                            '<option value="虚线">虚线</option>'+
                            '<option value="点线">点线</option>'+
                        '</select>'+
                    '</div>'+
                '</div>';
    var jqObj = createCompentJQ(str);
    //默认值为实线
    currentSettingObj.val.splitline = "solid";
    jqObj.find("select").change(function(e){
        var result = $(this).val();
        if (result=="实线"){
            result = "solid";
        }else if(result=="虚线"){
            result = "dashed";
        }
        else if(result=="点线"){
            result = "dotted";
        }
        //分割线样式
        currentSettingObj.val.splitline = result;
    });

    jqObj.appendTo($("#component_attr_box"));
}