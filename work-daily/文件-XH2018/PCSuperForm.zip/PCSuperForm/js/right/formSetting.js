/**
 * Created by ASUS on 2018/4/13.
 */
var a={};
var down=true;//用来进行下一步表单验证的条件
/** 表单头部显示*/
function formTitleShow(){
    var formHeadShow=$('#page_setting .formHeadShow option:selected').val();
    //formset.formHeadShow=formHeadShow;
    a.formHeadShow=formHeadShow
}
formTitleShow()
/** 表单名称*/
function formName(){
    var formName=$('#page_setting .formTitle').val();
    if(formName == undefined || formName == ""){
        formName="名称未定义"
    }
    //formset.formName=formName;
    a.formName=formName;
}
/** 表单描述*/
function formDesc(){
    var formDesc=$('#page_setting .formDesc').val();
    if(formDesc == undefined || formDesc == ""){
        formDesc="描述未定义"
    }
    //formset.formDesc=formDesc;
    a.formDesc=formDesc;
}
/** 表单背景色*/
function formBgColor(){
    var formBgcolor=$('#page_setting .color').val();
    //formset.formBgcolor=formBgcolor;
    a.formBgcolor=formBgcolor;
}
/** 每个用户提交数据限制次数*/
function subCount(){
    var subCount=$('#page_setting .subCount').val();
    if(subCount != ""){
        //formset.subCount=subCount;
        a.subCount=subCount;
    }else{
        return false
    }
}
/** 数据提交通知邮箱地址*/
function subNoticeEmail(){
    var subNoticeEmail=$('#page_setting .subNoticeEmail').val();
    if(subNoticeEmail != ""){
        var re = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$"); //正则表达式
        if(!re.test(subNoticeEmail)){
            alert("邮箱地址格式有误!");
            down=false;
            return false
        }else{
            //formset.subNoticeEmail=subNoticeEmail;
            a.subNoticeEmail=subNoticeEmail;
        }
    }else{
        return false
    }
}
/** 数据提交通知手机号*/
function subNoticePhone(){
    var subNoticePhone=$('#page_setting .subNoticePhone').val();
    if(subNoticePhone != "") {
        var re = /^1[34578]\d{9}$/g;
        if (!re.test(subNoticePhone)) {
            alert("号码格式有误");
            down=false;
            return false
        } else {
            //formset.subNoticePhone=subNoticePhone;
            a.subNoticePhone=subNoticePhone;
        }
    }else {
        return false
    }
}
/** 表单访问口令*/
function formToken(){
    var formToken=$('#page_setting .formToken').val();
    if(formToken != ""){
        //formset.formToken=formToken;
        a.formToken=formToken;
    }else{
        return false
    }
}
/** 表单提交跳转链接*/
function subUrl(){
    var subUrl=$('#page_setting .subUrl').val();
    if(subUrl != "") {
        var re=/^([hH][tT]{2}[pP]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)(([A-Za-z0-9-~]+)\.)+([A-Za-z0-9-~\/])+$/;
        if (!re.test(subUrl)) {
            alert("这网址不是以http://或https://开头，或者不是网址！");
            down=false;
            return false
        } else {
            //formset.subUrl=subUrl;
            a.subUrl=subUrl;
        }
    }else {
        return false
    }
}
/** number表单禁止输入E(处理number表单能输入e的问题)*/
$('#page_setting').find('input[type=number]').keypress(function(e) {
    if (!String.fromCharCode(e.keyCode).match(/[0-9.]/)) {
        return false;
    }
});
/** number表单设置为只能输入正整数)*/
$('#page_setting').find('input[type=number]').keyup(function(e) {
    this.value=this.value.replace(/\D/g,'')
});



