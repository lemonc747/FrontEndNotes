/**
 * Created by ASUS on 2018/4/20.
 */
/** 初始化组件样式 */
//var initStyleObj={
//    "textAlign":"center",
//    "verticalAlign":"middle",
//    "fontFamily":"宋体",
//    "fontSize":[100,"px"],
//    "fontWeight":"bold",
//    "fontStyle":"italic",
//    "textDecoration":"",
//    "fontColor":"#c2c2c2",
//    "backgroundColor":"#9c1c1c",
//    "backgroundImage":"",
//    "opacity":[100,"%"],
//    "borderStyle":"double",
//    "borderWidth":[],
//    "borderColor":"",
//    "borderRadius":[],
//    "letterSpacing":[],
//    "lineHeight":[],
//    "zIndex":"",
//    "paddingTop":[],
//    "paddingBottom":[],
//    "paddingLeft":[],
//    "paddingRight":[],
//    "marginTop":[],
//    "marginBottom":[],
//    "marginLeft":[],
//    "marginRight":[],
//    "overflow":"scroll"
//};
function styleInit(){
    $('#component_style .textAlign').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#component_style .verticalAlign').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#component_style .fontFamily option').eq(0).prop("selected",true);
    valueUnitInit(".fontSize","",".fontSizeUnit","px");
    $('#component_style .textStyle').find('button').removeClass('btn-primary').addClass('btn-default');
    $('#style_font_color input').prop('value','#cccccc');
    $('#style_font_color i').css('backgroundColor','#cccccc');
    $('#style_bg_color input').prop('value','#ffffff');
    $('#style_bg_color i').css('backgroundColor','#ffffff');
    valueUnitInit(".opacity","",".opacityUnit","%");
    $('#component_style .borderStyle option').eq(0).prop('selected',true);
    valueUnitInit(".borderWidth","",".borderWidthUnit","px");
    $('#style_border_color input').prop('value','#ffffff');
    $('#style_border_color i').css('backgroundColor','#cccccc');
    valueUnitInit(".borderRadius","",".borderRadiusUnit","%");//圆角
    valueUnitInit(".letterSpacing","",".letterSpacingUnit","%");//字间距
    $('#component_style .lineHeight').prop('value',"");//字行高
    $('#component_style .zIndex').prop('value',"");//层级
    valueUnitInit(".paddingTop","",".paddingTopUnit","px");
    valueUnitInit(".paddingBottom","",".paddingBottomUnit","px");
    valueUnitInit(".paddingLeft","",".paddingLeftUnit","px");
    valueUnitInit(".paddingRight","",".paddingRightUnit","px");
    valueUnitInit(".marginTop","",".marginTopUnit","px");
    valueUnitInit(".marginBottom","",".marginBottomUnit","px");
    valueUnitInit(".marginLeft","",".marginLeftUnit","px");
    valueUnitInit(".marginRight","",".marginRightUnit","px");
    $('#component_style .overflow option').eq(0).prop('selected',true);
};
/** 组件样式回流 */
function styleRuturn(styleObj){
    for(var i in styleObj){
        if(i == "textAlign"){
            var textAlign= styleObj[i];
            $('#component_style .textAlign').find("button[data-value =" +textAlign+"]").removeClass("btn-default").addClass("btn-primary");
        }
        if(i == "verticalAlign"){
            var verticalAlign= styleObj[i];
            $('#component_style .verticalAlign').find("button[data-value =" +verticalAlign+"]").removeClass("btn-default").addClass("btn-primary");
        }
        if(i == "fontFamily"){
            var fontFamily=styleObj[i];
            $('#component_style .fontFamily').val(styleObj[i]);
        }
        if(i == "fontSize"){
            $('#component_style .fontSize').val(styleObj[i][0]);
            $('#component_style .fontSizeUnit').val(styleObj[i][1]);
        }
        if(i == "fontWeight"){
            $('#component_style .textStyle .fontWeight').removeClass('btn-default').addClass('btn-primary');
            console.log("fontWeight");
        }
        if(i == "fontStyle"){
            $('#component_style .textStyle .fontStyle').removeClass('btn-default').addClass('btn-primary');
            console.log("fontWeight");
        }if(i == "textDecoration"){
            $('#component_style .textStyle .textDecoration').removeClass('btn-default').addClass('btn-primary');
            console.log("fontWeight");
        }
        if(i == "fontColor"){
            $('#style_font_color input').val(styleObj[i]);
            $('#style_font_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "backgroundColor"){
            $('#style_bg_color input').val(styleObj[i]);
            $('#style_bg_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "opacity"){
            $('#component_style .opacity').val(styleObj[i][0]);
            $('#component_style .opacityUnit').val(styleObj[i][1]);
        }
        if(i == "borderStyle"){
            $('#component_style .borderStyle').val(styleObj[i]);
        }
        if(i == "borderWidth"){
            $('#component_style .borderWidth').val(styleObj[i][0]);
            $('#component_style .borderWidthUnit').val(styleObj[i][1]);
        }
        if(i == "borderColor"){
            $('#style_border_color input').val(styleObj[i]);
            $('#style_border_color i').css("backgroundColor",styleObj[i]);
        }
        if(i == "borderRadius"){
            $('#component_style .borderRadius').val(styleObj[i][0]);
            $('#component_style .borderRadiusUnit').val(styleObj[i][1]);
        }
        if(i == "borderWidth"){
            $('#component_style .letterSpacing').val(styleObj[i][0]);
            $('#component_style .letterSpacingUnit').val(styleObj[i][1]);
        }
        if(i == "lineHeight"){
            $('#component_style .lineHeight').val(styleObj[i][0]);
            $('#component_style .lineHeightUnit').val(styleObj[i][1]);
        }
        if(i == "zIndex"){
            $('#component_style .zIndex').val(styleObj[i]);
        }
        if(i == "paddingTop"){
            $('#component_style .paddingTop').val(styleObj[i][0]);
            $('#component_style .paddingTopUnit').val(styleObj[i][0]);
        }
        if(i == "paddingBottom"){
            $('#component_style .paddingBottom').val(styleObj[i][0]);
            $('#component_style .paddingBottomUnit').val(styleObj[i][0]);
        }
        if(i == "paddingLeft"){
            $('#component_style .paddingLeft').val(styleObj[i][0]);
            $('#component_style .paddingLeftUnit').val(styleObj[i][0]);
        }
        if(i == "paddingRight"){
            $('#component_style .paddingRight').val(styleObj[i][0]);
            $('#component_style .paddingRightUnit').val(styleObj[i][0]);
        }
        if(i == "marginTop"){
            $('#component_style .marginTop').val(styleObj[i][0]);
            $('#component_style .marginTopUnit').val(styleObj[i][0]);
        }
        if(i == "marginBottom"){
            $('#component_style .marginBottom').val(styleObj[i][0]);
            $('#component_style .marginBottomUnit').val(styleObj[i][0]);
        }
        if(i == "marginLeft"){
            $('#component_style .marginLeft').val(styleObj[i][0]);
            $('#component_style .marginLeftUnit').val(styleObj[i][0]);
        }
        if(i == "marginRight"){
            $('#component_style .marginRight').val(styleObj[i][0]);
            $('#component_style .marginRightUnit').val(styleObj[i][0]);
        }
        if(i == 'overflow'){
            $('#component_style .overflow').val(styleObj[i]);
        }
    }
}
/** 初始化值+单位的输入框组 */
function valueUnitInit(first,val,second,unit){
    $('#component_style '+first).prop('value',val);
    $('#component_style '+second).prop('value',unit);
}
/** 拖拽成功后右边栏切换 */
function conmponentSetting(){
    $("#page_setting").addClass("hide");
    $("#componentSetting").removeClass("hide");
    styleInit();
}
