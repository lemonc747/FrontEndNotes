/**
 * Created by ASUS on 2018/4/19.
 */
/**
 * 组件样式获取
 * */

/** 获取水平对齐 */
function getStyleObj(selectObjData){
    var selectStyleObj = selectObjData;
    $('#component_style .textAlign').find('button').unbind("click").click(function(){
        var textAlign = $(this).data('value');
        $(this).removeClass('btn-default').addClass('btn-primary').siblings().removeClass('btn-primary');
        selectStyleObj["textAlign"]=textAlign;
    });
    /** 获取垂直对齐 */
    $("#component_style .verticalAlign").find('button').unbind("click").click(function(){
        var verticalAlign = $(this).data('value');
        $(this).removeClass('btn-default').addClass('btn-primary').siblings().removeClass('btn-primary');
        selectStyleObj["verticalAlign"]=verticalAlign;
    });
    /** 获取字体 */
    $("#component_style .fontFamily").unbind("change").change(function(){
        var fontFamily = $('.fontFamily option:selected').val();
        selectStyleObj["fontFamily"]=fontFamily;
    });
    /** 获取字体大小和单位 */
    getValueUnit(".fontSize",".fontSizeUnit","fontSize");
    /** 获取字体风格 */
    $("#component_style .textStyle").find('button').unbind("click").click(function(){
        if($(this).hasClass('btn-default')){
            $(this).removeClass('btn-default').addClass('btn-primary');
            if($(this).index()==0){
                var fontWeight=$(this).data('value');
                selectStyleObj["fontWeight"]=fontWeight;
            }else if($(this).index()==1){
                var fontStyle=$(this).data('value');
                selectStyleObj["fontStyle"]=fontStyle;
            }else if($(this).index()==2){
                var textDecoration=$(this).data('value');
                selectStyleObj["textDecoration"]=textDecoration;
            }
        }else{
            $(this).removeClass('btn-primary').addClass('btn-default');
            if($(this).index()==0){
                delete selectStyleObj["fontWeight"]
            }else if($(this).index()==1){
                delete selectStyleObj["fontStyle"]
            }else if($(this).index()==2){
                delete selectStyleObj["textDecoration"]
            }
        }
        
    });
    /** 获取字体颜色*/
    getColorpickerValue("#style_font_color","fontColor");
    /** 获取背景颜色*/
    getColorpickerValue("#style_bg_color","backgroundColor");
    /** 背景图片 */

    /** 透明度和单位 */
    getValueUnit(".opacity",".opacityUnit","opacity");
    /** 获取边框样式 */
    $("#component_style .borderStyle").unbind("change").change(function(){
        var borderStyle = $('.borderStyle option:selected').val();
        selectStyleObj["borderStyle"]=borderStyle;
        
    });
    /** 边框宽度和单位 */
    getValueUnit(".borderWidth",".borderWidthUnit","borderWidth");
    /** 获取边框颜色*/
    getColorpickerValue("#style_border_color","borderColor");
    /** 边框圆角和单位 */
    getValueUnit(".borderRadius",".borderRadiusUnit","borderRadius");
    /** 字间距和单位 */
    getValueUnit(".letterSpacing",".letterSpacingUnit","letterSpacing");
    /** 字行高和单位 */
    getValueUnit(".lineHeight",".lineHeightUnit","lineHeight");
    /** 层级 */
    $("#component_style .zIndex").unbind("change").change(function(){
        var zIndex = $(this).val();
        selectStyleObj["zIndex"]=zIndex;
        
    });
    /** 上内边距和单位 */
    getValueUnit(".paddingTop",".paddingTopUnit","paddingTop");
    /** 下内边距和单位 */
    getValueUnit(".paddingBottom",".paddingBottomUnit","paddingBottom");
    /** 左内边距和单位 */
    getValueUnit(".paddingLeft",".paddingLeftUnit","paddingLeft");
    /** 右内边距和单位 */
    getValueUnit(".paddingRight",".paddingRightUnit","paddingRight");
    /** 上外边距和单位 */
    getValueUnit(".marginTop",".marginTopUnit","marginTop");
    /** 下外边距和单位 */
    getValueUnit(".marginBottom",".marginBottomUnit","marginBottom");
    /** 左外边距和单位 */
    getValueUnit(".marginLeft",".marginLeftUnit","marginLeft");
    /** 右外边距和单位 */
    getValueUnit(".marginRight",".marginRightUnit","marginRight");
    /** 超过范围 */
    $("#component_style .overflow").unbind("change").change(function(){
        var overflow = $('.overflow option:selected').val();
        selectStyleObj["overflow"]=overflow;
        
    });
    /** 用来获取颜色拾取器的值得方法 */
    function getColorpickerValue(obj,key){//input框父元素的id选择器;selectStyleObj的属性名;
        $(obj).find('input').unbind("change").change(function(){
            var styleColor = $(this).val();
            selectStyleObj[key]=styleColor;
            
        });
    }
    /** 用来获取数值+单位的方法 */
    function getValueUnit(first,second,key){//第一个框的class选择器;第一个框的class选择器;selectStyleObj的属性名;
        $("#component_style "+first).unbind("change").change(function(){
            var style_unit =$('#component_style '+ second).val();//单位
            var style_value = $(this).val();
            selectStyleObj[key]=[style_value,style_unit];
            
        });
        $("#component_style "+second).unbind("change").change(function(){
            var style_unit =$(this).val();//单位
            var style_value =$('#component_style '+first).val();
            selectStyleObj[key]=[style_value,style_unit];
            
        });
    }
}


