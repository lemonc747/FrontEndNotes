/**
 * 拖拽工具类
 * based on Draggable.js
 * @date 20180420
 */
var DragUtils = {};

DragUtils.dragInit = function(options){

}


/**
 * 判断鼠标是否在container内
 * 
 * isOverContainer可能是间接触发的，我们无法预测event本身，所以也提供直接传入XY值
 * @param {*} container 
 * @param {*} clientX 
 * @param {*} clientY 
 */
DragUtils.isOverContainer = function(container, clientX, clientY){
    var con     = document.querySelector(container),
        position = getPosition(con),
        left    = position.left,
        right   = left + con.offsetWidth,
        top     = position.top,
        bottom  = top + con.offsetHeight,
        x       = event.clientX || clientX,
        y       = event.clientY || clientY;


    if( x < right && x > left && y < bottom && y > top){ 
        return true;
    } 
    return false;

    function getPosition(elem){
        var left = elem.offsetLeft,
            top = elem.offsetTop,
            parent = elem.offsetParent;
        if(parent){
            var p = getPosition(parent);
            left += p.left;
            top += p.top;
        }
        return {left:left, top:top};
    }
}
