
/**添加控件  点击事件**/
function addCompentBox(whichCompent){
    var jq;
    switch (whichCompent) {
        case SIMPLEINPUT:
            jq = createSimpleInput();
            break;
        case TEXTAREA:
            jq = createTextArea();   
            break;
        case RADIO:
            jq = createRadio();
            break;
        case CHECKBOX:
            jq = createcheckBox();
            break;
        case SELECT:
            jq = createPullDownInput();
            break;
        case NUMBER:
            jq = createNumberInput();
            break;
        case DATE:
            jq = createDateInput();
            break;
        case SWITCH:
            jq = createSwitch();
            break;
        case CASCADER:
            jq = createAreaInput();
            break;
        case TEXT:
            jq = createText();
            break;
        case SCORE:
            jq = createScore();
            break;
        case SPLITLINE:
            jq = createSpiltLine();
            break;
        default:
            break;
    }
    
    if(!!jq){
        jq.appendTo($("#pagemain"));
        currentComJq = jq;
        //组装表单设置项
        assembleSettingMeun(whichCompent);
    }
}

/**预览 */
function previewCanvas(){
    // currentCanvasJq = $("#formCanvas").children();
    $.router.load("./preview.html");
}

/**创建单行输入框 */
function createSimpleInput(){
    var componentStr =  '<div class="weui-cells__title component_Name">文本框</div>'+
        '<div class="weui-cells">'+
            '<div class="weui-cell">'+
            '<div class="weui-cell__bd">'+
                '<input class="weui-input component_inputTip" type="text" placeholder="请输入文本">'+
            '</div>'+
            '</div>'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建文本域输入框 */
function createTextArea(){
    var componentStr =  '<div class="weui-cells__title component_Name">文本域</div>'+
                        '<div class="weui-cell" style="background-color:#fff">'+
                        '<div class="weui-cell__bd">'+
                        '<textarea class="weui-textarea component_inputTip"  placeholder="请输入文本" rows="3"></textarea>'+
                        '<div class="weui-textarea-counter"><span>0</span>/200</div>'+
                        '</div>'+
                    '</div>';
    return createSelectCompentJQ(componentStr);
}

/**创建日期输入框 */
function createDateInput(){
    var componentStr =  '<div class="weui-cells__title component_Name">日期</div>'+
                            '<div class="weui-cell" style="background-color:#fff">'+
                            '<div class="weui-cell__bd">'+
                            '<input class="weui-input component_inputTip" type="date" value="">'+
                            '</div>'+
                            '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建下拉框输入框 */
function createPullDownInput(){
    var componentStr =  '<div class="weui-cells__title component_Name">下拉框</div>'+
        '<div class="weui-cell" style="background-color:#fff">'+
        '<input class="weui-input component_inputTip" type="text" value="选项">'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建地区级联输入框 */
function createAreaInput(){
    var componentStr ='<div class="weui-cells__title component_Name">地区</div>'+
        '<div class="weui-cell" style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<label for="" class="weui-label component_Name">选择地区</label>'+
        '<input type="text" class="weui-input component_inputTip" id="city-picker" value="省 市 区/县" />'+
        '</div>'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建数字输入框 */
function createNumberInput(){
    var componentStr ='<div class="weui-cells__title component_Name">数字</div>'+
        '<div class="weui-cell"  style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<label for="" class="weui-label component_Name">数字</label>'+
        '<input class="weui-input" type="number" pattern="[0-9]*" placeholder="请输入数字">'+
        '</div>'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建底部说明文字 */
function createText(){
    var componentStr = '<div class="weui-cells__title component_Name">文本</div>'+
    '<div class="weui-cell" style="background-color:#fff">'+
    '<div class="weui-cell__bd">'+
    '<input class="weui-input component_inputTip" type="text" value="请输入文本">'+
    '</div>'+
    '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建评分 */
function createScore(){
    var componentStr = '<div class="weui-cells__title component_Name">评分</div>'+
        '<div class="weui-cell" style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        ' <span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span><span class="icon icon-star starScore"></span>'+
        '</div>'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

/**创建分割线 */
function createSpiltLine(){
    var componentStr = '<div class="weui-cells__title component_Name">分割线</div>'+
        '<div class="weui-cell" style="background-color:#fff">'+
        '<div class="weui-cell__bd">'+
        '<hr style=""/>'+
        '</div>'+
        '</div>';
    return  createSelectCompentJQ(componentStr);
}

///**创建文本域输入框 */
//function createTextArea(){
//    var componentStr = '<div class="weui-cell" style="background-color:#fff">'+
//                        '<div class="weui-cell__bd">'+
//                        '<textarea class="weui-textarea component_inputTip"  placeholder="请输入文本" rows="3"></textarea>'+
//                        '<div class="weui-textarea-counter"><span>0</span>/200</div>'+
//                        '</div>'+
//                    '</div>';
//    return createSelectCompentJQ(componentStr);
//}

/**创建图文组合框 */
function createfixeBox(){
    var componentStr ='<div class="weui-panel__bd" style="background-color:#fff">'+
                        '<a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">'+
                        '<div class="weui-media-box__hd">'+
                            '<img class="weui-media-box__thumb" src="./images/avatar.jpg">'+
                        '</div>'+
                        '<div class="weui-media-box__bd">'+
                            '<h4 class="weui-media-box__title">标题一</h4>'+
                            '<p class="weui-media-box__desc">由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</p>'+
                        '</div>'+
                        '</a>'+
                    '</div>';
    return createSelectCompentJQ(componentStr);
}

/**创建switch 开关 */
function createSwitch(){
    var componentStr ='<div class="weui-cells__title component_Name">同意条款</div>'+
                    '<label for="weuiAgree" class="weui-agree" style="background-color:#fff">'+
                        '<input id="weuiAgree" type="checkbox" class="weui-agree__checkbox">'+
                        '<span class="weui-agree__text"><span class="component_Name">同意</span>'+
                        ' <a href="javascript:void(0);"> <span class="component_linkContent">《相关条款》</span></a>'+
                        '</span>'+
                    '</label>';
    return createSelectCompentJQ(componentStr);
}

/**创建单选框 */
function createRadio(){
    var containerStr = '<div class="weui-cells__title component_Name">单选框</div>';
    containerStr += '<div class="weui-cells weui-cells_radio" style="margin-top:0px;">';
    var componentStr = ""+containerStr;
    //创建选项
    for(var i = 0; i< 1;i++){
        componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="x11'+i+'">'+
            '<div class="weui-cell__bd">'+
            '<p>cell standard</p>'+
            '</div>'+
            '<div class="weui-cell__ft">'+
            '<input type="radio" class="weui-check" name="radio1" id="x11'+i+'">'+
            '<span class="weui-icon-checked"></span>'+
            '</div>'+
        '</label>';
    }
    componentStr += "</div>";
    return createSelectCompentJQ(componentStr);
}


/**创建复选框 */
function createcheckBox(){
    var containerStr = '<div class="weui-cells__title component_Name">多选框</div>';
    containerStr += '<div class="weui-cells weui-cells_checkbox">';
    var componentStr = "" + containerStr;
    for(var i= 0; i< 1; i++){
        componentStr +='<label class="weui-cell weui-check__label" style="padding-top:0px;padding-bottom: 0px;" for="s11'+i+'">'+
            '<div class="weui-cell__hd">'+
            '<input type="checkbox" class="weui-check" name="checkbox1" id="s11'+i+'" checked="checked">'+
            '<i class="weui-icon-checked"></i>'+
            '</div>'+
            '<div class="weui-cell__bd">'+
            '<p>standard is dealt for u.</p>'+
            '</div>'+
            '</label>';
    }
    componentStr += "</div>";
    return createSelectCompentJQ(componentStr);
}

/**创建下拉框选项 */
function createSelect(){
    var componentStr = '<div class="weui-cell" style="background-color:#fff">' +
                    '<div class="weui-cell__hd">'+
                    '    <label class="weui-label component_Name">qq</label>'+
                    '  </div>'+
                    '  <div class="weui-cell__bd" style="background-color:#fff">'+
                    '    <input class="weui-input component_inputTip" placeholder="请输入qq号">'+
                    '  </div>'+
                    '</div>';

    return  createSelectCompentJQ(componentStr);
}

/**创建级联菜单选项 */
function createCascader(){
    var componentStr = '<div class="weui-cell" style="background-color:#fff">' +
                    '<div class="weui-cell__hd">'+
                    '    <label class="weui-label component_Name">qq</label>'+
                    '  </div>'+
                    '  <div class="weui-cell__bd" style="background-color:#fff">'+
                    '    <input class="weui-input component_inputTip" placeholder="请输入qq号">'+
                    '  </div>'+
                    '</div>';
    return createSelectCompentJQ(componentStr);
}


/**创建表单 */
function createCompentJQ(componentStr){
    var divBox = $("<div>").html(componentStr);
    return divBox.children();
}

/**创建选中的效果*/
function createSelectCompentJQ(componentStr){
    var divBox = $("<div>").html(componentStr).addClass("divBox");
    divBox.css({"border":"3px dashed yellow","position":"relative"});
    setInputDisabled(divBox);
    var deleteBtn = $("<i>").addClass("icon icon-remove").addClass("selectTagRemove")
            .css({"position":"absolute","color":"red","right": "10px","top":"0px"});
    var moveUp = $("<i>").addClass("icon icon-up").addClass("moveUp")
            .css({"position":"absolute","font-weight":"bold",'color':'red',"right": "37px","top":"0px"});
    var moveDown = $("<i>").addClass("icon icon-down").addClass("moveDown")
            .css({"position":"absolute","font-weight":"bold",'color':'red',"right": "60px","top":"0px"});
    deleteBtn.appendTo(divBox);
    moveUp.appendTo(divBox);
    moveDown.appendTo(divBox);
    $(document).on("click",".selectTagRemove",function () {
        //移除控件
        $(this).parent().remove();
        //移除控件还要移除相应的数据,key为控件唯一的标识
        var commpoentkey = $(this).parent().data("key");
        console.log("控件id",commpoentkey);
        if(!!commpoentkey){
            removeKeyData(commpoentkey);
        }
    });
    //上移动
    $(document).on("click",".moveUp",function () {
        console.log($(this).parent().prev());
        var $prev = $(this).parent().prev();
        $prev.before($(this).parent());
        var key = $(this).parent().data("key");
        upInArray(key);
    });

    //下移动
    $(document).on("click",".moveDown",function () {
        var $next = $(this).parent().next();
        $next.after($(this).parent());
        var key = $(this).parent().data("key");
        downInArray(key);
    });

    //点击选中
    $(document).unbind("click").on("click",".divBox",function () {
        styleInit();
        var clickeKey = $(this).data("key");
        cancelAllSelect();
        var clickData = getKeyData(clickeKey);
        if(!!clickData){
            styleRuturn(clickData.styleObj);//样式回流
            getStyleObj(clickData.styleObj);
            addSelect(clickData.jqObj);
            //设置当前选中的
            clickHaveSelectCom(clickData);
        }
    });
    return divBox;
}

/**添加选中框效果 */
function addSelect(comJq){
    comJq.css({"border":"3px dashed black","position":"relative"});
    comJq.find(".selectTagRemove").show();
}

/**取消选中框效果 */
function cancelSelect(comJq){
    comJq.css({"border":"0px dashed yellow","position":"relative"});
    comJq.find(".selectTagRemove").hide();
}

/**取消所有的选中 */
function cancelAllSelect(){
    for(var i = 0; i < formTepComArr.length; i++){
        cancelSelect(formTepComArr[i].jqObj);
    }
}

/**让jq内所有的input框禁用 */
function setInputDisabled(divJq){
    for(var i = 0 ; i< divJq.find("input").length;i++){
        $(divJq.find("input")[i]).attr("disabled","disabled");
    }
}

/**移除UI相应的数据key */
function removeKeyData(key){
    var tempArr = [];
    for(var i = 0; i < formTepComArr.length; i++){
        if(formTepComArr[i].key != key){
            tempArr.push(formTepComArr[i]);
        }
    }
    formTepComArr = tempArr;
}

/**找到相应的数据*/
function getKeyData(key){
    for(var i = 0; i < formTepComArr.length; i++){
        if(formTepComArr[i].key == key){
            return formTepComArr[i];
        }
    }
    return null;
}

/**解析url的参数 */
function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
}

/**数组中的某个元素上移动一个位置 */
function upInArray(key){
    var temp;
    for(var i = 0 ; i< formTepComArr.length; i++){
        if(formTepComArr[i].key == key&& i != 0){
            temp = formTepComArr[i];
            formTepComArr[i] = formTepComArr[i-1];
            formTepComArr[i-1] = temp;
            break;
        }
    }
}

/**数组中的某个元素下移动一个位置 */
function downInArray(key){
    var temp; 
    for(var i = 0 ; i< formTepComArr.length; i++){
        if(formTepComArr[i].key == key&& i <= formTepComArr.length-1){
            temp = formTepComArr[i];
            formTepComArr[i] = formTepComArr[i+1];
            formTepComArr[i+1] = temp;
            break;
        }
    }
}